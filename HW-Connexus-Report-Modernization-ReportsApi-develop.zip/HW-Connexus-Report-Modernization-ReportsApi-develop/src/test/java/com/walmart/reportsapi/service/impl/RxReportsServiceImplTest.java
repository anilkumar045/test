package com.walmart.reportsapi.service.impl;

import java.text.ParseException;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import com.walmart.reportsapi.bo.rxreports.RxActivityBO;
import com.walmart.reportsapi.repository.RxReportsDao;
import com.walmart.reportsapi.service.RxReportsService;

/**
 * @author vn50wzr
 * This is a Service Test class to generate third party receivables reports
 *
 */
@RunWith(SpringRunner.class)
public class RxReportsServiceImplTest {
	
	@TestConfiguration
	static class RxActivityServiceConfiguration{
		@Bean
		public RxReportsService rxActivityService(){
			return new RxReportsServiceImpl();
		}
	}
	@MockBean
	private RxReportsDao rxActivityDAO;
	@Autowired
	private RxReportsService rxActivityService;
	@Before
	public void setUp(){
		
		MockitoAnnotations.initMocks(this);
	}
	
	
	
	@Test
	public void getRxActivity() throws ParseException{
		RxActivityBO rxActivityBO =new RxActivityBO();
		Mockito.when(rxActivityDAO.getRxActivityReportRepository( Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(rxActivityBO);

		RxActivityBO rxActivityReportBO =rxActivityService.getRxActivityReportService("5533", "5545", "10/12/2020 11:10:11");
		Assertions.assertTrue(rxActivityReportBO!=null);
	}
}
