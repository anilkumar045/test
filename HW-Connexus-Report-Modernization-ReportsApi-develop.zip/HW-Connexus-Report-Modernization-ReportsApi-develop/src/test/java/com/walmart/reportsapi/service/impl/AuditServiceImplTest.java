package com.walmart.reportsapi.service.impl;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import com.walmart.reportsapi.bo.audit.ControlledSubstanceRxBO;
import com.walmart.reportsapi.bo.audit.ControlledSubstanceRxDetailsBO;
import com.walmart.reportsapi.repository.AuditDao;
import com.walmart.reportsapi.service.AuditService;

/**
 * @author vn50w1j This is a Service Test class to generate Audit report
 *
 */
@RunWith(SpringRunner.class)
public class AuditServiceImplTest {
	@TestConfiguration
	static class AuditConfiguration {
		@Bean
		public AuditService auditService() {
			return new AuditServiceImpl();
		}
	}

	@MockBean
	private AuditDao auditdao;
	@Autowired
	private AuditService auditService;

	@Before
	public void setUp() {

		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getAuditActivity() throws Exception {
		ControlledSubstanceRxDetailsBO controlSubstanceRxBO = new ControlledSubstanceRxDetailsBO();
		Mockito.when(auditdao.getControlledSubstanceRxDetailsRepository(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(controlSubstanceRxBO);
				

		ControlledSubstanceRxDetailsBO controlActivityBO = auditService.getControlledSubstanceRxDetailsService("5533","12/01/2020 12:00:00 AM","12/02/2020 12:00:00 AM");
				

		Assertions.assertTrue(controlActivityBO != null);
	}


}
