/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report API team, Primary :Mounica(vn50vfz)
 * Date: 2020/12/30
 * Version: 0.1
 * Description: This Service Implementation Layer Test class is responsible for getting  the Amber Vial Inventory
 * report details based on input request parameters from the big data tables
 * TABLES: rts_vial,pharmacy_item,phm_item_cost,rx_fill_item			
 * The output is written to
 * 1. Request and Responses are generated in the JSON Format
 * 2. Informix and CosMos DB tables which is primarily used for Reports
 * 
 */
package com.walmart.reportsapi.controller;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.reportsapi.bo.audit.HeaderBO;
import com.walmart.reportsapi.bo.returntostockreports.AmberVialInventoryActivityBO;
import com.walmart.reportsapi.bo.returntostockreports.AmberVialInventoryDataBO;
import com.walmart.reportsapi.bo.returntostockreports.AmberVialInventoryStoreDetailsBO;
import com.walmart.reportsapi.service.ReturnToStockReportsService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = ReturnToStockReportsController.class)
public class ReturnToStockReportsControllerTest {
	@Autowired
	private MockMvc mockMvc;
	@Mock
	@Qualifier("returnToStockReportsService")
	private ReturnToStockReportsService returnToStockReportsService;

	@Before
	public void setUp() {

	}

	@Test
	public void getAmberVialInventoryActivity() throws Exception {
		String uri = "/returntostock/amber-vial-inventory";
		AmberVialInventoryActivityBO amberVialInventoryActivityBO = setReportDetails();
		Mockito.when(returnToStockReportsService.getAmberVialInventoryReport(Mockito.any(), Mockito.any(),
				Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt()))
				.thenReturn(amberVialInventoryActivityBO);

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(uri).param("fromDate", "12/26/2020 12:00:00 AM")

				.param("toDate", "12/27/2020 12:00:00 AM").param("storeId", "5533").param("reportOption", "6")
				.param("fromVialId", "10").param("toVialId", "20").accept(MediaType.APPLICATION_JSON);
		MvcResult mvcResult = null;
		try {
			mvcResult = mockMvc.perform(requestBuilder).andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int status = mvcResult.getResponse().getStatus();
		String content = null;
		try {
			content = mvcResult.getResponse().getContentAsString();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ObjectMapper objectMapper = new ObjectMapper();
		AmberVialInventoryActivityBO amberActivityBO = null;
		try {
			amberActivityBO = objectMapper.readValue(content, AmberVialInventoryActivityBO.class);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Assertions.assertEquals(200, status);
		Assertions.assertEquals(5533, amberActivityBO.getStoreDetails());
	}

	private AmberVialInventoryActivityBO setReportDetails() {

		Integer storeNumber = 5533;
		String appName = "Connexus Pharmacy System";
		String store = "Wal-Mart Pharmacy10-5533";
		String reportName = "AMBER VIAL INVENTORY";

		List<AmberVialInventoryStoreDetailsBO> storeDetails = new ArrayList<>();
		List<HeaderBO> header = new ArrayList<>();
		List<AmberVialInventoryDataBO> data = new ArrayList<>();

		AmberVialInventoryActivityBO amberVialInventoryActivityBO = new AmberVialInventoryActivityBO(storeDetails,
				header, data);
		storeDetails.add(new AmberVialInventoryStoreDetailsBO(storeNumber, appName, store, reportName));

		header.add(new HeaderBO("Vial ID", "vialId"));
		header.add(new HeaderBO("NDC", "ndc"));
		header.add(new HeaderBO("Drug Description", "drugDescription"));
		header.add(new HeaderBO("Original Quantity", "originalQuantity"));
		header.add(new HeaderBO("Original Cost", "originalCost"));
		header.add(new HeaderBO("Current Quantity", "currentQuantity"));
		header.add(new HeaderBO("Create Date", "createDate"));
		header.add(new HeaderBO("Expiration Date", "expirationDate"));
		header.add(new HeaderBO("User ID", "userId"));
		header.add(new HeaderBO("Time Stamp", "timeStamp"));
		header.add(new HeaderBO("Status", "status"));

		data.add(new AmberVialInventoryDataBO(5533, "00254359435", "HYDROCO/ACETAMIN 7.5-500MG TAB", "63.0", "2.00",
				"10", "2020-12-28 12:18:30", "2018-06-28T18:30Z", "MCLARK", "2020-12-27 12:18:30", "ACTIVE"));

		return amberVialInventoryActivityBO;
	}
}