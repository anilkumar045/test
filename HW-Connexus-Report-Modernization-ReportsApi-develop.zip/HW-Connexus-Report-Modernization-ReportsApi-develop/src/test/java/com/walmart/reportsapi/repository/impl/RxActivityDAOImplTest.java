package com.walmart.reportsapi.repository.impl;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import com.walmart.reportsapi.bo.rxreports.RxActivityBO;
import com.walmart.reportsapi.repository.RxReportsDao;
import com.walmart.reportsapi.repository.impl.rxreports.*;
import com.walmart.reportsapi.util.DateUtil;

/**
 * @author vn50wzr
 * 
 */
@RunWith(SpringRunner.class)
public class RxActivityDAOImplTest {

	@TestConfiguration
	static class RxActivityDAOConfiguration {
		@Bean
		public RxReportsDao rxactivitydao() {
			return new RxActivityDaoImpl();
		}
	}

	@Autowired
	private RxReportsDao rxactivitydao;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getRxActivity() {
		String rxNumber = "2015026";
		String fillDate = "10/18/2020 11:10:11";
		String storeId="5547";
		RxActivityBO rxActivityBO = rxactivitydao.getRxActivityReportRepository(storeId, rxNumber, fillDate);
		Assertions.assertEquals(true, rxActivityBO != null);
		
	}
}
