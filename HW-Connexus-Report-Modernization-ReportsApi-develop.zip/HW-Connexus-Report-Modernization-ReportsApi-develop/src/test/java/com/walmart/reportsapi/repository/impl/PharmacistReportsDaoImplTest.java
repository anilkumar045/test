package com.walmart.reportsapi.repository.impl;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import com.walmart.reportsapi.bo.pharmacistreports.DailyVisualVerifyCheckActivityBO;
import com.walmart.reportsapi.bo.pharmacistreports.FourPointCheckActivityBO;
import com.walmart.reportsapi.bo.pharmacistreports.PharmacistActivityReportBO;
import com.walmart.reportsapi.repository.PharmacistReportsDao;
import com.walmart.reportsapi.repository.impl.pharmacistreports.*;

/**
 * @author vn50vfz This is a test class for Repository Layer
 */
@RunWith(SpringRunner.class)
public class PharmacistReportsDaoImplTest {

	@TestConfiguration
	static class ThirdPartyConfiguration {
		@Bean
		public PharmacistReportsDao fourPtCheckDAO() {
			return new FourPointCheckDaoImpl();
		}
	}

	@Autowired
	private PharmacistReportsDao pharmacistReportsDao;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getFourPtActivity() throws Exception {

		FourPointCheckActivityBO fourPtCheckActivityBO = pharmacistReportsDao.getFourPointCheckActivityRepository("5533", "10/22/2020 12:00:00",
				"10/22/2020 12:00:00");
		Assertions.assertEquals(true, fourPtCheckActivityBO != null);

	}
	@Test
	public void getPharmacistActivity()  throws Exception{
		PharmacistActivityReportBO pharmacistActivityReportBO =pharmacistReportsDao.getPharmacistActivityReportRepository("5533","2020-12-23","Sumathi Gurusamy - Vendor");
		Assertions.assertEquals(true,pharmacistActivityReportBO!=null);
	}
	
	@Test
	public void getDailyVisuavlVerify() throws Exception {

		DailyVisualVerifyCheckActivityBO dailyVisualVerifyBO  = pharmacistReportsDao.getDailyVisualVerifyReport("3222", "10/22/2020 12:00:00",
				"10/22/2020 12:00:00");
		Assertions.assertEquals(true, dailyVisualVerifyBO != null);

	}
}
