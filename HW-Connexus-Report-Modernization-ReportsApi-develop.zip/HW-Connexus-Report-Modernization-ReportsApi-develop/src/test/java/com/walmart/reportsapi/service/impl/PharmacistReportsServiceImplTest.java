package com.walmart.reportsapi.service.impl;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import com.walmart.reportsapi.bo.pharmacistreports.DailyVisualVerifyCheckActivityBO;
import com.walmart.reportsapi.bo.pharmacistreports.FourPointCheckActivityBO;
import com.walmart.reportsapi.bo.pharmacistreports.PharmacistActivityReportBO;
import com.walmart.reportsapi.repository.PharmacistReportsDao;

import com.walmart.reportsapi.service.PharmacistReportsService;

/**
 * @author vn50vfz This is a Service Test class to generate third party
 *         receivables reports
 *
 */
@RunWith(SpringRunner.class)
public class PharmacistReportsServiceImplTest {

	@TestConfiguration
	static class FourPtActivityConfiguration {
		@Bean
		public PharmacistReportsService fourPtCheckService() {
			return new PharmacistReportsServiceImpl();
		}
	}

	@MockBean
	private PharmacistReportsDao pharmacistReportsDao;
	@Autowired
	private PharmacistReportsService pharmacistReportsService;

	@Before
	public void setUp() {

		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void get4PtActivity() throws Exception {
		FourPointCheckActivityBO fourPtCheckActivityBO = new FourPointCheckActivityBO();
		Mockito.when(pharmacistReportsDao.getFourPointCheckActivityRepository(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(fourPtCheckActivityBO);

		FourPointCheckActivityBO fourptActivityReportBO = pharmacistReportsService
				.getFourPointCheckActivityService("5533", "10/22/2020 12:00:00", "10/22/2020 12:00:00");
		Assertions.assertTrue(fourptActivityReportBO != null);
	}
	@Test
	public void getPharmacyActivity()  throws Exception{
		PharmacistActivityReportBO pharmacistActivityReportBO =new PharmacistActivityReportBO();
		Mockito.when(pharmacistReportsDao.getPharmacistActivityReportRepository(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(pharmacistActivityReportBO);

		PharmacistActivityReportBO pharmacistActivityBO =pharmacistReportsService.getPharmacistActivityReportService("5533","2020-12-23","Sumathi Gurusamy - Vendor");
		Assertions.assertEquals(5545,pharmacistActivityBO.getStoreId());
	}
	@Test
	public void getDailyVisualVerifycheck() throws Exception {
		DailyVisualVerifyCheckActivityBO dailyVisualVerifyBO = new DailyVisualVerifyCheckActivityBO();
		Mockito.when(pharmacistReportsDao.getDailyVisualVerifyReport(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(dailyVisualVerifyBO);

		DailyVisualVerifyCheckActivityBO dailyVisVerBO = pharmacistReportsService
				.getDailyVisualVerifyReport("3222", "10/22/2020 12:00:00", "10/22/2020 12:00:00");
		Assertions.assertTrue(dailyVisVerBO != null);
	}
}
