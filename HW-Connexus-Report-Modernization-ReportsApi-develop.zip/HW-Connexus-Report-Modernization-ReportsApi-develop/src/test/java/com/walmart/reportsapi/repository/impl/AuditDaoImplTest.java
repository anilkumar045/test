package com.walmart.reportsapi.repository.impl;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import com.walmart.reportsapi.bo.audit.ControlledSubstanceRxDetailsBO;
import com.walmart.reportsapi.repository.AuditDao;
import com.walmart.reportsapi.repository.impl.audit.*;

/**
 * @author vn50w1j This is a test class for Repository Layer
 */
@RunWith(SpringRunner.class)
public class AuditDaoImplTest {
	@TestConfiguration
	static class AuditConfiguration {
		@Bean
		public AuditDao auditdao() {
			return new ControlledSubstanceRxDetailsDaoImpl();
		}
	}

	@Autowired
	private AuditDao auditdao;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getAuditDaoActivity() throws Exception {

		ControlledSubstanceRxDetailsBO controlSubstanceRxActivityBO = auditdao
				.getControlledSubstanceRxDetailsRepository("5533", "12/01/2020 12:00:00 AM", "12/02/2020 12:00:00 AM");

		Assertions.assertEquals(true, controlSubstanceRxActivityBO != null);

	}

}
