package com.walmart.reportsapi.controller;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.reportsapi.bo.rxreports.DataBO;
import com.walmart.reportsapi.bo.audit.HeaderBO;
import com.walmart.reportsapi.bo.rxreports.RxActivityBO;
import com.walmart.reportsapi.service.RxReportsService;

/**
 * @author vn50wzr
 * This is a Controller Test class to generate RX Activity Report
 *
 */
@RunWith(SpringRunner.class)
@WebMvcTest(value =RxReportsController.class)
public class RxReportsControllerTest {
	@Autowired
	private MockMvc mockMvc;
	@Mock
	@Qualifier("rxActivityService")
	private RxReportsService rxReportsService;
	
	@Before
	public void setUp(){
		
	}
	
	@Test
	public void getRxActivityId() throws ParseException{
		String uri="/rx-report";
		RxActivityBO rxActivityBO = setReportDetails();
		Mockito.when(rxReportsService.getRxActivityReportService(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(rxActivityBO);
		RequestBuilder requestBuilder=MockMvcRequestBuilders.get(uri)
				.param("rxNumber","1254677")
				.param("fillDate", "12/13/2020 11:11:11")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult mvcResult=null;
		try {
			mvcResult = mockMvc.perform(requestBuilder).andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int status =mvcResult.getResponse().getStatus();
		String content=null;
		try {
			content = mvcResult.getResponse().getContentAsString();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ObjectMapper objectMapper=new ObjectMapper();
		RxActivityBO rxActBO=null;
		try {
			rxActBO = objectMapper.readValue(content, RxActivityBO.class);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Assertions.assertEquals(200,status);
		Assertions.assertEquals(5561,rxActBO.getStoreId());
	}
	
	private RxActivityBO setReportDetails(){
		List<HeaderBO> header = new ArrayList<>();
		List<DataBO> data = new ArrayList<>();

		String date = "11/06/2020";
		Integer storeId = 5561;
		String appName = "Connexus Pharmacy System";
		String store = "Wal-Mart Pharmacy10-5561";
		String reportName = "Activity Report";
		String details = "5025 LOOP 410 NORTHWEST 5025 TRUTH OR CONSEQUENCE TRU COTRUTH OR CONSEQUENCE SC - 72712";
		String note = "* Blank store number indicates local store activity";

		RxActivityBO rxActivity = new RxActivityBO(storeId, date, appName, store, reportName, details, note, header, data);

		header.add(new HeaderBO("Rx Nbr", "rxNbr"));
		header.add(new HeaderBO("Fill Nbrr", "fillNbr"));
		header.add(new HeaderBO("Store Nbr", "rxNbr"));
		header.add(new HeaderBO("User Id", "userId"));
		header.add(new HeaderBO("User Name", "userName"));
		header.add(new HeaderBO("Activity Date", "activityDate"));
		header.add(new HeaderBO("Station", "station"));

		data.add(new DataBO("2202652", 1, "1120408", null, "VN50W1L", "10/06/2020 11:45:00 AM", "Four Point Check",
				"Aswinkumar Packirisamy - Vendor"));
		data.add(new DataBO("2202652", 2, "1120408", null, "VN50W1L", "10/06/2020 11:45:00 AM", "Input Check",
				"Aswinkumar Packirisamy - Vendor"));
		data.add(new DataBO("2202652", 3, "1120408", null, "VN50W1L", "10/06/2020 11:45:00 AM", "Visual Check",
				"Aswinkumar Packirisamy - Vendor"));
		return rxActivity;
	}

	

}
