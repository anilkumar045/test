/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report API team, Primary :Mounica(vn50vfz)
 * Date: 2020/12/30
 * Version: 0.1
 * Description: This Service Implementation Layer Test class is responsible for getting  the Amber Vial Inventory
 * report details based on input request parameters from the big data tables
 * TABLES: rts_vial,pharmacy_item,phm_item_cost,rx_fill_item			
 * The output is written to
 * 1. Request and Responses are generated in the JSON Format
 * 2. Informix and CosMos DB tables which is primarily used for Reports
 * 
 */
package com.walmart.reportsapi.service.impl;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import com.walmart.reportsapi.bo.returntostockreports.AmberVialInventoryActivityBO;
import com.walmart.reportsapi.repository.ReturnToStockReportsDao;
import com.walmart.reportsapi.service.ReturnToStockReportsService;

@RunWith(SpringRunner.class)
public class ReturnToStockReportsServiceImplTest {

	@TestConfiguration
	static class ReturnToStockReportsConfiguration {
		@Bean
		public ReturnToStockReportsService returnToStockReportsService() {
			return new ReturnToStockReportsServiceImpl();
		}
	}

	@MockBean
	private ReturnToStockReportsDao returnToStockReportsDao;

	@Autowired
	private ReturnToStockReportsService returnToStockReportsService;

	@Before
	public void setUp() {

		MockitoAnnotations.initMocks(this);
	}
	/**
	 * This Service layer Implementation Test Case method is used get the
	 * Amber Vial Inventory report details based on fromDate, toDate, storeId, reportOption, fromVialId, toVialId
	 * 
	 * @param String fromDate
	 * @param String toDate
	 * @param Integer storeId
	 * @param Boolean reportOption
	 * @param Integer fromVialId
	 * @param  Integer toVialId
	 * @return AmberVialInventoryActivityBO(contains report details,header details and report data details)
	 * @throws Exception(Null Pointer/Record Not Found)
	 * 
	 */
	@Test
	public void getAmberVialInventoryActivity() throws Exception {
		AmberVialInventoryActivityBO amberVialInventoryActivityBO = new AmberVialInventoryActivityBO();
		Mockito.when(returnToStockReportsDao.getAmberVialInventoryReport(Mockito.any(), Mockito.any(), Mockito.anyInt(),
				Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(amberVialInventoryActivityBO);

		AmberVialInventoryActivityBO amberVialActivityBO = returnToStockReportsService
				.getAmberVialInventoryReport("11/23/2020 12:00:00 AM", "12/23/2020 12:00:00 AM", 5533, 5, 0, 0);

		Assertions.assertTrue(amberVialActivityBO != null);
	}
}
