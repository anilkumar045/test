package com.walmart.reportsapi.controller;

import java.io.UnsupportedEncodingException;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.reportsapi.bo.pharmacistreports.DailyVisualCheckDataBO;
import com.walmart.reportsapi.bo.pharmacistreports.DailyVisualVerifyCheckActivityBO;
import com.walmart.reportsapi.bo.pharmacistreports.DailyVisualVerifyCheckDatesBO;
import com.walmart.reportsapi.bo.pharmacistreports.DailyVisualVerifyCheckPharmacistBO;
import com.walmart.reportsapi.bo.pharmacistreports.FourPointCheckActivityBO;
import com.walmart.reportsapi.bo.pharmacistreports.FourPointCheckDataBO;
import com.walmart.reportsapi.bo.pharmacistreports.FourPointCheckDatesBO;
import com.walmart.reportsapi.bo.pharmacistreports.FourPointCheckPharmacistBO;
import com.walmart.reportsapi.bo.pharmacistreports.FourPointCheckStoreDetailsBO;
import com.walmart.reportsapi.bo.pharmacistreports.PharmacistActivityDataBO;
import com.walmart.reportsapi.bo.pharmacistreports.PharmacistActivityReportBO;
import com.walmart.reportsapi.bo.StoreDetailsBO;
import com.walmart.reportsapi.bo.audit.HeaderBO;
import com.walmart.reportsapi.service.PharmacistReportsService;

/**
 * @author vn50vfz This is a Controller Test class to generate 4 Pt Check
 *         Activity Report
 *
 */
@RunWith(SpringRunner.class)
@WebMvcTest(value = PharmacistReportsController.class)
public class PharmacistReportsControllerTest {
	@Autowired
	private MockMvc mockMvc;
	@Mock
	@Qualifier("fourPtCheckService")
	private PharmacistReportsService pharmacistReportsService;

	@Before
	public void setUp() {

	}

	@Test
	public void get4PtActivityId() throws Exception {
		String uri = "/4-point-check-report";
		FourPointCheckActivityBO fourPtCheckActivityBO = setReportDetails();
		Mockito.when(pharmacistReportsService.getFourPointCheckActivityService(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(fourPtCheckActivityBO);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(uri).param("fromDate", "10/22/2020 12:00:00")
				.param("toDate", "10/22/2020 12:00:00").accept(MediaType.APPLICATION_JSON);
		MvcResult mvcResult = null;
		try {
			mvcResult = mockMvc.perform(requestBuilder).andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int status = mvcResult.getResponse().getStatus();
		String content = null;
		try {
			content = mvcResult.getResponse().getContentAsString();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ObjectMapper objectMapper = new ObjectMapper();
		FourPointCheckActivityBO fourptActBO = null;
		try {
			fourptActBO = objectMapper.readValue(content, FourPointCheckActivityBO.class);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Assertions.assertEquals(200, status);
		Assertions.assertEquals(1101, fourptActBO.getStoreDetails().getStoreNumber());
	}

	private FourPointCheckActivityBO setReportDetails() {
		Integer storeNumber = 1101;
		String appName = "Connexus Pharmacy System";
		String store = "Wal-Mart Pharmacy10-5561";
		String reportName = "4Point Check Report";
		String details = "5025 LOOP 410 NORTHWEST 5025 TRUTH OR CONSEQUENCE TRU COTRUTH OR CONSEQUENCE SC - 72712";

		List<HeaderBO> header = new ArrayList<HeaderBO>();
		List<FourPointCheckDatesBO> dates = new ArrayList<FourPointCheckDatesBO>();

		List<FourPointCheckPharmacistBO> pharmacists = new ArrayList<FourPointCheckPharmacistBO>();
		List<FourPointCheckDataBO> data = new ArrayList<FourPointCheckDataBO>();

		FourPointCheckActivityBO fourPtCheckActivity = new FourPointCheckActivityBO(
				new FourPointCheckStoreDetailsBO(storeNumber, appName, store, reportName, details), header, dates);

		header.add(new HeaderBO("Rx", "rx"));
		header.add(new HeaderBO("PatientName", "patientName"));
		header.add(new HeaderBO("FillDate", "fillDate"));
		header.add(new HeaderBO("Drug", "drug"));
		header.add(new HeaderBO("Quantity", "quantity"));
		header.add(new HeaderBO("DAW", "daw"));
		header.add(new HeaderBO("UserId", "userId"));
		header.add(new HeaderBO("Date/Time", "dateTime"));

		dates.add(new FourPointCheckDatesBO("2020-01-01T23:28:56.782Z", pharmacists));

		pharmacists.add(new FourPointCheckPharmacistBO("Chinmoy Pradhan", data));
		pharmacists.add(new FourPointCheckPharmacistBO("Tamil Selvan", data));
		pharmacists.add(new FourPointCheckPharmacistBO("Aswin Kumar", data));

		data.add(new FourPointCheckDataBO("88100046", "DISK,Orenge", "2020-01-01T23:28:56.782Z", "ADVANCE FORMULA CE TAB", "5",
				"0", "50V0059", "2020-01-01T23:28:56.782Z"));
		data.add(new FourPointCheckDataBO("88100047", "DISK,Orenge", "2020-01-01T23:28:56.782Z", "ADVANCE FORMULA CE TAB", "5",
				"0", "50V0059", "2020-01-01T23:28:56.782Z"));
		data.add(new FourPointCheckDataBO("88100049", "DISK,Orenge", "2020-01-01T23:28:56.782Z", "ADVANCE FORMULA CE TAB", "5",
				"0", "50V0059", "2020-01-01T23:28:56.782Z"));
		return fourPtCheckActivity;
	}
	@Test
	public void getPharmacyActivity() throws Exception {
		String uri = "/pharmacy-activity";
		PharmacistActivityReportBO pharmacistActivityReportBO = setPharmacyActivityReportDetails();
		Mockito.when(pharmacistReportsService.getPharmacistActivityReportService(Mockito.anyString(),Mockito.anyString(),Mockito.anyString()))
				.thenReturn(pharmacistActivityReportBO);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(uri).param("activityDate", "10/26/2020")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult mvcResult = null;
		try {
			mvcResult = mockMvc.perform(requestBuilder).andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int status = mvcResult.getResponse().getStatus();
		String content = null;
		try {
			content = mvcResult.getResponse().getContentAsString();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ObjectMapper objectMapper = new ObjectMapper();
		PharmacistActivityReportBO pharmaActivityReportVO = null;
		try {
			pharmaActivityReportVO = objectMapper.readValue(content, PharmacistActivityReportBO.class);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Assertions.assertEquals(200, status);
		Assertions.assertEquals(5545, pharmaActivityReportVO.getStoreId());
	}

	private PharmacistActivityReportBO setPharmacyActivityReportDetails() {
		String date = "10/16/2020";
		int storeId = 5545;
		String appName = "Connexus Pharmacy System";
		String store = "Sam's Pharmacy10-5545";
		String reportName = "Pharmacist Activity Report";
		String details = "5025 LOOP 410 NORTHWEST 5025 TRUTH OR CONSEQUENCE TRU COTRUTH OR CONSEQUENCE SC - 72712";
		List<HeaderBO> header = new ArrayList<HeaderBO>();
		List<PharmacistActivityDataBO> data = new ArrayList<PharmacistActivityDataBO>();

		PharmacistActivityReportBO pharmacistActivityReportVO = new PharmacistActivityReportBO(storeId, date, appName,
				store, reportName, details, header, data);
		header.add(new HeaderBO("Rx Nbr", "rxNbr"));
		header.add(new HeaderBO("Activity", "activity"));

		pharmacistActivityReportVO.setHeader(header);
		data.add(new PharmacistActivityDataBO(2202652, 1, "Four Point Check"));
		data.add(new PharmacistActivityDataBO(2202652, 2, "Input Check"));
		data.add(new PharmacistActivityDataBO(2202652, 3, "Visual Checkr"));
		data.add(new PharmacistActivityDataBO(2202652, 4, "Four Point Check"));
		data.add(new PharmacistActivityDataBO(2202652, 5, "Input Check"));
		data.add(new PharmacistActivityDataBO(2202652, 6, "Visual Check"));
		pharmacistActivityReportVO.setData(data);
		return pharmacistActivityReportVO;
	}
	
	@Test
	public void getDailyVisualVerifyCheck() throws Exception {
		String uri = "/daily-visual-verify";
		DailyVisualVerifyCheckActivityBO dailyVisualCheckActivityBO = setDailyVisualVerifyReportDetails();
		Mockito.when(pharmacistReportsService.getDailyVisualVerifyReport(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(dailyVisualCheckActivityBO);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(uri).param("storeId", "3222").param("fromDate", "10/22/2020 12:00:00")
				.param("toDate", "10/22/2020 12:00:00").accept(MediaType.APPLICATION_JSON);
		MvcResult mvcResult = null;
		try {
			mvcResult = mockMvc.perform(requestBuilder).andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int status = mvcResult.getResponse().getStatus();
		String content = null;
		try {
			content = mvcResult.getResponse().getContentAsString();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ObjectMapper objectMapper = new ObjectMapper();
		DailyVisualVerifyCheckActivityBO dailyVCheckActivityBO = null;
		try {
			dailyVCheckActivityBO = objectMapper.readValue(content, DailyVisualVerifyCheckActivityBO.class);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Assertions.assertEquals(200, status);
		Assertions.assertEquals(3222, dailyVCheckActivityBO.getStoreDetails().getStoreNumber());
	}
	
	
	private DailyVisualVerifyCheckActivityBO setDailyVisualVerifyReportDetails() {

		Integer storeNumber = 3222;
		String reportDate = "date";
		String from = "2020-02-02T23:28:56.782Z";
		String to = "2020-02-01T23:28:56.782Z";
		String appName = "Connexus Pharmacy System";
		String store = "Wal-Mart Pharmacy10-3222";
		String reportName = "Visual Verify Check Report";
		String details = "3222 LOOP 410 NORTHWEST 5025 TRUTH OR CONSEQUENCE TRU COTRUTH OR CONSEQUENCE SC - 72712";

		List<HeaderBO> header = new ArrayList<>();
		header.add(new HeaderBO("Rx", "rx"));
		header.add(new HeaderBO("PatientName", "patientName"));
		header.add(new HeaderBO("FillDate", "fillDate"));
		header.add(new HeaderBO("Drug", "drug"));
		header.add(new HeaderBO("Quantity", "quantity"));
		header.add(new HeaderBO("UserId", "userId"));
		header.add(new HeaderBO("Date/Time", "dateTime"));
		List<DailyVisualVerifyCheckDatesBO> dates = new ArrayList<>();

		List<DailyVisualVerifyCheckPharmacistBO> pharmacists = new ArrayList<>();
		List<DailyVisualCheckDataBO> data = new ArrayList<>();

		DailyVisualVerifyCheckActivityBO dailyVisualCheckActivityBO  = new DailyVisualVerifyCheckActivityBO(new StoreDetailsBO(storeNumber, appName, store, reportName, details), header, dates);

		dates.add(new DailyVisualVerifyCheckDatesBO("11/23/2020", pharmacists));
		pharmacists.add(new DailyVisualVerifyCheckPharmacistBO("Conservation", data));
		data.add(new DailyVisualCheckDataBO("3600002", "ABCD DBCD, AWSER", "11/23/2020", "CLINDAMYCIN TAB TEST", "10",
				"VN506KD", "11/23/2020 13:55:55"));

		return dailyVisualCheckActivityBO;
	}
}
