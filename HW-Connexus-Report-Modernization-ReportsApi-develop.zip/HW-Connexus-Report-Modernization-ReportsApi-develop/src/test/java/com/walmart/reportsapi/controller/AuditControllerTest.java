package com.walmart.reportsapi.controller;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.reportsapi.bo.audit.ControlledSubstanceRxDetailsBO;
import com.walmart.reportsapi.bo.audit.ControlledSubstanceRxDetailsDataBO;
import com.walmart.reportsapi.bo.audit.ControlledSubstanceStoreDetailsBO;
import com.walmart.reportsapi.bo.audit.HeaderBO;
import com.walmart.reportsapi.service.AuditService;

/**
 * @author vn50w1j This is a Controller Test class to generate Audit Report
 *
 */
@RunWith(SpringRunner.class)
@WebMvcTest(value = AuditController.class)
public class AuditControllerTest {
	@Autowired
	private MockMvc mockMvc;
	@Mock
	@Qualifier("auditService")
	private AuditService auditService;

	@Before
	public void setUp() {

	}

	@Test
	public void getControlledSubstanceRxActivity() throws Exception {
		String uri = "/controlled-substance-rx-details";
		ControlledSubstanceRxDetailsBO controlSubstanceRxBO = setReportDetails();
		Mockito.when(auditService.getControlledSubstanceRxDetailsService(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(controlSubstanceRxBO);

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(uri).param("storeId", "5533").param("fromDate", "12/01/2020 12:00:00 AM")
				.param("toDate", "12/02/2020 12:00:00 AM").accept(MediaType.APPLICATION_JSON);
		MvcResult mvcResult = null;
		try {
			mvcResult = mockMvc.perform(requestBuilder).andReturn();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int status = mvcResult.getResponse().getStatus();
		String content = null;
		try {
			content = mvcResult.getResponse().getContentAsString();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ObjectMapper objectMapper = new ObjectMapper();
		ControlledSubstanceRxDetailsBO controllerActBO = null;
		try {
			controllerActBO = objectMapper.readValue(content, ControlledSubstanceRxDetailsBO.class);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Assertions.assertEquals(200, status);
		Assertions.assertEquals(5561, controllerActBO.getStoreDetails());
	}

	private ControlledSubstanceRxDetailsBO setReportDetails() {
		
		String storeId = "5666";
		String appName = "Connexus Pharmacy System";
		String store = "Wal-Mart Pharmacy10-5666";
		String reportName = "Controlled Substance Rx Details Report";
		List<ControlledSubstanceStoreDetailsBO> storeDetails = new ArrayList<>();
		List<HeaderBO> header = new ArrayList<HeaderBO>();
		List<ControlledSubstanceRxDetailsDataBO> data = new ArrayList<ControlledSubstanceRxDetailsDataBO>();

		ControlledSubstanceRxDetailsBO controlSubstanceRx = new ControlledSubstanceRxDetailsBO(storeDetails, header, data);
		
		storeDetails.add(new ControlledSubstanceStoreDetailsBO(storeId, appName, store, reportName));
		header.add(new HeaderBO("Rx Issue Date","date"));
		header.add(new HeaderBO("Rx Number","rxNbr"));
		header.add(new HeaderBO("Patient Name - Patient Address","patientInfo"));

		header.add(new HeaderBO( "Drug Name","drugName"));
		header.add(new HeaderBO("Quantity Prescribed","quantity"));
		header.add(new HeaderBO("Days Supply","supply"));
		header.add(new HeaderBO("Sig","sig"));
		header.add(new HeaderBO("Practioner Name - Practioner Address - DEA","prescriberInfo"));

		data.add(new ControlledSubstanceRxDetailsDataBO("10/27/2020","2202380",1,"SIV","NONG - BENTONVILLE AR 72712","Dextroamphet 10MG TAB","1.0","1","TAKE 1 TABLET BY MOUTH BEFORE MEAL(S)","JOHN","ABIE J - 921 NE 13TH ST OKLAHOMA CITY OK - 731045007 - FJ0000656","12238882990"));

				return controlSubstanceRx;
	}


}
