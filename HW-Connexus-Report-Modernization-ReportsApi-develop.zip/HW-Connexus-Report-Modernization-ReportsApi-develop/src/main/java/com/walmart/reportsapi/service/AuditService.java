package com.walmart.reportsapi.service;

import com.walmart.reportsapi.bo.audit.ControlledSubstanceRxDetailsBO;

public interface AuditService {

	ControlledSubstanceRxDetailsBO getControlledSubstanceRxDetailsService(String storeId, String fromDate, String toDate);

}
