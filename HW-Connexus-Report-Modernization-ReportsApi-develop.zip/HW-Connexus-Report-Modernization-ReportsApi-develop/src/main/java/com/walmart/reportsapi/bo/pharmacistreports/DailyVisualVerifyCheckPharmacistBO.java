package com.walmart.reportsapi.bo.pharmacistreports;

import java.util.List;

public class DailyVisualVerifyCheckPharmacistBO {

	private String pharmacistName;

	private List<DailyVisualCheckDataBO> data;

	public DailyVisualVerifyCheckPharmacistBO(String pharmacistName, List<DailyVisualCheckDataBO> data) {
		super();
		this.pharmacistName = pharmacistName;
		this.data = data;
	}

	public String getPharmacistName() {
		return pharmacistName;
	}

	public void setPharmacistName(String pharmacistName) {
		this.pharmacistName = pharmacistName;
	}

	public List<DailyVisualCheckDataBO> getData() {
		return data;
	}

	public void setData(List<DailyVisualCheckDataBO> data) {
		this.data = data;
	}

	

}
