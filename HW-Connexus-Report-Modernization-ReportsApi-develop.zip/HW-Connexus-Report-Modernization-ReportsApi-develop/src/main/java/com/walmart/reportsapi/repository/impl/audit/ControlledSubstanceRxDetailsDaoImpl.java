/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report API team, Primary :Shiva(vn50xd0)
 * Date: 2020/12/31
 * Version: 0.2
 * Description: This DAOImpl class is responsible for getting  the Controlled Substance Rx Details
 * Report details based on input request parameters from the big data tables
 * TABLES: rx_December, patient_GDB_DEC, fill_December, DrugModel, prescriber, license
 * The output is written to
 * 1. Request and Responses are generated in the JSON Format
 * 2. Big Table tables which is primarily used for Reports
 * 
 */
package com.walmart.reportsapi.repository.impl.audit;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import static com.google.cloud.bigtable.data.v2.models.Filters.FILTERS;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.gax.rpc.ServerStream;
import com.google.cloud.bigtable.data.v2.BigtableDataClient;
import com.google.cloud.bigtable.data.v2.models.Filters.InterleaveFilter;
import com.google.cloud.bigtable.data.v2.models.Query;
import com.google.cloud.bigtable.data.v2.models.Row;
import com.google.cloud.bigtable.data.v2.models.RowCell;
import com.walmart.reportsapi.bo.audit.ControlledSubstanceRxBO;
import com.walmart.reportsapi.bo.audit.ControlledSubstanceRxDetailsBO;
import com.walmart.reportsapi.bo.audit.ControlledSubstanceRxDetailsDataBO;
import com.walmart.reportsapi.bo.audit.ControlledSubstanceStoreDetailsBO;
import com.walmart.reportsapi.bo.audit.HeaderBO;
import com.walmart.reportsapi.repository.AuditDao;

@Repository
public class ControlledSubstanceRxDetailsDaoImpl implements AuditDao {
	private static final Logger LOGGER = LoggerFactory.getLogger(ControlledSubstanceRxDetailsDaoImpl.class);
	ControlledSubstanceRxDetailsBO controlledSubstanceRxDetails = null;
	Map<String, String> patientdetails = new HashMap<String, String>();
	Map<String, String> drugdetails = new HashMap<String, String>();
	Map<String, String> prescriberdetails = new HashMap<String, String>();
	Map<String, String> licensedetails = new HashMap<String, String>();

	String projectId = "wmt-hnw-techmod-poc";
	String instanceId = "hnw-conx-poc";
	String rxTable = "rx_December";
	String patientTable = "patient_GDB_DEC";
	String rxfillTable = "fill_December";
	String drugTable = "DrugModel";
	String prescriberTable = "prescriber";
	String licenseTable = "license";

	@Override
	public ControlledSubstanceRxDetailsBO getControlledSubstanceRxDetailsRepository(String storeId, String fromDate,
			String toDate) throws Exception {

		List<ControlledSubstanceRxDetailsDataBO> data = new ArrayList<ControlledSubstanceRxDetailsDataBO>();
		LOGGER.info("getControlledSubstanceRxDetailsRepository Method fromDate: {} and toDate: {} and store: {}",
				fromDate, toDate, storeId);

		LOGGER.info("Creating BigtableDataClient ..");
		try (BigtableDataClient dataClient = BigtableDataClient.create(projectId, instanceId)) {
			String from = "";
			String to = "";
			SimpleDateFormat targetFormat = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat originalFormat = new SimpleDateFormat("MM/dd/yyyy");
			from = targetFormat.format(originalFormat.parse(fromDate.split(" ")[0]));
			to = targetFormat.format(originalFormat.parse(toDate.split(" ")[0]));
			LOGGER.info("formatted input dates : " + from + " and " + to);
			String start = storeId + "#" + from;
			String end = storeId + "#" + to;

			LOGGER.info("Querying Rx bigtable with range row filter using written date");
			List<ControlledSubstanceRxBO> controlledSubstanceDetails = readRowsRx(dataClient, start, end);
			if (controlledSubstanceDetails != null) {

				LOGGER.info("Querying Patient bigtable for patient names");
				readRowsPatient(dataClient, storeId, controlledSubstanceDetails);
				if (patientdetails != null) {
					LOGGER.info("Querying DrugModel bigtable to get DrugName");
					readRowsDrugModel(dataClient, controlledSubstanceDetails);
					if (drugdetails != null) {
						LOGGER.info("Querying prescriber bigtable for prescriber names");
						readRowsPrescriber(dataClient, controlledSubstanceDetails);
						if (prescriberdetails != null) {
							LOGGER.info("Querying License bigtable to get licenseNumber");
							readRowsLicense(dataClient, controlledSubstanceDetails);
						}

					}
				}
			}
			long javaResponceAssignStart = System.currentTimeMillis();
			int i = 0;
			controlledSubstanceDetails.forEach(details -> {
				if (patientdetails != null && !patientdetails.isEmpty() && drugdetails != null && !drugdetails.isEmpty()
						&& prescriberdetails != null && !prescriberdetails.isEmpty() && licensedetails != null
						&& !licensedetails.isEmpty()) {

					if (patientdetails.containsKey(details.getPatientId())
							&& drugdetails.containsKey(details.getPrdMdsFamId())
							&& prescriberdetails.containsKey(details.getPrescriberId())
							&& licensedetails.containsKey(details.getPrescriberId())) {

						String patientInfo = "";
						String prescriberName = "";
						String patientName = "";
						String patientAddressFinal = "";
						String drugNameFinal = "";
						String licenseNumberFinal = "";
						patientInfo = patientdetails.get(details.getPatientId());
						String[] patient = patientInfo.split("#");
						patientName = patient[0];
						patientAddressFinal = patient[1];
						drugNameFinal = drugdetails.get(details.getPrdMdsFamId());
						prescriberName = prescriberdetails.get(details.getPrescriberId());
						licenseNumberFinal = licensedetails.get(details.getPrescriberId());
						ControlledSubstanceRxDetailsDataBO finalData = new ControlledSubstanceRxDetailsDataBO(
								details.getRxWrittenDate(), details.getRxNbr(), i + 1, patientName, patientAddressFinal,
								drugNameFinal, details.getRxFillQty(), details.getRxFillDaysSplyQty(),
								details.getRxExpandedSigTxt(), prescriberName, patientAddressFinal, licenseNumberFinal);
						data.add(finalData);
					}
				}

			});
			long javaResponceAssignEnd = System.currentTimeMillis();
			LOGGER.info("javaPojoAssignEnd assign to pojo class for final list and iteration time = "
					+ (javaResponceAssignEnd - javaResponceAssignStart));

		}

		catch (Exception e) {
			e.printStackTrace();
		}
		controlledSubstanceRxDetails.setData(data);

		return controlledSubstanceRxDetails;
	}

	private List<ControlledSubstanceRxBO> readRowsRx(BigtableDataClient dataClient, String start, String end) {
		List<ControlledSubstanceRxBO> controlledSubstanceDetails = new ArrayList<ControlledSubstanceRxBO>();
		long rxstart = System.currentTimeMillis();
		Query rxquery = Query.create(rxTable).range(start, end);
		ServerStream<Row> rxRows = dataClient.readRows(rxquery);
		int rowCount = 0;
		for (Row row : rxRows) {
			LOGGER.info("row details from rx table" + row.getKey().toStringUtf8());
			rowCount++;
			rxquery.rowKey(row.getKey());

			ControlledSubstanceRxBO controlledSubstanceDetail = new ControlledSubstanceRxBO();
			String rowKey = row.getKey().toStringUtf8();

			String[] keys = rowKey.split("#");
			controlledSubstanceDetail.setStoreNbr(keys[0]);
			controlledSubstanceDetail.setRxWrittenDate(keys[1]);
			controlledSubstanceDetail.setRxId(keys[2]);
			controlledSubstanceDetail.setActivityUserId(keys[3]);
			controlledSubstanceDetail.setPatientId(keys[4]);
			controlledSubstanceDetail.setPrescriberId(keys[5]);
			controlledSubstanceDetail.setPrdMdsFamId(keys[6]);
			controlledSubstanceDetail.setRxNbr(keys[7]);
			controlledSubstanceDetail.setCheckUserId(keys[8]);
			controlledSubstanceDetail.setInputId(keys[9]);

			long fillDaysSupplyQtyTs = 0;
			for (RowCell c : row.getCells("Prescription", "fillDaysSupplyQty")) {
				if (c.getTimestamp() > fillDaysSupplyQtyTs) {
					fillDaysSupplyQtyTs = c.getTimestamp();
					controlledSubstanceDetail.setRxFillDaysSplyQty(c.getValue().toStringUtf8());
				}
			}

			long fillqtyTs = 0;
			for (RowCell c : row.getCells("Prescription", "fillQty")) {
				if (c.getTimestamp() > fillqtyTs) {
					fillqtyTs = c.getTimestamp();
					controlledSubstanceDetail.setRxFillQty(c.getValue().toStringUtf8());
				}
			}

			long expandedSigTs = 0;
			for (RowCell c : row.getCells("Prescription", "expandedSig")) {
				if (c.getTimestamp() > expandedSigTs) {
					expandedSigTs = c.getTimestamp();
					controlledSubstanceDetail.setRxExpandedSigTxt(c.getValue().toStringUtf8());
				}
			}
			long statusTs = 0;
			for (RowCell c : row.getCells("Prescription", "status")) {
				if (c.getTimestamp() > statusTs) {
					statusTs = c.getTimestamp();
					controlledSubstanceDetail.setRxStatus(c.getValue().toStringUtf8());
				}
			}

			if (!"CANC".equals(controlledSubstanceDetail.getRxStatus())
					&& !"DEA".equals(controlledSubstanceDetail.getRxStatus())
					&& !"HID".equals(controlledSubstanceDetail.getRxStatus())
					&& !"BUILD".equals(controlledSubstanceDetail.getRxStatus())) {

				LOGGER.info(" -----> " + rowKey);

				controlledSubstanceDetails.add(controlledSubstanceDetail);
			}

		}
		long rxend = System.currentTimeMillis();
		LOGGER.info("rx query and iteration time = " + (rxend - rxstart));
		LOGGER.info("rx query record count = " + rowCount);
		return controlledSubstanceDetails;
	}

	private void readRowsPatient(BigtableDataClient dataClient, String storeId,
			List<ControlledSubstanceRxBO> controlledSubstanceDetails)
			throws JsonMappingException, JsonProcessingException {
		long patientstart = System.currentTimeMillis();
		Query paQuery = Query.create(patientTable);
		controlledSubstanceDetails.forEach(pa -> {
			LOGGER.info("patient ID ::: " + pa.getPatientId());
			paQuery.rowKey(storeId + "#" + pa.getPatientId());
		});
		ServerStream<Row> paRows = dataClient.readRows(paQuery);

		for (Row patient : paRows) {

			String[] rowkeyParts = patient.getKey().toStringUtf8().split("#");
			long firstNameTs = 0;
			long middleNameTs = 0;
			long lastNamTse = 0;
			long patient_addressTs = 0;
			String firstName = "", middleName = "", lastName = "";
			String patientAddress = "";
			for (RowCell cell : patient.getCells()) {
				if (cell.getQualifier().toStringUtf8().equals("firstName")) {
					if (cell.getTimestamp() > firstNameTs) {
						firstNameTs = cell.getTimestamp();
						firstName = cell.getValue().toStringUtf8();
					}
				} else if (cell.getQualifier().toStringUtf8().equals("middleName")) {
					if (cell.getTimestamp() > middleNameTs) {
						middleNameTs = cell.getTimestamp();
						middleName = cell.getValue().toStringUtf8();
					}

				} else if (cell.getQualifier().toStringUtf8().equals("lastName")) {
					if (cell.getTimestamp() > lastNamTse) {
						lastNamTse = cell.getTimestamp();
						lastName = cell.getValue().toStringUtf8();
					}

				} else if (cell.getQualifier().toStringUtf8().equals("hw_patient_address")) {
					if (cell.getTimestamp() > patient_addressTs) {
						patient_addressTs = cell.getTimestamp();
						patientAddress = cell.getValue().toStringUtf8();
					}

				}
			}
			String addressLine1 = "";
			String cityName = "";
			String stateProvCode = "";
			String postalCode = "";
			if (patientAddress != null && !patientAddress.isEmpty()) {
				LOGGER.info("patientAddress details::" + patientAddress);
				ObjectMapper mapper = new ObjectMapper();
				List<JsonNode> patientAddressList = mapper.readValue(patientAddress,
						mapper.getTypeFactory().constructCollectionType(List.class, JsonNode.class));
				if (!patientAddressList.isEmpty()) {
					addressLine1 = patientAddressList.get(0).get("addressLine1").asText();
					cityName = patientAddressList.get(0).get("cityName").asText();
					stateProvCode = patientAddressList.get(0).get("stateProvCode").asText();
					stateProvCode = patientAddressList.get(0).get("postalCode").asText();
				}
			}
			patientdetails.put(rowkeyParts[1], lastName + "," + firstName + " " + middleName + "#" + addressLine1 + "- "
					+ cityName + "- " + stateProvCode + "- " + postalCode);
			LOGGER.info("patientinfo::" + patientdetails);
		}
		long patientend = System.currentTimeMillis();
		LOGGER.info("patient query and iteration time = " + (patientend - patientstart));
	}

	private void readRowsDrugModel(BigtableDataClient dataClient,
			List<ControlledSubstanceRxBO> controlledSubstanceDetails) {
		long drugmodelstart = System.currentTimeMillis();
		InterleaveFilter drugFilter = FILTERS.interleave();
		controlledSubstanceDetails.forEach(pp -> {
			LOGGER.info("ProductMdsFamId ID ::: " + pp.getPrdMdsFamId());
			drugFilter.filter(FILTERS.key().regex("^.+#" + pp.getPrdMdsFamId() + "$"));
		});
		Query drugQuery = Query.create(drugTable).filter(drugFilter);
		ServerStream<Row> drugRows = dataClient.readRows(drugQuery);
		for (Row drug : drugRows) {
			String[] rowkeyParts = drug.getKey().toStringUtf8().split("#");
			long drugControlCodeTs = 0;
			String drugControlCode = "";
			long drugnameTs = 0;
			String drugname = "";

			for (RowCell cell : drug.getCells()) {
				if (cell.getQualifier().toStringUtf8().equals("shortName")) {
					if (cell.getTimestamp() > drugnameTs) {
						drugnameTs = cell.getTimestamp();
						drugname = cell.getValue().toStringUtf8();
						LOGGER.info("drugname  ::: " + drugname);
					}
				} else if (cell.getQualifier().toStringUtf8().equals("drugControlCode")) {
					if (cell.getTimestamp() > drugControlCodeTs) {
						drugControlCodeTs = cell.getTimestamp();
						drugControlCode = cell.getValue().toStringUtf8();
						LOGGER.info("drugControlCode  ::: " + drugControlCode);
					}

				}
			}
			if ("2300".equals(drugControlCode) || "2301".equals(drugControlCode) || "2302".equals(drugControlCode)
					|| "2303".equals(drugControlCode)) {
				drugdetails.put(rowkeyParts[1], drugname);

			}
		}
		long drugmodelend = System.currentTimeMillis();
		LOGGER.info("drugModel query and iteration time = " + (drugmodelend - drugmodelstart));
		LOGGER.info("drugdetails  ::" + drugdetails.toString());
	}

	private void readRowsPrescriber(BigtableDataClient dataClient,
			List<ControlledSubstanceRxBO> controlledSubstanceDetails) {
		long prescriberstart = System.currentTimeMillis();
		Query prescriberQuery = Query.create(prescriberTable);
		controlledSubstanceDetails.forEach(prescriber -> {
			LOGGER.info("prescriber ID ::: " + prescriber.getPrescriberId());
			prescriberQuery.rowKey(prescriber.getPrescriberId());
		});
		ServerStream<Row> prescriberRows = dataClient.readRows(prescriberQuery);

		for (Row prescriber : prescriberRows) {
			long firstNameTs = 0;
			long middleNameTs = 0;
			long lastNameTs = 0;
			String firstName = "", middleName = "", lastName = "";
			for (RowCell cell : prescriber.getCells()) {
				if (cell.getQualifier().toStringUtf8().equals("firstName")) {
					if (cell.getTimestamp() > firstNameTs) {
						firstNameTs = cell.getTimestamp();
						firstName = cell.getValue().toStringUtf8();
					}
				} else if (cell.getQualifier().toStringUtf8().equals("middleName")) {
					if (cell.getTimestamp() > middleNameTs) {
						middleNameTs = cell.getTimestamp();
						middleName = cell.getValue().toStringUtf8();
					}

				} else if (cell.getQualifier().toStringUtf8().equals("lastName")) {
					if (cell.getTimestamp() > lastNameTs) {
						lastNameTs = cell.getTimestamp();
						lastName = cell.getValue().toStringUtf8();
					}

				}

			}
			prescriberdetails.put(prescriber.getKey().toStringUtf8(), lastName + "," + firstName + " " + middleName);
			LOGGER.info("prescriber ::: " + prescriber.getKey().toStringUtf8() + " - " + firstName + " " + middleName
					+ " " + lastName);
		}
		long prescriberend = System.currentTimeMillis();
		LOGGER.info("prescriber query and iteration time = " + (prescriberend - prescriberstart));
		LOGGER.info("prescriberdetails  ::" + prescriberdetails.toString());
	}

	private void readRowsLicense(BigtableDataClient dataClient,
			List<ControlledSubstanceRxBO> controlledSubstanceDetails) {
		long licensestart = System.currentTimeMillis();
		Query licenseQuery = Query.create(licenseTable);
		controlledSubstanceDetails.forEach(license -> {
			LOGGER.info("license prescriber ID ::: " + license.getPrescriberId());
			licenseQuery.rowKey(license.getPrescriberId());
		});
		ServerStream<Row> licenseRows = dataClient.readRows(licenseQuery);
		for (Row license : licenseRows) {
			long licensenumberTs = 0;
			long licenseTypeTs = 0;
			long statusCodeTs = 0;
			String licensenumber = "";
			String licenseType = "";
			String statusCode = "";

			for (RowCell cell : license.getCells()) {
				if (cell.getQualifier().toStringUtf8().equals("licenseNumber")) {
					if (cell.getTimestamp() > licensenumberTs) {
						licensenumberTs = cell.getTimestamp();
						licensenumber = cell.getValue().toStringUtf8();
					}
				} else if (cell.getQualifier().toStringUtf8().equals("licenseType")) {
					if (cell.getTimestamp() > licenseTypeTs) {
						licenseTypeTs = cell.getTimestamp();
						licenseType = cell.getValue().toStringUtf8();
					}

				} else if (cell.getQualifier().toStringUtf8().equals("statusCode")) {
					if (cell.getTimestamp() > statusCodeTs) {
						statusCodeTs = cell.getTimestamp();
						statusCode = cell.getValue().toStringUtf8();
					}

				}
			}
			if ("800".equals(licenseType) && "20006".equals(statusCode)) {
				licensedetails.put(license.getKey().toStringUtf8(), licensenumber);
			}

		}
		long licenseend = System.currentTimeMillis();
		LOGGER.info("license query and iteration time = " + (licenseend - licensestart));
		LOGGER.info("licensedetails  ::" + licensedetails.toString());
	}

	@PostConstruct
	public void setHeaderValues() {

		String storeId = "5666";
		String appName = "Connexus Pharmacy System";
		String store = "Wal-Mart Pharmacy10-5666";
		String reportName = "Controlled Substance Rx Details Report";
		List<ControlledSubstanceStoreDetailsBO> storeDetails = new ArrayList<>();
		List<HeaderBO> header = new ArrayList<>();
		List<ControlledSubstanceRxDetailsDataBO> data = new ArrayList<>();

		controlledSubstanceRxDetails = new ControlledSubstanceRxDetailsBO(storeDetails, header, data);

		storeDetails.add(new ControlledSubstanceStoreDetailsBO(storeId, appName, store, reportName));
		header.add(new HeaderBO("Rx Issue Date", "rxIssueDate"));
		header.add(new HeaderBO("Rx Number", "rxNbr"));
		header.add(new HeaderBO("Patient Name - Patient Address", "patientInfo"));
		header.add(new HeaderBO("Drug Name", "drugName"));
		header.add(new HeaderBO("Quantity Prescribed", "quantity"));
		header.add(new HeaderBO("Days Supply", "supply"));
		header.add(new HeaderBO("Sig", "sig"));
		header.add(new HeaderBO("Practioner Name - Practioner Address - DEA", "prescriberInfo"));
	}

}
