/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report API team, Primary :Srilekha Kothapally(vn5101f)
 * Date: 2020/10/14
 * Version: 0.1
 * Description: This DAO Interface class is used to declare the methods for
 * AmberVial Inventory DAO layer implementation
 * TABLES: rts_vial, pharmacy_item, pharmacy_product, pharmacy_offering:phm_item_cost, rts_vial_status_txt,rx_fill_item
 * The output is written to
 * 1. Request and Responses are generated in the JSON Format
 * 2. Informix and CosMos DB tables which is primarily used for Reports
 * 
 */
package com.walmart.reportsapi.repository;

import com.walmart.reportsapi.bo.returntostockreports.AmberVialInventoryActivityBO;
import com.walmart.reportsapi.exception.ReportApiServiceException;

public interface ReturnToStockReportsDao {

	AmberVialInventoryActivityBO getAmberVialInventoryReport(String fromDate, String toDate, Integer storeId,
			Integer reportOption, Integer fromVialId, Integer toVialId) throws ReportApiServiceException;
}
