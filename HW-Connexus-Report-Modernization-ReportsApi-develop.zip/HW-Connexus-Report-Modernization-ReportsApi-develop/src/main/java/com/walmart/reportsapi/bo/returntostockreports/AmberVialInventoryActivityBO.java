package com.walmart.reportsapi.bo.returntostockreports;

import java.util.List;

import com.walmart.reportsapi.bo.audit.ControlledSubstanceStoreDetailsBO;
import com.walmart.reportsapi.bo.audit.HeaderBO;

public class AmberVialInventoryActivityBO {

	private List<AmberVialInventoryStoreDetailsBO> storeDetails;
	private List<HeaderBO> header;
	private List<AmberVialInventoryDataBO> data;

	public AmberVialInventoryActivityBO() {
		super();

	}

	public AmberVialInventoryActivityBO(List<AmberVialInventoryStoreDetailsBO> storeDetails, List<HeaderBO> header,
			List<AmberVialInventoryDataBO> data) {
		super();
		this.storeDetails = storeDetails;
		this.header = header;
		this.data = data;
	}

	public List<AmberVialInventoryStoreDetailsBO> getStoreDetails() {
		return storeDetails;
	}

	public void setStoreDetails(List<AmberVialInventoryStoreDetailsBO> storeDetails) {
		this.storeDetails = storeDetails;
	}

	public List<HeaderBO> getHeader() {
		return header;
	}

	public void setHeader(List<HeaderBO> header) {
		this.header = header;
	}

	public List<AmberVialInventoryDataBO> getData() {
		return data;
	}

	public void setData(List<AmberVialInventoryDataBO> data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "AmberVialInventoryActivityBO [storeDetails=" + storeDetails + ", header=" + header + ", data=" + data
				+ ", getStoreDetails()=" + getStoreDetails() + ", getHeader()=" + getHeader() + ", getData()="
				+ getData() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}

}