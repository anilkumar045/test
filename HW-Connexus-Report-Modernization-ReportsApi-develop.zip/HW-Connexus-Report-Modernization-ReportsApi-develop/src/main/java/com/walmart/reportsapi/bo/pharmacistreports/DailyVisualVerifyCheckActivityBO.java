package com.walmart.reportsapi.bo.pharmacistreports;

import java.util.List;

import com.walmart.reportsapi.bo.StoreDetailsBO;
import com.walmart.reportsapi.bo.audit.HeaderBO;

public class DailyVisualVerifyCheckActivityBO {

	private StoreDetailsBO storeDetails;
	private List<HeaderBO> header;
	private List<DailyVisualVerifyCheckDatesBO> dates;

	public DailyVisualVerifyCheckActivityBO() {
		super();

	}

	public DailyVisualVerifyCheckActivityBO(StoreDetailsBO storeDetails, List<HeaderBO> header, List<DailyVisualVerifyCheckDatesBO> dates) {
		super();
		
		this.storeDetails = storeDetails;
		this.header = header;
		this.dates = dates;
	}
	
	public StoreDetailsBO getStoreDetails() {
		return storeDetails;
	}

	public void setStoreDetails(StoreDetailsBO storeDetails) {
		this.storeDetails = storeDetails;
	}

	
	public List<HeaderBO> getHeader() {
		return header;
	}

	public void setHeader(List<HeaderBO> header) {
		this.header = header;
	}

	public List<DailyVisualVerifyCheckDatesBO> getDates() {
		return dates;
	}

	public void setDates(List<DailyVisualVerifyCheckDatesBO> dates) {
		this.dates = dates;
	}

	

}
