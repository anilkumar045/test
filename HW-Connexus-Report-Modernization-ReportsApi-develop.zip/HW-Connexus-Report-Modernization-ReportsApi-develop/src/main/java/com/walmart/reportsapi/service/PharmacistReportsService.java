/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report API team, Primary :Arjun(vn506kd)
 * Date: 2020/12/31
 * Version: 0.2
 * Description: This Service class is responsible for getting  the Four Point Check
 * report details based on input request parameters from the big data tables
 * TABLES: rxDec, patient_DEC, fill_December, DrugModel
 * The output is written to
 * 1. Request and Responses are generated in the JSON Format
 * 2. Big Table tables which is primarily used for Reports
 * 
 */
package com.walmart.reportsapi.service;


import com.walmart.reportsapi.bo.pharmacistreports.DailyVisualVerifyCheckActivityBO;
import com.walmart.reportsapi.bo.pharmacistreports.FourPointCheckActivityBO;
import com.walmart.reportsapi.bo.pharmacistreports.PharmacistActivityReportBO;
import com.walmart.reportsapi.exception.ReportApiServiceException;

/**
 * The 4point check Service Interface class is used to declare the methods for
 * service layer implementation
 */
public interface PharmacistReportsService {

	FourPointCheckActivityBO getFourPointCheckActivityService(String storeId, String fromDate, String toDate) throws ReportApiServiceException;
	public PharmacistActivityReportBO getPharmacistActivityReportService(String storeId, String activityDate, String userName) throws ReportApiServiceException;
	public DailyVisualVerifyCheckActivityBO getDailyVisualVerifyReport(String storeId, String activityDate, String userName) throws ReportApiServiceException;

}
