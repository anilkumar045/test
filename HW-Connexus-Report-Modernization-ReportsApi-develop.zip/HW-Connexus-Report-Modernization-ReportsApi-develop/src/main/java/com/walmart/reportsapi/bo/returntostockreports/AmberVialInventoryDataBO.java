package com.walmart.reportsapi.bo.returntostockreports;

public class AmberVialInventoryDataBO {
	private Integer vialId;
	private String ndc;
	private String drugDescription;
	private String originalQuantity;
	private String originalCost;
	private String currentQuantity;
	private String createDate;
	private String expirationDate;
	private String userId;
	private String timeStamp;
	private String status;

	public AmberVialInventoryDataBO() {
		super();
	}

	public AmberVialInventoryDataBO(Integer vialId, String ndc, String drugDescription, String originalQuantity,
			String originalCost, String currentQuantity, String createDate, String expirationDate, String userId,
			String timeStamp, String status) {
		super();
		this.vialId = vialId;
		this.ndc = ndc;
		this.drugDescription = drugDescription;
		this.originalQuantity = originalQuantity;
		this.originalCost = originalCost;
		this.currentQuantity = currentQuantity;
		this.createDate = createDate;
		this.expirationDate = expirationDate;
		this.userId = userId;
		this.timeStamp = timeStamp;
		this.status = status;
	}

	public Integer getVialId() {
		return vialId;
	}

	public void setVialId(Integer vialId) {
		this.vialId = vialId;
	}

	public String getNdc() {
		return ndc;
	}

	public void setNdc(String ndc) {
		this.ndc = ndc;
	}

	public String getDrugDescription() {
		return drugDescription;
	}

	public void setDrugDescription(String drugDescription) {
		this.drugDescription = drugDescription;
	}

	public String getOriginalQuantity() {
		return originalQuantity;
	}

	public void setOriginalQuantity(String originalQuantity) {
		this.originalQuantity = originalQuantity;
	}

	public String getOriginalCost() {
		return originalCost;
	}

	public void setOriginalCost(String originalCost) {
		this.originalCost = originalCost;
	}

	public String getCurrentQuantity() {
		return currentQuantity;
	}

	public void setCurrentQuantity(String currentQuantity) {
		this.currentQuantity = currentQuantity;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "AmberVialDataBO [vialId=" + vialId + ", ndc=" + ndc + ", drugDescription=" + drugDescription
				+ ", originalQuantity=" + originalQuantity + ", originalCost=" + originalCost + ", currentQuantity="
				+ currentQuantity + ", createDate=" + createDate + ", expirationDate=" + expirationDate + ", userId="
				+ userId + ", timeStamp=" + timeStamp + ", status=" + status + ", getVialId()=" + getVialId()
				+ ", getNdc()=" + getNdc() + ", getDrugDescription()=" + getDrugDescription()
				+ ", getOriginalQuantity()=" + getOriginalQuantity() + ", getOriginalCost()=" + getOriginalCost()
				+ ", getCurrentQuantity()=" + getCurrentQuantity() + ", getCreateDate()=" + getCreateDate()
				+ ", getExpirationDate()=" + getExpirationDate() + ", getUserId()=" + getUserId() + ", getTimeStamp()="
				+ getTimeStamp() + ", getStatus()=" + getStatus() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}
}