package com.walmart.reportsapi.bo.pharmacistreports;

import java.util.List;

public class DailyVisualVerifyCheckDatesBO {

	private String date;

	private List<DailyVisualVerifyCheckPharmacistBO> pharmacists;

	public DailyVisualVerifyCheckDatesBO(String date, List<DailyVisualVerifyCheckPharmacistBO> pharmacists) {
		super();
		this.date = date;
		this.pharmacists = pharmacists;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public List<DailyVisualVerifyCheckPharmacistBO> getPharmacists() {
		return pharmacists;
	}

	public void setPharmacists(List<DailyVisualVerifyCheckPharmacistBO> pharmacists) {
		this.pharmacists = pharmacists;
	}


}
