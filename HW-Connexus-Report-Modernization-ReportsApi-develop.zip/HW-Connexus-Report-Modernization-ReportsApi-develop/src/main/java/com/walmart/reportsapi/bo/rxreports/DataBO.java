package com.walmart.reportsapi.bo.rxreports;

public class DataBO {
	
	private String rxNbr;
	private Integer unique;
	private String fillNbr;
	private String storeNbr;
	private String userid;
	private String activityDate;
	private String station;
	private String username;
	
	
	public DataBO() {
		super();
		
	}
	public DataBO(String rxNbr, Integer unique, String fillNbr, String storeNbr, String userid, String activityDate,
			String station, String username) {
		super();
		this.rxNbr = rxNbr;
		this.unique = unique;
		this.fillNbr = fillNbr;
		this.storeNbr = storeNbr;
		this.userid = userid;
		this.activityDate = activityDate;
		this.station = station;
		this.username = username;
	}
	public String getRxNbr() {
		return rxNbr;
	}
	public void setRxNbr(String rxNbr) {
		this.rxNbr = rxNbr;
	}
	public Integer getUnique() {
		return unique;
	}
	public void setUnique(Integer unique) {
		this.unique = unique;
	}
	public String getFillNbr() {
		return fillNbr;
	}
	public void setFillNbr(String fillNbr) {
		this.fillNbr = fillNbr;
	}
	public String getStoreNbr() {
		return storeNbr;
	}
	public void setStoreNbr(String storeNbr) {
		this.storeNbr = storeNbr;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getActivityDate() {
		return activityDate;
	}
	public void setActivityDate(String activityDate) {
		this.activityDate = activityDate;
	}
	public String getStation() {
		return station;
	}
	public void setStation(String station) {
		this.station = station;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	@Override
	public String toString() {
		return "DataBO [rxNbr=" + rxNbr + ", unique=" + unique + ", fillNbr=" + fillNbr + ", storeNbr=" + storeNbr
				+ ", userid=" + userid + ", activityDate=" + activityDate + ", station=" + station + ", username="
				+ username + ", getRxNbr()=" + getRxNbr() + ", getUnique()=" + getUnique() + ", getFillNbr()="
				+ getFillNbr() + ", getStoreNbr()=" + getStoreNbr() + ", getUserid()=" + getUserid()
				+ ", getActivityDate()=" + getActivityDate() + ", getStation()=" + getStation() + ", getUsername()="
				+ getUsername() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
		

}
