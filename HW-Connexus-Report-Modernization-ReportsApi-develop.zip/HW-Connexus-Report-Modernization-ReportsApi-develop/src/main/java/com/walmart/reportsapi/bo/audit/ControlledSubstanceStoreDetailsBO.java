package com.walmart.reportsapi.bo.audit;

public class ControlledSubstanceStoreDetailsBO {
	
	private String storeId;
	private String appName;
	private String store;
	private String reportName;

	public ControlledSubstanceStoreDetailsBO() {
		super();
		
	}

	public ControlledSubstanceStoreDetailsBO(String storeId, String appName, String store, String reportName) {
		super();
		this.storeId = storeId;
		this.appName = appName;
		this.store = store;
		this.reportName = reportName;
	}

	public String getStoreId() {
		return storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getStore() {
		return store;
	}

	public void setStore(String store) {
		this.store = store;
	}

	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	@Override
	public String toString() {
		return "ControlledSubstanceStoreDetailsBO [storeId=" + storeId + ", appName=" + appName + ", store=" + store
				+ ", reportName=" + reportName + "]";
	}

}
