/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report API team, Primary :Arjun(vn506kd)
 * Date: 2020/12/31
 * Version: 0.2
 * Description: This DAOImpl class is responsible for getting  the Four Point Check
 * report details based on input request parameters from the big data tables
 * TABLES: rxDec, patient_DEC, fill_December, DrugModel
 * The output is written to
 * 1. Request and Responses are generated in the JSON Format
 * 2. Big Table tables which is primarily used for Reports
 * 
 */
package com.walmart.reportsapi.repository.impl.pharmacistreports;

import static com.google.cloud.bigtable.data.v2.models.Filters.FILTERS;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.gax.rpc.ServerStream;
import com.google.cloud.bigtable.data.v2.BigtableDataClient;
import com.google.cloud.bigtable.data.v2.models.Filters.ChainFilter;
import com.google.cloud.bigtable.data.v2.models.Filters.InterleaveFilter;
import com.google.cloud.bigtable.data.v2.models.Query;
import com.google.cloud.bigtable.data.v2.models.Row;
import com.google.cloud.bigtable.data.v2.models.RowCell;
import com.walmart.reportsapi.bo.audit.HeaderBO;
import com.walmart.reportsapi.bo.pharmacistreports.FourPointCheckActivityBO;
import com.walmart.reportsapi.bo.pharmacistreports.FourPointCheckBO;
import com.walmart.reportsapi.bo.pharmacistreports.FourPointCheckDataBO;
import com.walmart.reportsapi.bo.pharmacistreports.FourPointCheckDatesBO;
import com.walmart.reportsapi.bo.pharmacistreports.FourPointCheckPharmacistBO;
import com.walmart.reportsapi.bo.pharmacistreports.FourPointCheckStoreDetailsBO;
import com.walmart.reportsapi.repository.PharmacistReportsDao;

/**
 * FourPointCheck DAO implementation class is used get the 4 point check report
 * details based on input request parameters from BigTable
 */
@Repository("fourPointCheckDAO")
public class FourPointCheckDaoImpl implements PharmacistReportsDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(FourPointCheckDaoImpl.class);

	String projectId = "wmt-hnw-techmod-poc";
	String instanceId = "hnw-conx-poc";
	String rxaTableId = "rxDec";
	String paTableId = "patient_DEC";
	String rxfTableId = "fill_December";
	String ppTableId = "DrugModel";

	/**
	 * This method is used get the 4 Point check report details based on fromDate
	 * and toDate
	 * 
	 * @param fromDate
	 * @param toDate
	 * @return FourPtCheckActivityBO
	 */

	@Override
	public FourPointCheckActivityBO getFourPointCheckActivityRepository(String storeId, String fromDate,
			String toDate) {

		LOGGER.info("getfourptactivity:Entered Method fromDate: {} and toDate: {} and store: {}", fromDate, toDate,
				storeId);

		FourPointCheckActivityBO fourPtCheckActivity = getHardcodedResponse();
		String from = "";
		String to = "";

		LOGGER.info("Creating BigtableDataClient ..");
		try (BigtableDataClient dataClient = BigtableDataClient.create(projectId, instanceId)) {

			SimpleDateFormat targetFormat = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat originalFormat = new SimpleDateFormat("MM/dd/yyyy");

			from = targetFormat.format(originalFormat.parse(fromDate.split(" ")[0])) + " 00:00:00";
			to = targetFormat.format(originalFormat.parse(toDate.split(" ")[0])) + " 23:59:59";
			LOGGER.info("formatted input dates : " + from + " and " + to);

			LOGGER.info("Querying Rx bigtable using rowkey range");

			List<FourPointCheckBO> fourPtActivities = readRowsRx(dataClient, from, to, storeId);

			List<FourPointCheckBO> maxFourPtActivities = new ArrayList<FourPointCheckBO>();

			Map<String, FourPointCheckBO> maxFourPtActivitiesMapWithFillData = new HashMap<String, FourPointCheckBO>();

			if (fourPtActivities != null) {
				long rxfilterstart = System.currentTimeMillis();
				LOGGER.info("Grouping result by rxId and keeping only records having latest activity sequence number");
				for (List<FourPointCheckBO> activitiesForRxId : fourPtActivities.stream()
						.collect(Collectors.groupingBy(a -> a.getRxId())).values()) {
					maxFourPtActivities.add(activitiesForRxId.get(activitiesForRxId.size() - 1));
				}
				long rxfilterend = System.currentTimeMillis();
				LOGGER.info(" !!!!! rx filtering time = " + (rxfilterend - rxfilterstart));
				LOGGER.info("rx filtered records count = " + maxFourPtActivities.size());

				LOGGER.info("Querying Patient bigtable for patient names");
				Map<String, String> patientNames = readRowsPatient(dataClient, maxFourPtActivities);

				long patientfilterstart = System.currentTimeMillis();
				Map<String, List<FourPointCheckBO>> patientRxMap = maxFourPtActivities.stream()
						.collect(Collectors.groupingBy(a -> a.getPatientId()));
				maxFourPtActivities = new ArrayList<FourPointCheckBO>();
				for (String patientId : patientRxMap.keySet()) {
					if (patientNames.containsKey(patientId)) {
						for (FourPointCheckBO rx : patientRxMap.get(patientId)) {
							rx.setPatientName(patientNames.get(rx.getPatientId()));
							maxFourPtActivities.add(rx);
						}
					}
				}
				long patientfilterend = System.currentTimeMillis();
				LOGGER.info(" !!!!! patient filtering time = " + (patientfilterend - patientfilterstart));

				LOGGER.info("Querying rx_fill bigtable for fill and fill item details");
				maxFourPtActivitiesMapWithFillData = readRowsRxFillDouble(dataClient, storeId, maxFourPtActivities);
			}

			List<FourPointCheckBO> finalReportList = readRowsDrugModel(dataClient, maxFourPtActivitiesMapWithFillData);

			long postprocessstart = System.currentTimeMillis();
			LOGGER.info(" !!!!! Final activites count = " + finalReportList.size());
			LOGGER.info("Formatting date strings");
			finalReportList.forEach(r -> {
				String activityTs = r.getActivityTs();
				String datestr = activityTs.split(" ")[0];
				r.setActivityTime(activityTs.split(" ")[1]);

				Date date = null;
				try {
					date = targetFormat.parse(datestr);
				} catch (ParseException e) {
					e.printStackTrace();
				}
				String formattedDate = originalFormat.format(date);
				r.setActivityDate(formattedDate);
			});
			LOGGER.info("Mapping record list to response BO");
			List<FourPointCheckDatesBO> dates = new ArrayList<FourPointCheckDatesBO>();
			for (Map.Entry<String, List<FourPointCheckBO>> dateEntry : finalReportList.stream()
					.collect(Collectors.groupingBy(r -> r.getActivityDate())).entrySet()) {
				List<FourPointCheckPharmacistBO> pharmacists = new ArrayList<FourPointCheckPharmacistBO>();
				for (Map.Entry<String, List<FourPointCheckBO>> pharmacistEntry : dateEntry.getValue().stream()
						.collect(Collectors.groupingBy(x -> x.getCheckUserId())).entrySet()) {
					List<FourPointCheckDataBO> datas = new ArrayList<FourPointCheckDataBO>();
					for (FourPointCheckBO record : pharmacistEntry.getValue()) {
						datas.add(new FourPointCheckDataBO(record.getRxNbr(), record.getPatientName(),
								record.getFillDate(), record.getProductName(), record.getFillQty(), record.getDawCode(),
								record.getCheckUserId().trim(),
								record.getActivityDate() + " " + record.getActivityTime()));
					}
					pharmacists.add(new FourPointCheckPharmacistBO(pharmacistEntry.getKey(), datas));
				}
				dates.add(new FourPointCheckDatesBO(dateEntry.getKey(), pharmacists));
			}
			LOGGER.info("Sorting response based on fill date and pharmacist name");
			dates.sort(Comparator.comparing(FourPointCheckDatesBO::getDate));
			dates.forEach(d -> {
				d.getPharmacists().sort(Comparator.comparing(FourPointCheckPharmacistBO::getPharmacistName));
			});
			long postprocessend = System.currentTimeMillis();
			LOGGER.info(
					" !!!!! Formatting, response mapping and sorting time = " + (postprocessend - postprocessstart));

			fourPtCheckActivity.setDates(dates);
			fourPtCheckActivity.getStoreDetails().setStoreNumber(Integer.parseInt(storeId));
			LOGGER.info("completed");

		}

		catch (Exception e) {
			e.printStackTrace();
		}
		return fourPtCheckActivity;
	}

	private List<FourPointCheckBO> readRowsRx(BigtableDataClient dataClient, String from, String to, String storeId) {

		List<FourPointCheckBO> fourPtActivities = new ArrayList<FourPointCheckBO>();
		Query rxaQuery = Query.create(rxaTableId).range(storeId + "#" + from + "#", storeId + "#" + to + "#")
				.limit(750);

		long rxBTstart = System.currentTimeMillis();
		ServerStream<Row> rxaRows = dataClient.readRows(rxaQuery);
		long rxBTend = System.currentTimeMillis();
		LOGGER.info(" !!!!! rx dataClient.readRows = " + (rxBTend - rxBTstart));

		long rxstart = System.currentTimeMillis();
		int rowCount = 0;
		for (Row r : rxaRows) {
			rowCount++;

			FourPointCheckBO rxa = new FourPointCheckBO();

			long typeTs = 0;
			for (RowCell c : r.getCells("RxActivity", "type")) {
				if (c.getTimestamp() > typeTs) {
					typeTs = c.getTimestamp();
					rxa.setActivityType(c.getValue().toStringUtf8());
				}
			}
			if (!"4PNTCHEK".equals(rxa.getActivityType()))
				continue;

			long statusTs = 0;
			for (RowCell c : r.getCells("Prescription", "status")) {
				if (c.getTimestamp() > statusTs) {
					statusTs = c.getTimestamp();
					rxa.setRxStatus(c.getValue().toStringUtf8());
				}
			}
			if (!rxa.getRxStatus().equals("ACTIVE") && !rxa.getRxStatus().equals("ON_HOLD"))
				continue;

			String[] rowkeyParts = r.getKey().toStringUtf8().split("#");
			rxa.setStoreNbr(rowkeyParts[0]);
			rxa.setRxNbr(rowkeyParts[7]);
			rxa.setRxId(rowkeyParts[2]);
			rxa.setPatientId(rowkeyParts[4]);
			rxa.setCheckUserId(rowkeyParts[8]);
			if (rxa.getCheckUserId() == null || rxa.getCheckUserId() == "")
				continue;
			rxa.setActivityUserId(rowkeyParts[3]);
			rxa.setActivityTs(rowkeyParts[1]);
			fourPtActivities.add(rxa);
		}
		long rxend = System.currentTimeMillis();
		LOGGER.info(" !!!!! rx query and iteration time = " + (rxend - rxstart));
		LOGGER.info("rx query record count = " + rowCount);
		return fourPtActivities;
	}

	private Map<String, String> readRowsPatient(BigtableDataClient dataClient,
			List<FourPointCheckBO> maxFourPtActivities) {
		Map<String, String> patientNames = new HashMap<String, String>();

		long pidstart = System.currentTimeMillis();
		InterleaveFilter paFilter = FILTERS.interleave();
		maxFourPtActivities.stream().map(rx -> rx.getPatientId()).collect(Collectors.toSet()).forEach(pid -> {
			paFilter.filter(FILTERS.key().regex("^.+#" + pid + "$"));
		});
		long pidend = System.currentTimeMillis();
		LOGGER.info(" !!!!! collecting patient id = " + (pidend - pidstart));

		Query paQuery = Query.create(paTableId).filter(paFilter);
		if (!maxFourPtActivities.isEmpty()) {

			long paBTstart = System.currentTimeMillis();
			ServerStream<Row> paRows = dataClient.readRows(paQuery);
			long paBTend = System.currentTimeMillis();
			LOGGER.info(" !!!!! patient dataClient.readRows = " + (paBTend - paBTstart));

			long patientstart = System.currentTimeMillis();
			for (Row patient : paRows) {
				String[] rowkeyParts = patient.getKey().toStringUtf8().split("#");
				String firstName = "";
				long firstNameTs = 0;
				for (RowCell c : patient.getCells("patient", "firstName")) {
					if (c.getTimestamp() > firstNameTs) {
						firstNameTs = c.getTimestamp();
						firstName = c.getValue().toStringUtf8();
					}
				}
				String middleName = "";
				long middleNameTs = 0;
				for (RowCell c : patient.getCells("patient", "middleName")) {
					if (c.getTimestamp() > middleNameTs) {
						middleNameTs = c.getTimestamp();
						middleName = c.getValue().toStringUtf8();
					}
				}
				String lastName = "";
				long lastNameTs = 0;
				for (RowCell c : patient.getCells("patient", "lastName")) {
					if (c.getTimestamp() > lastNameTs) {
						lastNameTs = c.getTimestamp();
						lastName = c.getValue().toStringUtf8();
					}
				}
				patientNames.put(rowkeyParts[1], lastName + ", " + firstName + " " + middleName);
			}
			long patientend = System.currentTimeMillis();
			LOGGER.info(" !!!!! patient query and iteration time = " + (patientend - patientstart));
		}
		LOGGER.info(" patient names >>> " + patientNames.toString());
		return patientNames;
	}

	private Map<String, FourPointCheckBO> readRowsRxFillDouble(BigtableDataClient dataClient, String storeId,
			List<FourPointCheckBO> maxFourPtActivities) throws JsonMappingException, JsonProcessingException {
		Map<String, FourPointCheckBO> maxFourPtActivitiesMapWithFillData = new HashMap<String, FourPointCheckBO>();

		long rxf1BTstart = System.currentTimeMillis();
		Map<String, FourPointCheckBO> maxFourPtActivitiesMap = maxFourPtActivities.stream()
				.collect(Collectors.toMap(FourPointCheckBO::getRxId, obj -> obj));
		Query rxfQuery = Query.create(rxfTableId);
		for (String id : maxFourPtActivitiesMap.keySet()) {
			rxfQuery.prefix(storeId + "#" + id + "#");
		}
		ChainFilter rxfStatusFilter = FILTERS.chain().filter(FILTERS.qualifier().exactMatch("status"))
				.filter(FILTERS.value().exactMatch("ACTIVE"));
		rxfQuery.filter(rxfStatusFilter);
		if (!maxFourPtActivitiesMap.isEmpty()) {

			ServerStream<Row> rxfRows = dataClient.readRows(rxfQuery);
			long rxf1BTend = System.currentTimeMillis();
			LOGGER.info(" !!!!! rx_fill (1) dataClient.readRows = " + (rxf1BTend - rxf1BTstart));

			long rxf1start = System.currentTimeMillis();
			rxfQuery = Query.create(rxfTableId);
			Set<String> temp = new HashSet<String>();
			int rxf1count = 0;
			int fillcount = 0;
			for (Row r : rxfRows) {
				++rxf1count;
				String[] rowkeyParts = r.getKey().toStringUtf8().split("#");
				String rxId = rowkeyParts[1];
				if (!temp.contains(rxId)) {
					++fillcount;
					rxfQuery.rowKey(r.getKey().toStringUtf8());
					temp.add(rxId);
				}
			}
			long rxf1end = System.currentTimeMillis();
			LOGGER.info(" !!!!! rx_fill (1) query and iteration time = " + (rxf1end - rxf1start));
			LOGGER.info(" !!!!! rx_fill (1) query iteration count = " + rxf1count);
			LOGGER.info(" !!!!! rx_fill (1) query filtered fill count = " + fillcount);

			int rxf2count = 0;
			long rxf2BTstart = System.currentTimeMillis();
			rxfRows = dataClient.readRows(rxfQuery);
			long rxf2BTend = System.currentTimeMillis();
			LOGGER.info(" !!!!! rx_fill (2) dataClient.readRows = " + (rxf2BTend - rxf2BTstart));

			long rxf2start = System.currentTimeMillis();
			for (Row r : rxfRows) {
				++rxf2count;
				String[] rowkeyParts = r.getKey().toStringUtf8().split("#");
				String rxId = rowkeyParts[1];
				if (!maxFourPtActivitiesMapWithFillData.containsKey(rxId)) {

					String statusCode = "";
					long statusTs = 0;
					for (RowCell c : r.getCells("Fill", "status")) {
						if (c.getTimestamp() > statusTs) {
							statusTs = c.getTimestamp();
							statusCode = c.getValue().toStringUtf8();
						}
					}
					if (statusCode == "CANCELED")
						continue;

					String rxFillId = rowkeyParts[3];
					String fillDate = rowkeyParts[2];
					String dawCode = rowkeyParts[4];

					String fillQty = "";
					long fillQtyTs = 0;
					for (RowCell c : r.getCells("Fill", "fillQty")) {
						if (c.getTimestamp() > fillQtyTs) {
							fillQtyTs = c.getTimestamp();
							fillQty = c.getValue().toStringUtf8();
						}
					}

					String fillItems = "";
					long fillItemsTs = 0;
					for (RowCell c : r.getCells("Fill", "items")) {
						if (c.getTimestamp() > fillItemsTs) {
							fillItemsTs = c.getTimestamp();
							fillItems = c.getValue().toStringUtf8();
						}
					}

					FourPointCheckBO record = maxFourPtActivitiesMap.get(rxId);
					record.setRxFillId(rxFillId);
					record.setFillDate(fillDate);
					record.setDawCode(dawCode);
					record.setFillQty(fillQty);
					if (fillItems != null && !fillItems.isEmpty()) {
						ObjectMapper mapper = new ObjectMapper();
						List<JsonNode> fillItemsList = mapper.readValue(fillItems,
								mapper.getTypeFactory().constructCollectionType(List.class, JsonNode.class));
						if (!fillItemsList.isEmpty()) {
							record.setItemMdsFamId(fillItemsList.get(0).get("itemMdsFamId").asText());
						} else
							continue;
					} else
						continue;
					maxFourPtActivitiesMapWithFillData.put(rxId, record);
				}
			}
			long rxf2end = System.currentTimeMillis();
			LOGGER.info(" !!!!! rx_fill (2) query and iteration time = " + (rxf2end - rxf2start));
			LOGGER.info(" !!!!! rx_fill (2) query iteration count = " + rxf2count);
		}
		return maxFourPtActivitiesMapWithFillData;
	}

	private List<FourPointCheckBO> readRowsDrugModel(BigtableDataClient dataClient,
			Map<String, FourPointCheckBO> maxFourPtActivitiesMapWithFillData) {

		List<FourPointCheckBO> finalReportList = new ArrayList<FourPointCheckBO>();

		Map<String, List<FourPointCheckBO>> itemMdsFamIdRxMap = maxFourPtActivitiesMapWithFillData.values().stream()
				.collect(Collectors.groupingBy(a -> a.getItemMdsFamId()));
		LOGGER.info("Querying pharmacy_product bigtable to get product_name");
		InterleaveFilter ppFilter = FILTERS.interleave();
		itemMdsFamIdRxMap.keySet().forEach(i -> {
			if (null != i) {
				ppFilter.filter(FILTERS.key().regex("^" + i + "#.+$"));
			}
		});
		Query ppQuery = Query.create(ppTableId).filter(ppFilter);
		if (!itemMdsFamIdRxMap.isEmpty()) {

			long ppBTstart = System.currentTimeMillis();
			ServerStream<Row> ppRows = dataClient.readRows(ppQuery);
			long ppBTend = System.currentTimeMillis();
			LOGGER.info(" !!!!! drug model dataClient.readRows = " + (ppBTend - ppBTstart));

			long ppstart = System.currentTimeMillis();
			for (Row r : ppRows) {
				String[] rowkeyParts = r.getKey().toStringUtf8().split("#");
				String mdsFamId = rowkeyParts[0];
				String productMdsFamId = rowkeyParts[1];
				String productName = "";
				long productNameTs = 0;
				for (RowCell c : r.getCells("drug", "productName")) {
					if (c.getTimestamp() > productNameTs) {
						productNameTs = c.getTimestamp();
						productName = c.getValue().toStringUtf8();
					}
				}
				for (FourPointCheckBO rx : itemMdsFamIdRxMap.get(mdsFamId)) {
					rx.setProductMdsFamId(productMdsFamId);
					rx.setProductName(productName);
				}
			}
			long ppend = System.currentTimeMillis();
			LOGGER.info(" !!!!! drug model query and iteration time = " + (ppend - ppstart));
		}
		for (List<FourPointCheckBO> rxList : itemMdsFamIdRxMap.values()) {
			for (FourPointCheckBO rx : rxList) {
				finalReportList.add(rx);
			}
		}
		return finalReportList;
	}

	private FourPointCheckActivityBO getHardcodedResponse() {

		Integer storeNumber = 1101;
		String appName = "Connexus Pharmacy System";
		String store = "Wal-Mart Pharmacy10-5533";
		String reportName = "4Point Check Report";
		String details = "5533 LOOP 410 NORTHWEST 5025 TRUTH OR CONSEQUENCE TRU COTRUTH OR CONSEQUENCE SC - 72712";

		List<HeaderBO> header = new ArrayList<>();
		List<FourPointCheckDatesBO> dates = new ArrayList<>();

		FourPointCheckActivityBO fourPtCheckActivity = new FourPointCheckActivityBO(
				new FourPointCheckStoreDetailsBO(storeNumber, appName, store, reportName, details), header, dates);

		header.add(new HeaderBO("Rx", "rx"));
		header.add(new HeaderBO("PatientName", "patientName"));
		header.add(new HeaderBO("FillDate", "fillDate"));
		header.add(new HeaderBO("Drug", "drug"));
		header.add(new HeaderBO("Quantity", "quantity"));
		header.add(new HeaderBO("DAW", "daw"));
		header.add(new HeaderBO("UserId", "userId"));
		header.add(new HeaderBO("Date/Time", "dateTime"));

		return fourPtCheckActivity;
	}

}