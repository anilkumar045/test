package com.walmart.reportsapi.bo.audit;

public class ControlledSubstanceRxBO {

	private String rxId;
	private String rxNbr;
	private String storeNbr;
	private String checkUserId;
	private String rxWrittenDate;
	private String activityUserId;
	private String patientId;
	private String prescriberId;
	private String prdMdsFamId;
	private String inputId;
	private String rxFillDaysSplyQty;
	private String rxStatus;
	private String rxExpandedSigTxt;
	private String rxFillQty;
	
	
	
	public ControlledSubstanceRxBO(String rxId, String rxNbr, String storeNbr, String checkUserId, String rxWrittenDate,
			String activityUserId, String patientId, String prescriberId, String prdMdsFamId, String inputId,
			String rxFillDaysSplyQty, String rxStatus, String rxExpandedSigTxt, String rxFillQty) {
		super();
		this.rxId = rxId;
		this.rxNbr = rxNbr;
		this.storeNbr = storeNbr;
		this.checkUserId = checkUserId;
		this.rxWrittenDate = rxWrittenDate;
		this.activityUserId = activityUserId;
		this.patientId = patientId;
		this.prescriberId = prescriberId;
		this.prdMdsFamId = prdMdsFamId;
		this.inputId = inputId;
		this.rxFillDaysSplyQty = rxFillDaysSplyQty;
		this.rxStatus = rxStatus;
		this.rxExpandedSigTxt = rxExpandedSigTxt;
		this.rxFillQty = rxFillQty;
	}
	public ControlledSubstanceRxBO() {
		// TODO Auto-generated constructor stub
	}
	public String getRxId() {
		return rxId;
	}
	public void setRxId(String rxId) {
		this.rxId = rxId;
	}
	public String getRxNbr() {
		return rxNbr;
	}
	public void setRxNbr(String rxNbr) {
		this.rxNbr = rxNbr;
	}
	public String getStoreNbr() {
		return storeNbr;
	}
	public void setStoreNbr(String storeNbr) {
		this.storeNbr = storeNbr;
	}
	public String getCheckUserId() {
		return checkUserId;
	}
	public void setCheckUserId(String checkUserId) {
		this.checkUserId = checkUserId;
	}
	public String getRxWrittenDate() {
		return rxWrittenDate;
	}
	public void setRxWrittenDate(String rxWrittenDate) {
		this.rxWrittenDate = rxWrittenDate;
	}
	public String getActivityUserId() {
		return activityUserId;
	}
	public void setActivityUserId(String activityUserId) {
		this.activityUserId = activityUserId;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public String getPrescriberId() {
		return prescriberId;
	}
	public void setPrescriberId(String prescriberId) {
		this.prescriberId = prescriberId;
	}
	public String getPrdMdsFamId() {
		return prdMdsFamId;
	}
	public void setPrdMdsFamId(String prdMdsFamId) {
		this.prdMdsFamId = prdMdsFamId;
	}
	public String getInputId() {
		return inputId;
	}
	public void setInputId(String inputId) {
		this.inputId = inputId;
	}
	
	
	public String getRxFillDaysSplyQty() {
		return rxFillDaysSplyQty;
	}
	public void setRxFillDaysSplyQty(String rxFillDaysSplyQty) {
		this.rxFillDaysSplyQty = rxFillDaysSplyQty;
	}
	
	
	public String getRxStatus() {
		return rxStatus;
	}
	public void setRxStatus(String rxStatus) {
		this.rxStatus = rxStatus;
	}
	
	
	public String getRxExpandedSigTxt() {
		return rxExpandedSigTxt;
	}
	public void setRxExpandedSigTxt(String rxExpandedSigTxt) {
		this.rxExpandedSigTxt = rxExpandedSigTxt;
	}
	public String getRxFillQty() {
		return rxFillQty;
	}
	public void setRxFillQty(String rxFillQty) {
		this.rxFillQty = rxFillQty;
	}
	@Override
	public String toString() {
		return "ControlledSubstanceRxBO [rxId=" + rxId + ", rxNbr=" + rxNbr + ", storeNbr=" + storeNbr
				+ ", checkUserId=" + checkUserId + ", rxWrittenDate=" + rxWrittenDate + ", activityUserId="
				+ activityUserId + ", patientId=" + patientId + ", prescriberId=" + prescriberId + ", prdMdsFamId="
				+ prdMdsFamId + ", inputId=" + inputId + ", rxFillDaysSplyQty=" + rxFillDaysSplyQty + ", rxStatus="
				+ rxStatus + ", rxExpandedSigTxt=" + rxExpandedSigTxt + ", rxFillQty=" + rxFillQty + "]";
	}
	
	
}
