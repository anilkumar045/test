package com.walmart.reportsapi.repository.impl.pharmacistreports;

import static com.google.cloud.bigtable.data.v2.models.Filters.FILTERS;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.google.api.gax.rpc.ServerStream;
import com.google.cloud.bigtable.data.v2.BigtableDataClient;
import com.google.cloud.bigtable.data.v2.models.Filters.Filter;
import com.google.cloud.bigtable.data.v2.models.Query;
import com.google.cloud.bigtable.data.v2.models.Row;
import com.google.cloud.bigtable.data.v2.models.RowCell;
import com.walmart.reportsapi.bo.audit.HeaderBO;
import com.walmart.reportsapi.bo.pharmacistreports.PharmacistActivityDataBO;
import com.walmart.reportsapi.bo.pharmacistreports.PharmacistActivityReportBO;
import com.walmart.reportsapi.exception.ReportApiServiceException;
import com.walmart.reportsapi.repository.PharmacistReportsDao;
import com.walmart.reportsapi.util.DateUtil;


/**
 * PharmacistActivityReport DAO implementation class is used get the Pharmacist
 * Activity report details based on input request parameters from BigTable
 */
@Repository("pharmacistActivityDAO")
public class PharmacistActivityReportDaoImpl implements PharmacistReportsDao {
	private static final Logger LOGGER = LoggerFactory.getLogger(PharmacistActivityReportDaoImpl.class);

	@Override
	public PharmacistActivityReportBO getPharmacistActivityReportRepository(String storeId, String activityDate, String userName)
			throws ReportApiServiceException {
		LOGGER.info("[PharmacistActivityReportDAOImpl] [getPharmacistActivityReport] Entered method");
		PharmacistActivityReportBO pharmacistActivityReportBO = null;
		try {
			pharmacistActivityReportBO = setPharmacistActivityReportDetails(storeId, activityDate, userName);

		} catch (Exception e) {
			LOGGER.error(
					"[PharmacistActivityReportDAOImpl] [getPharmacistActivityReport] Exception occurred while getting PharmacistActivityReport:"
							+ e.getMessage(),
					e);
			throw new ReportApiServiceException("Exception while getting PharmacistActivityReport " + e.getMessage());
		}
		LOGGER.info("[PharmacistActivityReportDAOImpl] [getPharmacistActivityReport] method end");
		return pharmacistActivityReportBO;

	}

	private PharmacistActivityReportBO setPharmacistActivityReportDetails(String storeId, String activityDate,
			String userName) throws ReportApiServiceException {

		String projectId = "wmt-hnw-techmod-poc";
		String instanceId = "hnw-conx-poc";
		String storeNbr = storeId;
		PharmacistActivityReportBO pharmacistActivityReportBO = new PharmacistActivityReportBO();
		setHeaderInfo(storeId,activityDate, pharmacistActivityReportBO);
		LOGGER.info("Creating BigTable Data Client");

		String userId = getUserIdFromSystemUser(projectId, instanceId, storeNbr, activityDate, userName);
		pharmacistActivityReportBO=getDataFromRxAndRxFill(pharmacistActivityReportBO,projectId, instanceId, storeNbr, activityDate, userId);

		LOGGER.info("Pharmacist Activity Report completed");
		return pharmacistActivityReportBO;
	}

	private String getUserIdFromSystemUser(String projectId, String instanceId, String storeNbr, String activityDate,
			String userName) {

		String suTableId = "System_User";
		String userId = null;
		try (BigtableDataClient dataClient = BigtableDataClient.create(projectId, instanceId)) {

			long suQueryStart = System.currentTimeMillis();

			LOGGER.info(("Start time for System User" + new Timestamp(suQueryStart)));
			LOGGER.info("Querying table System User: " + suTableId);

			Query suQuery = Query.create(suTableId).prefix(storeNbr + "#" + userName + "#");
			ServerStream<Row> suRows = dataClient.readRows(suQuery);
			long suQueryEnd = System.currentTimeMillis();
			LOGGER.info(("End time for read System_User" + new Timestamp(suQueryEnd)));
			LOGGER.info(("Difference in millis = " + (suQueryStart - suQueryEnd)));

			for (Row row : suRows) {
				String rowKey = row.getKey().toStringUtf8();
				String[] keys = rowKey.split("#");
				userId = keys[2];
				LOGGER.info("UserId from System_user table is  " + userId);
			}
		} catch (IOException e) {
			e.printStackTrace();
			LOGGER.error("Error in SystemUser Table Details : " + e.getMessage());

		}
		return userId;

	}

	private PharmacistActivityReportBO getDataFromRxAndRxFill(PharmacistActivityReportBO pharmacistActivityReportBO,String projectId, String instanceId, String storeNbr,
			String activityDate, String userId) {

		String rxTableId = "rxDec";
		String rxFillTableId = "fill_December";
		String pctTableId = "pharmacy_code_txt";
		List<String> typeList = new ArrayList<>();
		List<PharmacistActivityDataBO> activities = new ArrayList<>();
		//PharmacistActivityReportBO pharmacistActivityReportBO = new PharmacistActivityReportBO();

		try (BigtableDataClient dataClient = BigtableDataClient.create(projectId, instanceId)) {

			long rxQueryStart = System.currentTimeMillis();
			String formatActivityDate=DateUtil.formatDate(activityDate);
			LOGGER.info(("Start time for read rx" + new Timestamp(rxQueryStart)));
			LOGGER.info("Querying table : " + rxTableId);

			if (null != userId) {
				Query rxQuery = Query.create(rxTableId).prefix(storeNbr + "#" + formatActivityDate)
						.rowKey("#" + userId + "#");

				ServerStream<Row> rxRows = dataClient.readRows(rxQuery);
				int rxNumber = 0;
				long rxQueryEnd = System.currentTimeMillis();

				LOGGER.info(("End time for read rx" + new Timestamp(rxQueryEnd)));
				LOGGER.info(("Difference in millis = " + (rxQueryEnd - rxQueryStart)));
				for (Row row : rxRows) {
					String rowKey = row.getKey().toStringUtf8();
					String[] keys = rowKey.split("#");
					storeNbr = keys[0];
					rxNumber = Integer.parseInt(keys[7]);
					String rxId = keys[2];
					LOGGER.info(rowKey + " = " + storeNbr + " + " + rxNumber + " + " + rxId);

					List<RowCell> rxActivityTypeCells = row.getCells("RxActivity", "type");
					LOGGER.info("PharmacistActivityReportDAOImpl.setPharmacistActivityReportDetails():::"
							+ rxActivityTypeCells);

					if (rxActivityTypeCells != null) {
						for (RowCell rowCell : rxActivityTypeCells) {
							typeList.add(rowCell.getValue().toStringUtf8());
						}
					}
					LOGGER.info(
							"PharmacistActivityReportDAOImpl.setPharmacistActivityReportDetails()::**::" + typeList);

					long rxFillQueryStart = System.currentTimeMillis();

					LOGGER.info(("Start time for read rx_fill" + new Timestamp(rxQueryStart)));
					Query rxFillQuery = Query.create(rxFillTableId).prefix(storeNbr + "#" + rxId + "#")
							.rowKey("#" + userId);
					ServerStream<Row> rxFillRows = dataClient.readRows(rxFillQuery);
					long rxFillQueryEnd = System.currentTimeMillis();

					LOGGER.info(("End time for read rx_fill" + new Timestamp(rxQueryEnd)));
					LOGGER.info(("Difference in millis = " + (rxFillQueryEnd - rxFillQueryStart)));
					int i = 0;

					for (Row r : rxFillRows) {
						String rowkey = r.getKey().toStringUtf8();
						LOGGER.info(" rxfill rowkey -> " + rowkey);
						String fillId = rowkey.split("#")[3];
						for (RowCell c : r.getCells("Fill", "type")) {
							typeList.add(c.getValue().toStringUtf8());
						}
						LOGGER.info("PharmacistActivityReportDAOImpl.activityTypeDesc(:***:)" + typeList);

					}

					if (null != typeList) {

						for (String actType : typeList) {
							String activityTypeDesc = null;
							Filter pctFillFilter = FILTERS.key().regex("^.+#" + actType + "#.+$");
							Query pctFillQuery = Query.create(pctTableId).filter(pctFillFilter);
							ServerStream<Row> pctFillRows = dataClient.readRows(pctFillQuery);
							for (Row pcRow : pctFillRows) {
								LOGGER.info(" pct rowkey -> " + pcRow);
								String pctRowKey = pcRow.getKey().toStringUtf8();
								String[] pctKeys = pctRowKey.split("#");
								activityTypeDesc = pctKeys[2];
							}
							LOGGER.info("PharmacistActivityReportDAOImpl.activityTypeDesc(::)" + activityTypeDesc);

							if (null != activityTypeDesc) {
								PharmacistActivityDataBO activity = new PharmacistActivityDataBO();
								activity.setRxNbr(rxNumber);
								activity.setActivity(activityTypeDesc);
								activity.setUnique(i);
								LOGGER.info(activity.toString());
								activities.add(activity);
							}
							i++;
						}

					}
				}
			}
			pharmacistActivityReportBO.setData(activities);

		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Error in Rx and Rx_Fill table : " + e.getMessage());
		}
		return pharmacistActivityReportBO;
	}

	private void setHeaderInfo(String storeNbr,String activityDate, PharmacistActivityReportBO pharmacistActivityReportBO) {
		String reportDate = activityDate;
		String appName = "Connexus Pharmacy System";
		String store = "Wal-Mart Pharmacy10-5533";
		String reportName = "4Point Check Report";
		String details = "5533 LOOP 410 NORTHWEST 5025 TRUTH OR CONSEQUENCE TRU COTRUTH OR CONSEQUENCE SC - 72712";

		List<HeaderBO> header = new ArrayList<>();
		pharmacistActivityReportBO.setStoreId(Integer.parseInt(storeNbr));
		pharmacistActivityReportBO.setReportName(reportName);
		pharmacistActivityReportBO.setDate(reportDate);
		pharmacistActivityReportBO.setAppName(appName);
		pharmacistActivityReportBO.setStore(store);
		pharmacistActivityReportBO.setDetails(details);
		header.add(new HeaderBO("Rx Nbr", "rx"));
		header.add(new HeaderBO("Activity", "activity"));
		pharmacistActivityReportBO.setHeader(header);
	}
}
