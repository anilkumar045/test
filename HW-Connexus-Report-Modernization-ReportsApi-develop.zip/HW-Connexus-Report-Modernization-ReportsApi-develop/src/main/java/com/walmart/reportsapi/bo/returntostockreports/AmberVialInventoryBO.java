package com.walmart.reportsapi.bo.returntostockreports;

public class AmberVialInventoryBO {

	private String storeNumber;
	private String createts;
	private String lastChangets;
	private String rtsVialId;
	private String mdsFamId;
	private String rx_fill_id;
	private String rtsVialStatusCode;
	private String item_qty;
	private String vialExpirationDate;
	private String lastChangeUSerId;
	private String rtsVialStatusDescription;

	private String ndcNumber;
	private String shortName;

	private String fillQty;

	private String costAmt;
	private String costTypeCode;
	private String effectiveDate;

	public String getRtsVialStatusDescription() {
		return rtsVialStatusDescription;
	}

	public void setRtsVialStatusDescription(String rtsVialStatusDescription) {
		this.rtsVialStatusDescription = rtsVialStatusDescription;
	}

	public String getStoreNumber() {
		return storeNumber;
	}

	public void setStoreNumber(String keys) {
		this.storeNumber = keys;
	}

	public String getCreatets() {
		return createts;
	}

	public void setCreatets(String createts) {
		this.createts = createts;
	}

	public String getLastChangets() {
		return lastChangets;
	}

	public void setLastChangets(String lastChangets) {
		this.lastChangets = lastChangets;
	}

	public String getRtsVialId() {
		return rtsVialId;
	}

	public void setRtsVialId(String rtsVialId) {
		this.rtsVialId = rtsVialId;
	}

	public String getMdsFamId() {
		return mdsFamId;
	}

	public void setMdsFamId(String mdsFamId) {
		this.mdsFamId = mdsFamId;
	}

	public String getRx_fill_id() {
		return rx_fill_id;
	}

	public void setRx_fill_id(String rx_fill_id) {
		this.rx_fill_id = rx_fill_id;
	}

	public String getRtsVialStatusCode() {
		return rtsVialStatusCode;
	}

	public void setRtsVialStatusCode(String rtsVialStatusCode) {
		this.rtsVialStatusCode = rtsVialStatusCode;
	}

	public String getItem_qty() {
		return item_qty;
	}

	public void setItem_qty(String item_qty) {
		this.item_qty = item_qty;
	}

	public String getVialExpirationDate() {
		return vialExpirationDate;
	}

	public void setVialExpirationDate(String vialExpirationDate) {
		this.vialExpirationDate = vialExpirationDate;
	}

	public String getLastChangeUSerId() {
		return lastChangeUSerId;
	}

	public void setLastChangeUSerId(String lastChangeUSerId) {
		this.lastChangeUSerId = lastChangeUSerId;
	}

	public String getNdcNumber() {
		return ndcNumber;
	}

	public void setNdcNumber(String ndcNumber) {
		this.ndcNumber = ndcNumber;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	public String getFillQty() {
		return fillQty;
	}

	public void setFillQty(String fillQty) {
		this.fillQty = fillQty;
	}

	public String getCostAmt() {
		return costAmt;
	}

	public void setCostAmt(String costAmt) {
		this.costAmt = costAmt;
	}

	public String getCostTypeCode() {
		return costTypeCode;
	}

	public void setCostTypeCode(String costTypeCode) {
		this.costTypeCode = costTypeCode;
	}

	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	@Override
	public String toString() {
		return "AmberVialBO [vialId=" + getRtsVialId() + ", getNdc()=" + getNdcNumber() + ", getShortName()="
				+ getShortName() + ", getFillQty() from rxfill=" + getFillQty() + ", getCostAmt()=" + getCostAmt()
				+ ", getItem_qty() from rts_vial=" + getItem_qty() + ", getCreatets()=" + getCreatets()
				+ ", getVialExpirationDate()=" + getVialExpirationDate() + ", getLastChangeUSerId()="
				+ getLastChangeUSerId();
	}

}