package com.walmart.reportsapi.bo.pharmacistreports;

import java.util.List;

import com.walmart.reportsapi.bo.audit.HeaderBO;

public class FourPointCheckActivityBO {

	private FourPointCheckStoreDetailsBO storeDetails;

	private List<HeaderBO> header;
	private List<FourPointCheckDatesBO> dates;

	public FourPointCheckActivityBO() {
		super();
	}

	public FourPointCheckActivityBO(FourPointCheckStoreDetailsBO storeDetails, List<HeaderBO> header,
			List<FourPointCheckDatesBO> dates) {
		super();
		this.storeDetails = storeDetails;
		this.header = header;
		this.dates = dates;
	}

	public FourPointCheckStoreDetailsBO getStoreDetails() {
		return storeDetails;
	}

	public void setStoreDetails(FourPointCheckStoreDetailsBO storeDetails) {
		this.storeDetails = storeDetails;
	}

	public List<HeaderBO> getHeader() {
		return header;
	}

	public void setHeader(List<HeaderBO> header) {
		this.header = header;
	}

	public List<FourPointCheckDatesBO> getDates() {
		return dates;
	}

	public void setDates(List<FourPointCheckDatesBO> dates) {
		this.dates = dates;
	}

	@Override
	public String toString() {
		return "FourPointCheckActivityBO [storeDetails=" + storeDetails + ", header=" + header + ", dates=" + dates
				+ "]";
	}

}
