/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report API team, Primary :Srilekha Kothapally(vn5101f)
 * Date: 2020/10/14
 * Version: 0.1
 * Description: AmberVialInventoryService implementation class is used get the AmberVialInventory
 * report details based on input request parameters
 * TABLES:rts_vial, pharmacy_item, pharmacy_product, pharmacy_offering:phm_item_cost, rts_vial_status_txt,rx_fill_item
 * The output is written to
 * 1. Request and Responses are generated in the JSON Format
 * 2. Informix and CosMos DB tables which is primarily used for Reports
 * 
 */
package com.walmart.reportsapi.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmart.reportsapi.bo.returntostockreports.AmberVialInventoryActivityBO;
import com.walmart.reportsapi.exception.ReportApiServiceException;
import com.walmart.reportsapi.repository.ReturnToStockReportsDao;
import com.walmart.reportsapi.service.ReturnToStockReportsService;

@Service
public class ReturnToStockReportsServiceImpl implements ReturnToStockReportsService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ReturnToStockReportsServiceImpl.class);

	@Autowired
	private ReturnToStockReportsDao amberVialInventoryDAO;

	/**
	*This Service method is used to get the AmberVial Inventory report details based on
	* based on the input params
	* @param String fromDate
	* @param String toDate
	* @param Integer storeId
	* @param Integer reportOption
	* @param Integer fromVialId
	* @param Integer toVialId
	* @return AmberVialInventoryActivityBO(Contains Report Details,Header Details and Report Data details)
	* @throws ReportApiServiceException(Null Pointer/Record Not Found)
	*/

	@Override
	public AmberVialInventoryActivityBO getAmberVialInventoryReport(String fromDate, String toDate, Integer storeId,
			Integer reportOption, Integer fromVialId, Integer toVialId) throws ReportApiServiceException {
		// TODO Auto-generated method stub
		AmberVialInventoryActivityBO amberVialInventoryActivityBO = null;
		try {

			amberVialInventoryActivityBO = amberVialInventoryDAO.getAmberVialInventoryReport(fromDate, toDate, storeId, reportOption, fromVialId, toVialId);

		} catch (ReportApiServiceException e) {

			LOGGER.error("[AmberVialInventoryServiceImpl][getAmberVialInventoryReport] Exception occurred while getting the AmberVialInventory report :"
					+ e.getMessage(), e);
			throw e;
		}
		return amberVialInventoryActivityBO;
	}
}

