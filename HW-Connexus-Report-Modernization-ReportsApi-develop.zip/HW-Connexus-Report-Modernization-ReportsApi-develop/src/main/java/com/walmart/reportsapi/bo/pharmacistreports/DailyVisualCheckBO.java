package com.walmart.reportsapi.bo.pharmacistreports;

public class DailyVisualCheckBO {
	private String rxId;
	private String rxNbr;
	private String storeNbr;
	private String checkUserId;
	private String rxStatus;
	private String compoundInd;
	
	private String activityType;
	private String activityTs;
	private String activityUserId;
	
	private String patientId;
	private String patientName;
	
	private String rxFillId;
	private String fillDate;
	private String fillQty;
	private String dawCode;
	
	private String itemMdsFamId;
	private String productMdsFamId;
	private String productName;
	
	public String getRxId() {
		return rxId;
	}
	public void setRxId(String rxId) {
		this.rxId = rxId;
	}
	public String getRxNbr() {
		return rxNbr;
	}
	public void setRxNbr(String rxNbr) {
		this.rxNbr = rxNbr;
	}
	public String getStoreNbr() {
		return storeNbr;
	}
	public void setStoreNbr(String storeNbr) {
		this.storeNbr = storeNbr;
	}
	public String getCheckUserId() {
		return checkUserId;
	}
	public void setCheckUserId(String checkUserId) {
		this.checkUserId = checkUserId;
	}
	public String getRxStatus() {
		return rxStatus;
	}
	public void setRxStatus(String rxStatus) {
		this.rxStatus = rxStatus;
	}
	public String getActivityType() {
		return activityType;
	}
	public void setActivityType(String activityType) {
		this.activityType = activityType;
	}
	public String getActivityTs() {
		return activityTs;
	}
	public void setActivityTs(String activityTs) {
		this.activityTs = activityTs;
	}
	public String getActivityUserId() {
		return activityUserId;
	}
	public void setActivityUserId(String activityUserId) {
		this.activityUserId = activityUserId;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getRxFillId() {
		return rxFillId;
	}
	public void setRxFillId(String rxFillId) {
		this.rxFillId = rxFillId;
	}
	public String getFillDate() {
		return fillDate;
	}
	public void setFillDate(String fillDate) {
		this.fillDate = fillDate;
	}
	public String getFillQty() {
		return fillQty;
	}
	public void setFillQty(String fillQty) {
		this.fillQty = fillQty;
	}
	public String getDawCode() {
		return dawCode;
	}
	public void setDawCode(String dawCode) {
		this.dawCode = dawCode;
	}
	public String getItemMdsFamId() {
		return itemMdsFamId;
	}
	public void setItemMdsFamId(String itemMdsFamId) {
		this.itemMdsFamId = itemMdsFamId;
	}
	public String getProductMdsFamId() {
		return productMdsFamId;
	}
	public void setProductMdsFamId(String productMdsFamId) {
		this.productMdsFamId = productMdsFamId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	private String activityDate;
	private String activityTime;
	
	public String getActivityDate() {
		return activityDate;
	}
	public void setActivityDate(String activityDate) {
		this.activityDate = activityDate;
	}
	public String getActivityTime() {
		return activityTime;
	}
	public void setActivityTime(String activityTime) {
		this.activityTime = activityTime;
	}
	
	public String getCompoundInd() {
		return compoundInd;
	}
	public void setCompoundInd(String compoundInd) {
		this.compoundInd = compoundInd;
	}
	
	@Override
	public String toString() {
		return "FourPointCheckBO [rxId=" + rxId + ", rxNbr=" + rxNbr + ", storeNbr=" + storeNbr + ", checkUserId="
				+ checkUserId + ", rxStatus=" + rxStatus + ", activityType=" + activityType + ", activityTs="
				+ activityTs + ", activityUserId=" + activityUserId + ", patientId=" + patientId + ", patientName="
				+ patientName + ", rxFillId=" + rxFillId + ", fillDate=" + fillDate + ", fillQty=" + fillQty
				+ ", dawCode=" + dawCode + ", itemMdsFamId=" + itemMdsFamId + ", productMdsFamId=" + productMdsFamId
				+ ", productName=" + productName + ", activityDate=" + activityDate + ", activityTime=" + activityTime
				+ "]";
	}
	
}