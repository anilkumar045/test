/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report API team, Primary :Shiva(vn50xd0)
 * Date: 2020/12/31
 * Version: 0.2
 * Description: This Controller class is responsible for getting  the Audit Report
 * details based on input request parameters from the big data tables
 * TABLES: rx_December, patient_GDB_DEC, fill_December, DrugModel, prescriber, license
 * The output is written to
 * 1. Request and Responses are generated in the JSON Format
 * 2. Big Table tables which is primarily used for Reports
 * 
 */
package com.walmart.reportsapi.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.walmart.reportsapi.bo.audit.ControlledSubstanceRxDetailsBO;
import com.walmart.reportsapi.service.AuditService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * Audit Controller class is used get the Four Point Check report details based
 * on input request parameters
 */
@RestController
@RequestMapping("/audit")
public class AuditController {

	private static final Logger LOGGER = LoggerFactory.getLogger(AuditController.class);

	@Autowired
	AuditService auditService;

	@ApiOperation(value = "Get audit report Details based on input request parameters")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error") })

	@RequestMapping(value = "/controlled-substance-rx-details", method = RequestMethod.GET, produces = "application/json")
	public ControlledSubstanceRxDetailsBO getControlledSubstanceRxDetails(
			@RequestParam(required = true, value = "storeId") String storeId,
			@RequestParam(required = true, value = "fromDate") String fromDate,
			@RequestParam(required = true, value = "toDate") String toDate) throws Exception {

		LOGGER.info("[AuditController][getControlledSubstanceRxDetails] Method Starts");

		ControlledSubstanceRxDetailsBO controlledSubstanceRxDetails = null;
		try {
			if (!fromDate.equals("null") && !toDate.equals("null")) {
				controlledSubstanceRxDetails = auditService.getControlledSubstanceRxDetailsService(storeId, fromDate,
						toDate);
			}
		} catch (Exception e) {
			LOGGER.error(
					"[AuditController][getControlledSubstanceRxDetails] Exception occurred while getting the getControlledSubstanceRxDetails :"
							+ e.getMessage(),
					e);

		}
		return controlledSubstanceRxDetails;
	}
}
