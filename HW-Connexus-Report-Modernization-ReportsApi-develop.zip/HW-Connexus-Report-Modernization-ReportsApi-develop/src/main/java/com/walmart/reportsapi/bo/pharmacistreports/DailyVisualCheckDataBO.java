package com.walmart.reportsapi.bo.pharmacistreports;

public class DailyVisualCheckDataBO {

	private String rx;
	private String patientName;
	private String fillDate;
	private String drug;
	private String quantity;
	private String userId;
	private String dateTime;

	public DailyVisualCheckDataBO(String rx, String patientName, String fillDate, String drug, String quantity,
		 String userId, String dateTime) {
		super();
		this.rx = rx;
		this.patientName = patientName;
		this.fillDate = fillDate;
		this.drug = drug;
		this.quantity = quantity;
		this.userId = userId;
		this.dateTime = dateTime;
	}

	public String getRx() {
		return rx;
	}

	public void setRx(String rx) {
		this.rx = rx;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getFillDate() {
		return fillDate;
	}

	public void setFillDate(String fillDate) {
		this.fillDate = fillDate;
	}

	public String getDrug() {
		return drug;
	}

	public void setDrug(String drug) {
		this.drug = drug;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	

}
