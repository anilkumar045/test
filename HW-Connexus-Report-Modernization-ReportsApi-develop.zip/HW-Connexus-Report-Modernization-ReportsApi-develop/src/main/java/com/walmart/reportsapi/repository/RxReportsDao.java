/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report API team, Primary :vn50w1f
 * Date: 2021/1/1
 * Version: 0.1
 * Description: This DAO Interface class is used to declare the methods for
 * RxActivity DAO layer implementation
 * TABLES: rxDec, fill_December, System_User
 * The output is written to
 * 1. Request and Responses are generated in the JSON Format
 * 2. Big table is primarily used for Reports
 * 
 */

package com.walmart.reportsapi.repository;

import com.walmart.reportsapi.bo.rxreports.RxActivityBO;

/**
 * RxActivity DAO Interface class is used to declare the methods for RxActivity
 * DAO layer implementation
 */
public interface RxReportsDao {

	RxActivityBO getRxActivityReportRepository(String storeId, String rxNumber, String fillDate);

}
