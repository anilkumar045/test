package com.walmart.reportsapi.bo.pharmacistreports;

import java.util.List;

public class FourPointCheckDatesBO {

	private String date;

	private List<FourPointCheckPharmacistBO> pharmacists;

	public FourPointCheckDatesBO(String date, List<FourPointCheckPharmacistBO> pharmacists) {
		super();
		this.date = date;
		this.pharmacists = pharmacists;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public List<FourPointCheckPharmacistBO> getPharmacists() {
		return pharmacists;
	}

	public void setPharmacists(List<FourPointCheckPharmacistBO> pharmacists) {
		this.pharmacists = pharmacists;
	}

	@Override
	public String toString() {
		return "FourPtCheckDatesBO [date=" + date + ", Pharmacists=" + pharmacists + ", getDate()=" + getDate()
				+ ", getPharmacists()=" + getPharmacists() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}

}
