package com.walmart.reportsapi.repository.impl.pharmacistreports;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.gax.rpc.ServerStream;
import com.google.cloud.bigtable.data.v2.BigtableDataClient;
import com.google.cloud.bigtable.data.v2.models.Filters.InterleaveFilter;
import com.google.cloud.bigtable.data.v2.models.Query;
import com.google.cloud.bigtable.data.v2.models.Row;
import com.google.cloud.bigtable.data.v2.models.RowCell;
import com.walmart.reportsapi.bo.StoreDetailsBO;
import com.walmart.reportsapi.bo.audit.HeaderBO;
import com.walmart.reportsapi.bo.pharmacistreports.DailyVisualCheckBO;
import com.walmart.reportsapi.bo.pharmacistreports.DailyVisualCheckDataBO;
import com.walmart.reportsapi.bo.pharmacistreports.DailyVisualVerifyCheckActivityBO;
import com.walmart.reportsapi.bo.pharmacistreports.DailyVisualVerifyCheckDatesBO;
import com.walmart.reportsapi.bo.pharmacistreports.DailyVisualVerifyCheckPharmacistBO;
import com.walmart.reportsapi.bo.pharmacistreports.FourPointCheckStoreDetailsBO;
import com.walmart.reportsapi.exception.ReportApiServiceException;
import com.walmart.reportsapi.repository.PharmacistReportsDao;
import static com.google.cloud.bigtable.data.v2.models.Filters.FILTERS;


@Repository("dailyVisualVerifyDAO")
public class DailyVisualVerifyDAOImpl  implements PharmacistReportsDao { 
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DailyVisualVerifyDAOImpl.class);
	private static String date = "2020-01-01T23:28:56.782Z";

	DailyVisualVerifyCheckActivityBO dailyVisualVerifyCheckActivity = null;
	List<DailyVisualCheckBO> dailyVisVerActivities = new ArrayList<DailyVisualCheckBO>();

	String projectId = "wmt-hnw-techmod-poc";
	String instanceId = "hnw-conx-poc";
	String rxaTableId = "rxDec";
	String paTableId = "patient_GDB_DEC";
	String rxfTableId = "FillDecember";
	String ppTableId = "DrugModel";
	String suTableId = "System_User";

	SimpleDateFormat targetFormat = new SimpleDateFormat("yyyy-MM-dd");
	SimpleDateFormat originalFormat = new SimpleDateFormat("MM/dd/yyyy");

	@PostConstruct
	public void populatecalledOn() {

		Integer storeNumber = 1101;
		String reportDate = date;
		String from = date;
		String to = "2020-02-01T23:28:56.782Z";
		String appName = "Connexus Pharmacy System";
		String store = "Wal-Mart Pharmacy10-5533";
		String reportName = "Visual Verify Check Report";
		String details = "5533 LOOP 410 NORTHWEST 5025 TRUTH OR CONSEQUENCE TRU COTRUTH OR CONSEQUENCE SC - 72712";

		List<HeaderBO> header = new ArrayList<>();
		header.add(new HeaderBO("Rx", "rx"));
		header.add(new HeaderBO("PatientName", "patientName"));
		header.add(new HeaderBO("FillDate", "fillDate"));
		header.add(new HeaderBO("Drug", "drug"));
		header.add(new HeaderBO("Quantity", "quantity"));
		header.add(new HeaderBO("UserId", "userId"));
		header.add(new HeaderBO("Date/Time", "dateTime"));
		List<DailyVisualVerifyCheckDatesBO> dates = new ArrayList<>();

		List<DailyVisualVerifyCheckPharmacistBO> pharmacists = new ArrayList<>();
		List<DailyVisualCheckDataBO> data = new ArrayList<>();

		dailyVisualVerifyCheckActivity = new DailyVisualVerifyCheckActivityBO(new StoreDetailsBO(storeNumber, appName, store, reportName, details), header, dates);

	}

	public DailyVisualVerifyCheckActivityBO getDailyVisualVerifyReport(String storeId, String fromDate, String toDate)
			throws ReportApiServiceException {

		LOGGER.info("getDailyVisualVerifyReport Method fromDate: {} and toDate: {} and store: {}", fromDate, toDate,
				storeId);

		String from = "";
		String to = "";
		List<DailyVisualCheckBO> finalReportList = new ArrayList<DailyVisualCheckBO>();
		LOGGER.info("Final dailyVisVerActivities  size" + dailyVisVerActivities.size());

		LOGGER.info("Creating BigtableDataClient ..");
		try (BigtableDataClient dataClient = BigtableDataClient.create(projectId, instanceId)) {
			from = targetFormat.format(originalFormat.parse(fromDate.split(" ")[0])) + " 00:00:00";
			to = targetFormat.format(originalFormat.parse(toDate.split(" ")[0])) + " 23:59:59";
			LOGGER.info("formatted input dates : " + from + " and " + to);
			LOGGER.info("Querying Fill bigtable using rowkey range");

			LOGGER.info("Querying Fill Table");
			dailyVisVerActivities = readRowsFill(dataClient, from, to, storeId);

			LOGGER.info(" fill dailyVisVerActivities  size" + dailyVisVerActivities.size());

			if (!dailyVisVerActivities.isEmpty()) {

				LOGGER.info(
						"Grouping result by fillId and keeping only records having latest activity sequence number");
				List<DailyVisualCheckBO> maxDailyVVActivities = new ArrayList<DailyVisualCheckBO>();
				for (List<DailyVisualCheckBO> activitiesForRxFillId : dailyVisVerActivities.stream()
						.collect(Collectors.groupingBy(a -> a.getRxFillId())).values()) {
					maxDailyVVActivities.add(activitiesForRxFillId.get(activitiesForRxFillId.size() - 1));
				}

				LOGGER.info(" Max sequnce of Fill List size for given data raneg -->" + maxDailyVVActivities.size());

				LOGGER.info("Querying Rx Table");
				dailyVisVerActivities = readRowsRxFill(dataClient, storeId, maxDailyVVActivities);
				LOGGER.info(" Rx dailyVisVerActivities  size" + dailyVisVerActivities.size());

				LOGGER.info("Querying Patient Table ");
				dailyVisVerActivities = readRowsPatient(dataClient, storeId, dailyVisVerActivities);
				LOGGER.info("Patient dailyVisVerActivities  size" + dailyVisVerActivities.size());

				LOGGER.info("Querying Drug model  Table");
				dailyVisVerActivities = readRowsDrugModel(dataClient, dailyVisVerActivities);
				LOGGER.info("Drug dailyVisVerActivities  size" + dailyVisVerActivities.size());

				LOGGER.info("Querying System User");
				finalReportList = readRowsSystemUser(dataClient, storeId, dailyVisVerActivities);

				LOGGER.info("FinalReportList size" + dailyVisVerActivities.size());

			}

			long restart = System.currentTimeMillis();
			LOGGER.info("Formatting date strings");
			finalReportList.forEach(r -> {
				String activityTs = r.getActivityTs();
				// 2020-11-17 15:08:30
				String datestr = activityTs.split(" ")[0];
				r.setActivityTime(activityTs.split(" ")[1]);

				SimpleDateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd");
				SimpleDateFormat targetFormat = new SimpleDateFormat("MM/dd/yyyy");
				Date date = null;
				try {
					date = originalFormat.parse(datestr);
				} catch (ParseException e) {
					e.printStackTrace();
				}
				String formattedDate = targetFormat.format(date);
				r.setActivityDate(formattedDate);

				Date fillDate = null;
				try {
					LOGGER.info("Original Fill Date -->" + r.getFillDate());
					fillDate = originalFormat.parse(r.getFillDate());

				} catch (ParseException e) {
					e.printStackTrace();
				}

				String formattedFillDate = targetFormat.format(date);
				r.setFillDate(formattedFillDate);

			});

			LOGGER.info("Mapping record list to response BO");
			List<DailyVisualVerifyCheckDatesBO> dates = new ArrayList<DailyVisualVerifyCheckDatesBO>();
			for (Map.Entry<String, List<DailyVisualCheckBO>> dateEntry : finalReportList.stream()
					.collect(Collectors.groupingBy(r -> r.getActivityDate())).entrySet()) {
				List<DailyVisualVerifyCheckPharmacistBO> pharmacists = new ArrayList<DailyVisualVerifyCheckPharmacistBO>();
				for (Map.Entry<String, List<DailyVisualCheckBO>> pharmacistEntry : dateEntry.getValue().stream()
						.collect(Collectors.groupingBy(x -> x.getCheckUserId())).entrySet()) {
					List<DailyVisualCheckDataBO> datas = new ArrayList<DailyVisualCheckDataBO>();
					for (DailyVisualCheckBO record : pharmacistEntry.getValue()) {
						datas.add(new DailyVisualCheckDataBO(record.getRxNbr(), record.getPatientName(),
								record.getFillDate(), record.getProductName(), record.getFillQty(),
								record.getActivityUserId(), record.getActivityDate() + " " + record.getActivityTime()));

					}
					pharmacists.add(new DailyVisualVerifyCheckPharmacistBO(pharmacistEntry.getKey(), datas));
				}
				dates.add(new DailyVisualVerifyCheckDatesBO(dateEntry.getKey(), pharmacists));

			}

			LOGGER.info("Sorting response based on fill date and pharmacist name");
			dates.sort(Comparator.comparing(DailyVisualVerifyCheckDatesBO::getDate));
			dates.forEach(d -> {
				d.getPharmacists().sort(Comparator.comparing(DailyVisualVerifyCheckPharmacistBO::getPharmacistName));
			});

			long resend = System.currentTimeMillis();
			LOGGER.info("^^^^^^^^^    Response Time = " + (resend - restart));

			dailyVisualVerifyCheckActivity.setDates(dates);

			LOGGER.info("completed");
		} catch (Exception e) {
			e.printStackTrace();
		}
		LOGGER.info("[DailyVisualVerifyDAOImpl] [getDailyVisualVerifyReport] method end");
		return dailyVisualVerifyCheckActivity;
	}

	private List<DailyVisualCheckBO> readRowsFill(BigtableDataClient dataClient, String from, String to, String storeId)
			throws JsonProcessingException, JsonProcessingException {

		long fillstart = System.currentTimeMillis();
		List<DailyVisualCheckBO> tempdailyVisVerActivities = new ArrayList<DailyVisualCheckBO>();
		Query fillaQuery = Query.create(rxfTableId).range(storeId + "#" + from + "#", storeId + "#" + to + "#");

		ServerStream<Row> fillaRows = dataClient.readRows(fillaQuery);
		fillaQuery = Query.create(rxfTableId);

		int rowCount = 0;
		for (Row r : fillaRows) {
			DailyVisualCheckBO filla = new DailyVisualCheckBO();
			String[] rowkeyParts = r.getKey().toStringUtf8().split("#");

			filla.setStoreNbr(rowkeyParts[0]);
			filla.setRxId(rowkeyParts[2]);
			filla.setRxFillId(rowkeyParts[4]);
			filla.setActivityUserId(rowkeyParts[6]);
			filla.setCheckUserId(rowkeyParts[5]);
			filla.setActivityTs(rowkeyParts[1]);
			filla.setFillDate(rowkeyParts[3]);

			rowCount++;

			String statusCode = "";
			long statusTs = 0;
			for (RowCell c : r.getCells("Fill", "status")) {
				if (c.getTimestamp() > statusTs) {
					statusTs = c.getTimestamp();
					statusCode = c.getValue().toStringUtf8();
				}
			}

			if (!statusCode.equals("ACTIVE") && !statusCode.equals("HOLD") && !statusCode.equals("TRANSFER"))
				continue;
			String type = "";
			long typeTs = 0;
			for (RowCell c : r.getCells("Fill", "type")) {
				if (c.getTimestamp() > typeTs) {
					typeTs = c.getTimestamp();
					type = c.getValue().toStringUtf8();
				}
			}

			if (!"VSULCHEK".equals(type))
				continue;

			String fillQty = "";
			long fillQtyTs = 0;
			for (RowCell c : r.getCells("Fill", "fillQty")) {
				if (c.getTimestamp() > fillQtyTs) {
					fillQtyTs = c.getTimestamp();
					fillQty = c.getValue().toStringUtf8();
				}
			}

			String fillItems = "";
			long fillItemsTs = 0;
			String itemMdsFamId = "";
			for (RowCell c : r.getCells("Fill", "items")) {
				if (c.getTimestamp() > fillItemsTs) {
					fillItemsTs = c.getTimestamp();
					fillItems = c.getValue().toStringUtf8();
				}
			}

			if (fillItems != null && !fillItems.isEmpty()) {
				ObjectMapper mapper = new ObjectMapper();
				List<JsonNode> fillItemsList = mapper.readValue(fillItems,
						mapper.getTypeFactory().constructCollectionType(List.class, JsonNode.class));
				if (!fillItemsList.isEmpty()) {
					itemMdsFamId = fillItemsList.get(0).get("itemMdsFamId").asText();
				} else
					continue;
			} else
				continue;

			filla.setCheckUserId(rowkeyParts[6]);
			if (filla.getCheckUserId() == null || filla.getCheckUserId() == "")
				continue;

			//LOGGER.info(rowkeyParts[0] + "#" + rowkeyParts[1] + "#" + rowkeyParts[2] + "#" + rowkeyParts[3] + "#"
				//	+ rowkeyParts[4] + "#" + rowkeyParts[5] + "#" + rowkeyParts[5] + rowkeyParts[6]);

			LOGGER.info(" Fill date  ---->" + filla.getFillDate());
			filla.setFillQty(fillQty);
			filla.setItemMdsFamId(itemMdsFamId);
			tempdailyVisVerActivities.add(filla);

		}

		long fillend = System.currentTimeMillis();
		LOGGER.info(" ^^^^^^^^^^^  Fill query and iteration time = " + (fillend - fillstart));
		LOGGER.info("Fill  query record count =" + rowCount);
		LOGGER.info(" Filtered Fill List size for given data raneg -->" + tempdailyVisVerActivities.size());
		return tempdailyVisVerActivities;
	}

	private List<DailyVisualCheckBO> readRowsRxFill(BigtableDataClient dataClient, String storeId,
			List<DailyVisualCheckBO> maxDailyVVActivities) {

		long rxastart = System.currentTimeMillis();
		Set<DailyVisualCheckBO> rxFillDVVActivities = new LinkedHashSet<DailyVisualCheckBO>();

		Map<String, List<DailyVisualCheckBO>> maxDailyVVActivitiesMap = maxDailyVVActivities.stream()
				.collect(Collectors.groupingBy(a -> a.getRxId()));

		LOGGER.info("RXID  Size  ------> " + maxDailyVVActivitiesMap.size());

		InterleaveFilter rxFilter = FILTERS.interleave();
		maxDailyVVActivitiesMap.keySet().forEach(i -> {
			if (null != i) {
				rxFilter.filter(FILTERS.key().regex("^.+#" + i + "#.+$"));
			}
		});

		Query rxaQuery = Query.create(rxaTableId).prefix(storeId).filter(rxFilter);
		ServerStream<Row> rxaRows = dataClient.readRows(rxaQuery);

		for (Row r : rxaRows) {

			long statusTs = 0;
			String rxStatus = "";
			for (RowCell c : r.getCells("Prescription", "status")) {
				if (c.getTimestamp() > statusTs) {
					statusTs = c.getTimestamp();
					rxStatus = c.getValue().toStringUtf8();

				}
			}

			if (!rxStatus.equals("ACTIVE") && !rxStatus.equals("ON_HOLD") && !rxStatus.equals("TRANSFERRED"))
				continue;

			String[] rowkeyParts = r.getKey().toStringUtf8().split("#");
			String rxNbr = rowkeyParts[7];
			String patientId = rowkeyParts[4];
			String rxId = rowkeyParts[2];

			for (DailyVisualCheckBO activity : maxDailyVVActivitiesMap.get(rxId)) {
				activity.setRxNbr(rxNbr);
				activity.setPatientId(patientId);
				rxFillDVVActivities.add(activity);

			}

		}

		List<DailyVisualCheckBO> tempdailyVisVerActivities = rxFillDVVActivities.stream().collect(Collectors.toList());
		LOGGER.info(" Rx and Fill Size ---> " + tempdailyVisVerActivities.size());

		long rxaend = System.currentTimeMillis();
		LOGGER.info("  ^^^^^^^^^^^^  rx_fill query and iteration time = " + (rxaend - rxastart));
		return tempdailyVisVerActivities;

	}

	private List<DailyVisualCheckBO> readRowsPatient(BigtableDataClient dataClient, String storeId,
			List<DailyVisualCheckBO> rxFilldailyVVActivities) {

		long pastart = System.currentTimeMillis();

		Query paQuery = Query.create(paTableId);

		rxFilldailyVVActivities.stream().collect(Collectors.groupingBy(DailyVisualCheckBO::getPatientId)).keySet()
				.forEach(id -> {
					String patrowkey = storeId + "#" + id;
					paQuery.prefix(patrowkey);
				});

		Map<String, String> patientNames = new HashMap<String, String>();
		if (!rxFilldailyVVActivities.isEmpty()) {

			ServerStream<Row> paRows = dataClient.readRows(paQuery);
			for (Row patient : paRows) {
				String[] rowkeyParts = patient.getKey().toStringUtf8().split("#");
				String firstName = "";
				long firstNameTs = 0;
				for (RowCell c : patient.getCells("hw_patient_name", "firstName")) {
					if (c.getTimestamp() > firstNameTs) {
						firstNameTs = c.getTimestamp();
						firstName = c.getValue().toStringUtf8();
					}
				}
				String middleName = "";
				long middleNameTs = 0;
				for (RowCell c : patient.getCells("hw_patient_name", "middleName")) {
					if (c.getTimestamp() > middleNameTs) {
						middleNameTs = c.getTimestamp();
						middleName = c.getValue().toStringUtf8();
					}
				}
				String lastName = "";
				long lastNameTs = 0;
				for (RowCell c : patient.getCells("hw_patient_name", "lastName")) {
					if (c.getTimestamp() > lastNameTs) {
						lastNameTs = c.getTimestamp();
						lastName = c.getValue().toStringUtf8();
					}
				}
				// LOGGER.info(rowkeyParts[1], lastName + " " + firstName + " " + middleName);
				patientNames.put(rowkeyParts[1], lastName + " " + firstName + " " + middleName);
			}

		}

		Map<String, List<DailyVisualCheckBO>> patientRxMap = rxFilldailyVVActivities.stream()
				.collect(Collectors.groupingBy(a -> a.getPatientId()));
		List<DailyVisualCheckBO> tempdailyVisVerActivities = new ArrayList<DailyVisualCheckBO>();
		for (String patientId : patientRxMap.keySet()) {
			if (patientNames.containsKey(patientId)) {
				for (DailyVisualCheckBO rx : patientRxMap.get(patientId)) {
					rx.setPatientName(patientNames.get(rx.getPatientId()));
					tempdailyVisVerActivities.add(rx);
				}
			}
		}

		long paend = System.currentTimeMillis();
		LOGGER.info("^^^^^^^^  Patient = " + (paend - pastart));
		return tempdailyVisVerActivities;

	}

	private List<DailyVisualCheckBO> readRowsDrugModel(BigtableDataClient dataClient,
			List<DailyVisualCheckBO> rxFilldailyVVActivities) {

		long ppstart = System.currentTimeMillis();
		List<DailyVisualCheckBO> tempdailyVisVerActivities = new ArrayList<DailyVisualCheckBO>();
		Map<String, List<DailyVisualCheckBO>> itemMdsFamIdRxMap = rxFilldailyVVActivities.stream()
				.collect(Collectors.groupingBy(a -> a.getItemMdsFamId()));

		InterleaveFilter ppFilter = FILTERS.interleave();
		itemMdsFamIdRxMap.keySet().forEach(i -> {
			if (null != i) {
				ppFilter.filter(FILTERS.key().regex("^" + i + "#.+$"));
			}
		});

		Query ppQuery = Query.create(ppTableId).filter(ppFilter);
		if (!itemMdsFamIdRxMap.isEmpty()) {
			ServerStream<Row> ppRows = dataClient.readRows(ppQuery);
			for (Row r : ppRows) {
				String[] rowkeyParts = r.getKey().toStringUtf8().split("#");
				String mdsFamId = rowkeyParts[0];
				String productMdsFamId = rowkeyParts[1];
				String productName = "";
				long productNameTs = 0;
				for (RowCell c : r.getCells("drug", "productName")) {
					if (c.getTimestamp() > productNameTs) {
						productNameTs = c.getTimestamp();
						productName = c.getValue().toStringUtf8();
					}
				}
				for (DailyVisualCheckBO rx : itemMdsFamIdRxMap.get(mdsFamId)) {
					rx.setProductName(productName);

				}
			}
		}

		for (List<DailyVisualCheckBO> rxList : itemMdsFamIdRxMap.values()) {
			for (DailyVisualCheckBO rx : rxList) {
				tempdailyVisVerActivities.add(rx);
			}
		}

		long ppend = System.currentTimeMillis();
		LOGGER.info("^^^^^^^^^   Drug Model Latency = " + (ppend - ppstart));
		return tempdailyVisVerActivities;
	}

	private List<DailyVisualCheckBO> readRowsSystemUser(BigtableDataClient dataClient, String storeId,
			List<DailyVisualCheckBO> rxFilldailyVVActivities) {

		List<DailyVisualCheckBO> tempfinalReportList = new ArrayList<DailyVisualCheckBO>();

		long sustart = System.currentTimeMillis();

		Map<String, List<DailyVisualCheckBO>> activityUserIdRxMap = rxFilldailyVVActivities.stream()
				.collect(Collectors.groupingBy(a -> a.getActivityUserId()));

		InterleaveFilter suFilter = FILTERS.interleave();
		activityUserIdRxMap.keySet().forEach(i -> {
			if (null != i) {

				suFilter.filter(FILTERS.key().regex("^.+#" + i + "$"));
			}
		});

		Query suQuery = Query.create(suTableId).prefix(storeId).filter(suFilter);

		if (!activityUserIdRxMap.isEmpty()) {
		
			ServerStream<Row> suRows = dataClient.readRows(suQuery);
			for (Row r : suRows) {

				String[] rowkeyParts = r.getKey().toStringUtf8().split("#");
				String rowKey = r.getKey().toStringUtf8();
				String[] keys = rowKey.split("#");
				String userId = keys[2];
				String userDes = keys[1];
				LOGGER.info(keys[1] + " " + keys[2]);

				for (DailyVisualCheckBO rx : activityUserIdRxMap.get(userId)) {

					rx.setCheckUserId(userDes);

				}
			}
		}

		for (List<DailyVisualCheckBO> rxList : activityUserIdRxMap.values()) {
			for (DailyVisualCheckBO rx : rxList) {
				tempfinalReportList.add(rx);
			}
		}

		long suend = System.currentTimeMillis();
		LOGGER.info("^^^^^^^^^   System User Latency = " + (suend - sustart));
		return tempfinalReportList;
	}
	
	

}
