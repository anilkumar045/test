package com.walmart.reportsapi.bo.pharmacistreports;

public class FourPointCheckDataBO {

	private String rx;
	private String patientName;
	private String fillDate;
	private String drug;
	private String quantity;
	private String daw;
	private String userId;
	private String dateTime;

	public FourPointCheckDataBO(String rx, String patientName, String fillDate, String drug, String quantity,
			String daw, String userId, String dateTime) {
		super();
		this.rx = rx;
		this.patientName = patientName;
		this.fillDate = fillDate;
		this.drug = drug;
		this.quantity = quantity;
		this.daw = daw;
		this.userId = userId;
		this.dateTime = dateTime;
	}

	public String getRx() {
		return rx;
	}

	public void setRx(String rx) {
		this.rx = rx;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getFillDate() {
		return fillDate;
	}

	public void setFillDate(String fillDate) {
		this.fillDate = fillDate;
	}

	public String getDrug() {
		return drug;
	}

	public void setDrug(String drug) {
		this.drug = drug;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getDaw() {
		return daw;
	}

	public void setDaw(String daw) {
		this.daw = daw;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	@Override
	public String toString() {
		return "FourPtCheckDataBO [rx=" + rx + ", patientName=" + patientName + ", fillDate=" + fillDate + ", drug="
				+ drug + ", quantity=" + quantity + ", daw=" + daw + ", userId=" + userId + ", dateTime=" + dateTime
				+ ", getRx()=" + getRx() + ", getPatientName()=" + getPatientName() + ", getFillDate()=" + getFillDate()
				+ ", getDrug()=" + getDrug() + ", getQuantity()=" + getQuantity() + ", getDaw()=" + getDaw()
				+ ", getUserId()=" + getUserId() + ", getDateTime()=" + getDateTime() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}
