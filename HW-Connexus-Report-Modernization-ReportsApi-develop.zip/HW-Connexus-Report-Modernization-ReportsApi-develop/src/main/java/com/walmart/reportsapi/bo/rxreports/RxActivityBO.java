package com.walmart.reportsapi.bo.rxreports;

import java.util.List;

import com.walmart.reportsapi.bo.audit.HeaderBO;

public class RxActivityBO {

	private Integer storeId;
	private String date;
	private String appName;
	private String store;
	private String reportName;
	private String details;
	private String note;
	private List<HeaderBO> header;
	private List<DataBO> data;

	public RxActivityBO() {
		super();

	}

	public RxActivityBO(Integer storeId, String date, String appName, String store, String reportName, String details,
			String note, List<HeaderBO> header, List<DataBO> data) {
		this.storeId = storeId;
		this.date = date;
		this.appName = appName;
		this.store = store;
		this.reportName = reportName;
		this.details = details;
		this.note = note;
		this.header = header;
		this.data = data;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getStore() {
		return store;
	}

	public void setStore(String store) {
		this.store = store;
	}

	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public List<HeaderBO> getHeader() {
		return header;
	}

	public void setHeader(List<HeaderBO> header) {
		this.header = header;
	}

	public List<DataBO> getData() {
		return data;
	}

	public void setData(List<DataBO> data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "RxActivityBO [storeId=" + storeId + ", date=" + date + ", appName=" + appName + ", store=" + store
				+ ", reportName=" + reportName + ", details=" + details + ", note=" + note + ", header=" + header
				+ ", data=" + data + ", getStoreId()=" + getStoreId() + ", getDate()=" + getDate() + ", getAppName()="
				+ getAppName() + ", getStore()=" + getStore() + ", getReportName()=" + getReportName()
				+ ", getDetails()=" + getDetails() + ", getNote()=" + getNote() + ", getHeader()=" + getHeader()
				+ ", getData()=" + getData() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}

}
