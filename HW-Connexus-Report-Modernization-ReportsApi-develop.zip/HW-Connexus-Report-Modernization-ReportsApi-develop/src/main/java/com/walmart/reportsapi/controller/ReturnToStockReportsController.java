/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report API team, Primary :Srilekha Kothapally(vn5101f)
 * Date: 2020/10/14
 * Version: 0.1
 * Description: This Controller class is responsible for getting  the AmberVial Inventory 
 * report details based on input request parameters from the big data tables
 * TABLES: rts_vial, pharmacy_item, pharmacy_product, pharmacy_offering:phm_item_cost, rts_vial_status_txt,rx_fill_item
 * The output is written to
 * 1. Request and Responses are generated in the JSON Format
 * 2. Informix and CosMos DB tables which is primarily used for Reports
 * 
 */
package com.walmart.reportsapi.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.walmart.reportsapi.bo.returntostockreports.AmberVialInventoryActivityBO;
import com.walmart.reportsapi.exception.ReportApiServiceException;
import com.walmart.reportsapi.service.ReturnToStockReportsService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/returntostock")
public class ReturnToStockReportsController {
	private static final Logger LOGGER = LoggerFactory.getLogger(ReturnToStockReportsController.class);

	@Autowired
	private ReturnToStockReportsService returnToStockReportsService;

	/**
	 * This Controller method is used to get the AmberVial Inventory report
	 * details based on the date range or VialId range
	 * @param String fromDate
	 * @param String toDate
	 * @param Integer storeId
	 * @param Integer reportOption
	 * @param Integer fromVialId
	 * @param Integer toVialId
	 * @return AmberVialInventoryActivityBO(Contains Report Details,Header Details and Report Data details)
	 * @throws ReportApiServiceException(Null Pointer/Record Not Found)
	 */
	
	@ApiOperation(value = "Get AmberVial Inventory Report Details by fromDate, toDate,storeId, reportOption,fromVialId,toVialId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error") })
	@RequestMapping(value = "/amber-vial-inventory", method = RequestMethod.GET, produces = "application/json")
	public AmberVialInventoryActivityBO getAmberVialInventoryReport(
			@RequestParam(required = false, value = "fromDate") String fromDate,
			@RequestParam(required = false, value = "toDate") String toDate,
			@RequestParam(required = true, value = "storeId") Integer storeId,
			@RequestParam(required = true, value = "reportOption") Integer reportOption,
			@RequestParam(required = false, value = "fromVialId") Integer fromVialId,
			@RequestParam(required = false, value = "toVialId") Integer toVialId) throws ReportApiServiceException {

		LOGGER.info("[AmberVialInventoryController] [getAmberVialInventoryReport] Method Starts");

		AmberVialInventoryActivityBO amberVialInventoryActivityBO = null;

		try {

			if ((!fromDate.equals("null") && !toDate.equals("null") && storeId != null)
					|| (!fromVialId.equals("null") && !toVialId.equals("null") && storeId != null)) {

				amberVialInventoryActivityBO = returnToStockReportsService.getAmberVialInventoryReport(fromDate, toDate,
						storeId, reportOption, fromVialId, toVialId);
			}
		} catch (ReportApiServiceException e) {
			LOGGER.error(
					"[AmberVialInventoryController][getAmberVialInventoryReport] Exception occurred while getting the AmberVialInventory Report :"
							+ e.getMessage(),
					e);
		}
		return amberVialInventoryActivityBO;
	}
}