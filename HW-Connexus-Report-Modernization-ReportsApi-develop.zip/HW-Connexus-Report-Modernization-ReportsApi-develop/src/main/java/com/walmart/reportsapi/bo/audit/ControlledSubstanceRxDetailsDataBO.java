package com.walmart.reportsapi.bo.audit;

public class ControlledSubstanceRxDetailsDataBO {

	private String rxIssueDate;
	private String rxNbr;
	private Integer sequenceId;
	private String patientName;
	private String patientAddress;
	private String drugName;
	private String quantity;
	private String supply;
	private String sig;
	private String prescriberName;
	private String prescriberAddress;
	private String dEA;
	
	public ControlledSubstanceRxDetailsDataBO() {
		super();

	}

	public ControlledSubstanceRxDetailsDataBO(String rxIssueDate, String rxNbr, Integer sequenceId, String patientName,
			String patientAddress, String drugName, String quantity, String supply, String sig, String prescriberName,
			String prescriberAddress, String dEA) {
		super();
		this.rxIssueDate = rxIssueDate;
		this.rxNbr = rxNbr;
		this.sequenceId = sequenceId;
		this.patientName = patientName;
		this.patientAddress = patientAddress;
		this.drugName = drugName;
		this.quantity = quantity;
		this.supply = supply;
		this.sig = sig;
		this.prescriberName = prescriberName;
		this.prescriberAddress = prescriberAddress;
		this.dEA = dEA;
	}

	public String getRxIssueDate() {
		return rxIssueDate;
	}

	public void setRxIssueDate(String rxIssueDate) {
		this.rxIssueDate = rxIssueDate;
	}

	public String getRxNbr() {
		return rxNbr;
	}

	public void setRxNbr(String rxNbr) {
		this.rxNbr = rxNbr;
	}

	public Integer getSequenceId() {
		return sequenceId;
	}

	public void setSequenceId(Integer sequenceId) {
		this.sequenceId = sequenceId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getPatientAddress() {
		return patientAddress;
	}

	public void setPatientAddress(String patientAddress) {
		this.patientAddress = patientAddress;
	}

	public String getDrugName() {
		return drugName;
	}

	public void setDrugName(String drugName) {
		this.drugName = drugName;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getSupply() {
		return supply;
	}

	public void setSupply(String supply) {
		this.supply = supply;
	}

	public String getSig() {
		return sig;
	}

	public void setSig(String sig) {
		this.sig = sig;
	}

	public String getPrescriberName() {
		return prescriberName;
	}

	public void setPrescriberName(String prescriberName) {
		this.prescriberName = prescriberName;
	}

	public String getPrescriberAddress() {
		return prescriberAddress;
	}

	public void setPrescriberAddress(String prescriberAddress) {
		this.prescriberAddress = prescriberAddress;
	}

	public String getdEA() {
		return dEA;
	}

	public void setdEA(String dEA) {
		this.dEA = dEA;
	}

	@Override
	public String toString() {
		return "ControlledSubstanceRxDetailsDataBO [rxIssueDate=" + rxIssueDate + ", rxNbr=" + rxNbr + ", sequenceId="
				+ sequenceId + ", patientName=" + patientName + ", patientAddress=" + patientAddress + ", drugName="
				+ drugName + ", quantity=" + quantity + ", supply=" + supply + ", sig=" + sig + ", prescriberName="
				+ prescriberName + ", prescriberAddress=" + prescriberAddress + ", dEA=" + dEA + "]";
	}

	
}
