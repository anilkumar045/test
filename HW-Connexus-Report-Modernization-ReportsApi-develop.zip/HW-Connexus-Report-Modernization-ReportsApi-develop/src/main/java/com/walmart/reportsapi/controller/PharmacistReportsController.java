/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report API team, Primary :Arjun(vn506kd)
 * Date: 2020/12/31
 * Version: 0.2
 * Description: This Controller class is responsible for getting  the Pharmacist Report
 * details based on input request parameters from the big data tables
 * TABLES: rxDec, patient_DEC, fill_December, DrugModel, pharmacy_code_txt, System_User
 * The output is written to
 * 1. Request and Responses are generated in the JSON Format
 * 2. Big Table tables which is primarily used for Reports
 * 
 */
package com.walmart.reportsapi.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.walmart.reportsapi.bo.pharmacistreports.DailyVisualVerifyCheckActivityBO;
import com.walmart.reportsapi.bo.pharmacistreports.FourPointCheckActivityBO;
import com.walmart.reportsapi.bo.pharmacistreports.PharmacistActivityReportBO;
import com.walmart.reportsapi.exception.ReportApiServiceException;
import com.walmart.reportsapi.service.PharmacistReportsService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/pharmacistreports")
public class PharmacistReportsController {

	private static final Logger LOGGER = LoggerFactory.getLogger(PharmacistReportsController.class);

	@Autowired
	PharmacistReportsService pharmacistReportsService;
	
	@ApiOperation(value = "Get PharmacistReports Details")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error") })

	@RequestMapping(value = "/4-point-check-report", method = RequestMethod.GET, produces = "application/json")
	public FourPointCheckActivityBO getFourPointCheckActivityDetails(@RequestParam(required = true, value = "storeId") String storeId,
			@RequestParam(required = true, value = "fromDate") String fromDate,
			@RequestParam(required = true, value = "toDate") String toDate) throws ReportApiServiceException {

		LOGGER.info("[FourPtCheckController][getFourPtActivityDetails] Method Starts");

		FourPointCheckActivityBO fourPointCheckActivity = null;
		try {
			if (!fromDate.equals("null") && !toDate.equals("null")) {

				fourPointCheckActivity = pharmacistReportsService.getFourPointCheckActivityService(storeId, fromDate, toDate);

			}

		} catch (ReportApiServiceException e) {
			LOGGER.error(
					"[FourPtCheckController][getFourPtActivityDetails] Exception occurred while getting the FourPtCheckActivityDetails :"
							+ e.getMessage(),
					e);

		}

		return fourPointCheckActivity;

	}

	@RequestMapping(value = "/pharmacist-activity", method = RequestMethod.GET, produces = "application/json")
	public PharmacistActivityReportBO getPharmacistActivityReportDetails(
			@RequestParam(required = true, value = "storeId") String storeId,
			@RequestParam("activityDate") String activityDate,
			@RequestParam(name = "userName", required = true) String userName) throws ReportApiServiceException {
		LOGGER.info("[PharmacistActivityController] [getPharmacistActivityReport] Method Starts");

		PharmacistActivityReportBO pharmacistActivityReportBO = null;
		pharmacistActivityReportBO = pharmacistReportsService.getPharmacistActivityReportService(storeId, activityDate,
				userName);

		LOGGER.info("[PharmacistActivityController] [getPharmacistActivityReport] Method End");
		return pharmacistActivityReportBO;
	}
	
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error") })

	@RequestMapping(value = "/daily-visual-verify", method = RequestMethod.GET, produces = "application/json")
	public DailyVisualVerifyCheckActivityBO getDailyVisualVerifyReport(@RequestParam("storeId") String storeId,
			@RequestParam(name = "fromDate") String fromDate, @RequestParam("toDate") String toDate) throws ReportApiServiceException {
		LOGGER.info("[DailyVisualVerifyController] [getDailyVisualVerifyReport] Method Starts");

		DailyVisualVerifyCheckActivityBO dailyVisualVerifyCheckActivity = null;
		dailyVisualVerifyCheckActivity = pharmacistReportsService.getDailyVisualVerifyReport(storeId,  fromDate,  toDate);

		LOGGER.info("[PharmacistActivityController] [getDailyVisualVerifyReport] Method End");
		return dailyVisualVerifyCheckActivity;
		
		
	}


}