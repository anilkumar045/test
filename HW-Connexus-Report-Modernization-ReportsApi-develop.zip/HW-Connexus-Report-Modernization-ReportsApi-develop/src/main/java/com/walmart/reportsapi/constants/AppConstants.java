package com.walmart.reportsapi.constants;

public class AppConstants {

	public static final String PROJECT_ID = "wmt-hnw-techmod-poc";
	public static final String INSTANCE_ID = "hnw-conx-poc";
	
	public static final String RXA_TABLE_ID = "rxDec";
	public static final String PATABLE_ID = "patient_DEC";
	public static final String RXF_TABLE_ID = "fill_December";
	public static final String PP_TABLE_ID = "DrugModel";
	public static final String PCT_TABLE_ID = "pharmacy_code_txt";	
	public static final String PIC_TABLE_ID = "pharmacy_item_cost";
	public static final String RTS_VIAL_CRT_TABLE_ID = "rts_vial_crt";
	public static final String RTS_VIAL_CHANGE_TABLE_ID = "rts_vial_change";
	public static final String RTS_VIAL_ID_TABLE_ID = "rts_vial_id";
	
	public static final String BAD_REQUEST = "Bad Request";
	public static final String SUCCESS_MSG = "Success";
	public static final String INTERNAL_SERVER_ERROR = "Internal Server Error";
	

}
