/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report API team, Primary :vn50w1f
 * Date: 2021/1/1
 * Version: 0.1
 * Description: RxActivity Service implementation class is used get the RxActivity
 * report details based on input request parameters
 * TABLES: rxDec, fill_December, System_User
 * The output is written to
 * 1. Request and Responses are generated in the JSON Format
 * 2. Big table is primarily used for Reports
 * 
 */

package com.walmart.reportsapi.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmart.reportsapi.bo.rxreports.RxActivityBO;

import com.walmart.reportsapi.repository.RxReportsDao;
import com.walmart.reportsapi.service.RxReportsService;

/**
 * RxActivityService implementation class is used get the RxActivity report
 * details based on input request parameters
 */
@Service
public class RxReportsServiceImpl implements RxReportsService {

	private static final Logger LOGGER = LoggerFactory.getLogger(RxReportsServiceImpl.class);

	@Autowired
	private RxReportsDao rxactivitydao;

	/**
	 * This service method is used to get the RxActivity report details based on
	 * rxNumber and fillDate
	 * 
	 * @param rxNumber
	 * @param fillDate
	 * @return RxActivityBO
	 * @throws Exception
	 */
	@Override
	public RxActivityBO getRxActivityReportService(String storeId, String rxNumber, String fillDate)
			throws ParseException {

		LOGGER.info("[RxActivityServiceImpl][getRxActivityReportService]Entered Method rxNumber:{} and fillDate:{}",
				rxNumber, fillDate);

		// SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy HH:MM:SS");
		//
		// Date fdate = new Date();
		// try {
		//
		// if (null != fillDate) {
		// fdate = sdf.parse(fillDate);
		// }
		// } catch (ParseException e) {
		//
		// LOGGER.error(
		// "[RxActivityController][getRxActivityDetails] Exception occurred
		// while getting the RxActivityDetails :"
		// + e.getMessage(),
		// e);
		// throw e;
		// }

		RxActivityBO rxactivity = rxactivitydao.getRxActivityReportRepository(storeId, rxNumber, fillDate);

		return rxactivity;
	}

}
