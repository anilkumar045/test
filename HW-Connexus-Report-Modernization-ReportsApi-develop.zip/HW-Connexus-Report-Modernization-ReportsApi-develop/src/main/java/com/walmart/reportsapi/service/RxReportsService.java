/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report API team, Primary :vn50w1f
 * Date: 2021/1/1
 * Version: 0.1
 * Description: The RxActivity Service Interface class is used to declare the
 * methods for service layer implementation
 * TABLES: rxDec, fill_December, System_User
 * The output is written to
 * 1. Request and Responses are generated in the JSON Format
 * 2. Big table is primarily used for Reports
 * 
 */

package com.walmart.reportsapi.service;

import java.text.ParseException;

import com.walmart.reportsapi.bo.rxreports.RxActivityBO;

/**
 * The RxActivity Service Interface class is used to declare the methods for
 * service layer implementation
 */
public interface RxReportsService {

	RxActivityBO getRxActivityReportService(String storeId, String rxNumber, String fillDate) throws ParseException;

}
