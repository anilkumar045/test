/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report API team, Primary :Arjun(vn506kd)
 * Date: 2020/12/31
 * Version: 0.2
 * Description: This ServiceImpl class is responsible for getting  the Four Point Check
 * report details based on input request parameters from the big data tables
 * TABLES: rxDec, patient_DEC, fill_December, DrugModel
 * The output is written to
 * 1. Request and Responses are generated in the JSON Format
 * 2. Big Table tables which is primarily used for Reports
 * 
 */
package com.walmart.reportsapi.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.walmart.reportsapi.bo.pharmacistreports.DailyVisualVerifyCheckActivityBO;
import com.walmart.reportsapi.bo.pharmacistreports.FourPointCheckActivityBO;
import com.walmart.reportsapi.bo.pharmacistreports.PharmacistActivityReportBO;
import com.walmart.reportsapi.exception.ReportApiServiceException;
import com.walmart.reportsapi.repository.PharmacistReportsDao;
import com.walmart.reportsapi.service.PharmacistReportsService;

/**
 * FourPointCheckService implementation class is used get the 4 point check
 * report details based on input request parameters
 */
@Service
public class PharmacistReportsServiceImpl implements PharmacistReportsService {
	private static final Logger LOGGER = LoggerFactory.getLogger(PharmacistReportsServiceImpl.class);

	@Autowired
	
	private PharmacistReportsDao fourPointCheckDAO;
	
	@Autowired
	private PharmacistReportsDao pharmacistActivityDAO;
	
	@Autowired
	public PharmacistReportsDao dailyVisualVerifyDAO;
	
	/**
	 * This Service method is used get the 4 Point check report details based on
	 * fromDate and toDate
	 * 
	 * @param fromDate
	 * @param toDate
	 * @return FourPtCheckActivityBO
	 * @throws ReportApiServiceException
	 */
	@Override
	public FourPointCheckActivityBO getFourPointCheckActivityService(String storeId, String fromDate, String toDate)
			throws ReportApiServiceException {
		FourPointCheckActivityBO fourpointactivity = null;
		try {

			fourpointactivity = fourPointCheckDAO.getFourPointCheckActivityRepository(storeId, fromDate, toDate);

		} catch (ReportApiServiceException e) {

			LOGGER.error(
					"[FourPtCheckController][getFourPtActivityDetails] Exception occurred while getting the FourPtcheckActivityDetails :"
							+ e.getMessage(),
					e);

		}

		return fourpointactivity;
	}
	
	@Override
	public PharmacistActivityReportBO getPharmacistActivityReportService(String storeId, String activityDate, String userName) throws ReportApiServiceException {
		LOGGER.info("[PharmacistActivityReportServiceImpl][getPharmacistActivityReport] method Entered ");
		PharmacistActivityReportBO pharmacistActivityReportBO = null;
		try{
			pharmacistActivityReportBO = pharmacistActivityDAO.getPharmacistActivityReportRepository(storeId, activityDate, userName);
		}catch (ReportApiServiceException e) {

			LOGGER.error(
					"[PharmacistActivity][getPharmacistActivityReport] Exception occurred while getting the getPharmacistActivityReport :"
							+ e.getMessage(),
					e);

		}
		//pharmacistActivityReportBO = pharmacistActivityReportDAO.getPharmacistActivityReport();
		//pharmacistActivityReportBO = setReportDetails();
		LOGGER.info("[PharmacistActivityReportServiceImpl][getPharmacistActivityReport] method End ");
		return pharmacistActivityReportBO;
	}
	
	public DailyVisualVerifyCheckActivityBO getDailyVisualVerifyReport(String storeId, String fromDate, String toDate) throws ReportApiServiceException{
		
		DailyVisualVerifyCheckActivityBO dailyVisualVerifyBO = null;
		dailyVisualVerifyBO = dailyVisualVerifyDAO.getDailyVisualVerifyReport(storeId,fromDate,toDate);
		LOGGER.info("[DailyVisualVerifyServiceImpl][getDailyVisualVerifyReport] method End ");
		return dailyVisualVerifyBO;
	}

}
