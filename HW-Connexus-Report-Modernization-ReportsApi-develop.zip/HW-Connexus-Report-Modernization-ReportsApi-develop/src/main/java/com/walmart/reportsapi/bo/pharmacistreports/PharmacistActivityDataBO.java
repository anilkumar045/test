package com.walmart.reportsapi.bo.pharmacistreports;

public class PharmacistActivityDataBO {
    
	private int rxNbr;
	private int unique;
	private String activity;

	public PharmacistActivityDataBO() {
		super();

	}

	public PharmacistActivityDataBO(int rxNbr, int unique, String activity) {
		super();
		this.rxNbr = rxNbr;
		this.unique = unique;
		this.activity = activity;
	}

	public int getRxNbr() {
		return rxNbr;
	}

	public void setRxNbr(int rxNbr) {
		this.rxNbr = rxNbr;
	}

	public int getUnique() {
		return unique;
	}

	public void setUnique(int unique) {
		this.unique = unique;
	}

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	@Override
	public String toString() {
		return "DataVO [rxNbr=" + rxNbr + ", unique=" + unique + ", activity=" + activity + "]";
	}

}