package com.walmart.reportsapi.bo;

public class StoreDetailsBO {
	
	private Integer storeNumber;
	private String appName;
	private String store;
	private String reportName;
	private String details;
	
	public StoreDetailsBO(Integer storeNumber, String appName, String store, String reportName, String details) {
		super();
		this.storeNumber = storeNumber;
		this.appName = appName;
		this.store = store;
		this.reportName = reportName;
		this.details = details;
	}
	
	public Integer getStoreNumber() {
		return storeNumber;
	}
	public void setStoreNumber(Integer storeNumber) {
		this.storeNumber = storeNumber;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getStore() {
		return store;
	}
	public void setStore(String store) {
		this.store = store;
	}
	public String getReportName() {
		return reportName;
	}
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}

}
