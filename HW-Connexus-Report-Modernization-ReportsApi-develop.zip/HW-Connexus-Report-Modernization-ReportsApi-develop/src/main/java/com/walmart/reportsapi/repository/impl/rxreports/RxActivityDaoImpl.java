/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report API team, Primary :vn50w1f
 * Date: 2021/1/1
 * Version: 0.1
 * Description: This DAO Interface class is used to declare the methods for
 * RxActivity DAO layer implementation
 * TABLES: rxDec, fill_December, System_User
 * The output is written to
 * 1. Request and Responses are generated in the JSON Format
 * 2. Big table is primarily used for Reports
 * 
 */

package com.walmart.reportsapi.repository.impl.rxreports;

import static com.google.cloud.bigtable.data.v2.models.Filters.FILTERS;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.google.api.gax.rpc.ServerStream;
import com.google.cloud.bigtable.data.v2.BigtableDataClient;
import com.google.cloud.bigtable.data.v2.models.Filters.InterleaveFilter;
import com.google.cloud.bigtable.data.v2.models.Query;
import com.google.cloud.bigtable.data.v2.models.Row;
import com.google.cloud.bigtable.data.v2.models.RowCell;
import com.walmart.reportsapi.bo.audit.HeaderBO;
import com.walmart.reportsapi.bo.rxreports.ActivitiesBO;
import com.walmart.reportsapi.bo.rxreports.DataBO;
import com.walmart.reportsapi.bo.rxreports.RxActivityBO;
import com.walmart.reportsapi.repository.RxReportsDao;

@Repository
public class RxActivityDaoImpl implements RxReportsDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(RxActivityDaoImpl.class);
	
	private static final String projectId = "wmt-hnw-techmod-poc";
	private static final String instanceId = "hnw-conx-poc";
	private static final String rxTableId = "rxDec";
	private static final String rxFillTableId = "fill_December";
	private static final String suTableId = "System_User";

	/**
	 * This DAO method is used to get the RxActivity report details based on
	 * rxNumber and fillDate
	 * 
	 * @param rxNumber
	 * @param fillDate
	 * @return RxActivityBO
	 */
	@Override
	public RxActivityBO getRxActivityReportRepository(String storeId, String rxNumber, String fillDate) {

		LOGGER.info("Generating Rx Acctivity Report for rxNbr: {} in store: {} with fill date: {}", rxNumber, storeId,
				fillDate);

		RxActivityBO rxactivity = getHardcodedResponse();
		List<DataBO> rxActivityResponseList = new ArrayList<>();

		LOGGER.info("Initializing BigTable Data Client");

		try (BigtableDataClient dataClient = BigtableDataClient.create(projectId, instanceId)) {

			SimpleDateFormat targetFormat = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat originalFormat = new SimpleDateFormat("MM/dd/yyyy");
			if (fillDate != null && !fillDate.isEmpty() && !fillDate.equalsIgnoreCase("null")) {
				fillDate = targetFormat.format(originalFormat.parse(fillDate.split(" ")[0]));
			}

			List<ActivitiesBO> rxActivities = readRowsRx(dataClient, storeId, rxNumber);

			if (!rxActivities.isEmpty()) {

				Map<String, HashSet<String>> rxIdFillIdsMap = new HashMap<String, HashSet<String>>();
				Map<String, List<ActivitiesBO>> fillActivitiesMap = new HashMap<String, List<ActivitiesBO>>();
				readRowsRxFill(dataClient, storeId, fillDate, rxActivities, rxIdFillIdsMap, fillActivitiesMap);

				if (!rxIdFillIdsMap.isEmpty()) {

					Map<String, String> userDescMap = readRowsSystemUser(dataClient, storeId, rxActivities,
							fillActivitiesMap);

					LOGGER.info("mapping activity lists to response BO");
					long postProcessStart = System.currentTimeMillis();
					Map<String, List<ActivitiesBO>> rxActivitiesMap = rxActivities.stream()
							.collect(Collectors.groupingBy(a -> a.getRxId()));
					for (String rxId : rxIdFillIdsMap.keySet()) {

						for (String fillId : rxIdFillIdsMap.get(rxId)) {

							for (ActivitiesBO rxActivity : rxActivitiesMap.get(rxId)) {

								String userid = rxActivity.getUserId().trim();
								String activityDate = rxActivity.getTimeStamp();
								String station = rxActivity.getType();
								String username = userDescMap.get(userid);

								DataBO iterData = new DataBO(rxNumber, 0, fillId, storeId, userid, activityDate,
										station, username);

								rxActivityResponseList.add(iterData);
							}

							if (fillActivitiesMap.get(fillId) != null) {
								for (ActivitiesBO fillActivity : fillActivitiesMap.get(fillId)) {

									String userid = fillActivity.getUserId().trim();
									String activityDate = fillActivity.getTimeStamp();
									String station = fillActivity.getType();
									String username = userDescMap.get(userid);

									DataBO iterData = new DataBO(rxNumber, 0, fillId, storeId, userid, activityDate,
											station, username);

									rxActivityResponseList.add(iterData);
								}
							}
						}
					}

					int unique = 0;
					rxActivityResponseList.sort(Comparator.comparing(DataBO::getActivityDate));
					for (DataBO rxa : rxActivityResponseList) {
						rxa.setUnique(++unique);
					}

					long postProcessEnd = System.currentTimeMillis();
					LOGGER.info(("Post process time = " + (postProcessEnd - postProcessStart)));
				}

			} else {
				LOGGER.info("No records found for rxNbr : " + rxNumber);
			}

			LOGGER.info("completed");
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Error in getRxActivityReportDetails : " + e.getMessage());
		}

		rxactivity.setData(rxActivityResponseList);
		rxactivity.setStoreId(Integer.parseInt(storeId));
		return rxactivity;

	}

	private Map<String, String> readRowsSystemUser(BigtableDataClient dataClient, String storeNbr,
			List<ActivitiesBO> rxActivities, Map<String, List<ActivitiesBO>> fillActivitiesMap) {
		long suQueryStart = System.currentTimeMillis();
		LOGGER.info("Querying table System User: " + suTableId);
		InterleaveFilter suFilter = FILTERS.interleave();
		rxActivities.stream().map(x -> x.getUserId()).collect(Collectors.toSet()).forEach(id -> {
			suFilter.filter(FILTERS.key().regex("^.+#" + id + "$"));
		});
		fillActivitiesMap.values().forEach(fills -> {
			fills.stream().map(x -> x.getUserId()).collect(Collectors.toSet()).forEach(id -> {
				suFilter.filter(FILTERS.key().regex("^.+#" + id + "$"));
			});
		});
		Query suQuery = Query.create(suTableId).prefix(storeNbr);
		ServerStream<Row> suRows = dataClient.readRows(suQuery);
		long suQueryEnd = System.currentTimeMillis();
		LOGGER.info(("System user dataClient.readRows = " + (suQueryEnd - suQueryStart)));

		long suStart = System.currentTimeMillis();
		Map<String, String> userDescMap = new HashMap<String, String>();
		for (Row row : suRows) {
			String[] keys = row.getKey().toStringUtf8().split("#");
			userDescMap.put(keys[2], keys[1]);
		}
		long suEnd = System.currentTimeMillis();
		LOGGER.info(("System user iteration time = " + (suEnd - suStart)));
		LOGGER.info("user desc map -> " + userDescMap.toString());
		return userDescMap;
	}

	private List<ActivitiesBO> readRowsRx(BigtableDataClient dataClient, String storeId, String rxNumber) {
		List<ActivitiesBO> rxActivities = new ArrayList<>();
		LOGGER.info("Querying table : " + rxTableId);
		long rxQueryStart = System.currentTimeMillis();
		Query rxQuery = Query.create(rxTableId).prefix(storeId)
				.filter(FILTERS.key().regex("^.+#" + rxNumber + "#.+$"));
		ServerStream<Row> rxRows = dataClient.readRows(rxQuery);
		long rxQueryEnd = System.currentTimeMillis();
		LOGGER.info(("Rx dataClient.readRows = " + (rxQueryEnd - rxQueryStart)));

		long rxStart = System.currentTimeMillis();
		for (Row row : rxRows) {
			LOGGER.info("Rx rowkey >>> " + row.getKey().toStringUtf8());
			String[] keys = row.getKey().toStringUtf8().split("#");
			storeId = keys[0];
			rxNumber = keys[7];
			String rxId = keys[2];
			String activityUserId = keys[3];
			String activityTimestamp = keys[1];

			long ts = 0;
			String type = null;
			List<RowCell> rxActivityTypeCells = row.getCells("RxActivity", "type");
			if (rxActivityTypeCells != null) {
				for (RowCell rowCell : rxActivityTypeCells) {
					if (rowCell.getTimestamp() > ts) {
						ts = rowCell.getTimestamp();
						type = rowCell.getValue().toStringUtf8();
					}
				}
			}

			ActivitiesBO activity = new ActivitiesBO();
			activity.setRxId(rxId);
			activity.setType(type);
			activity.setTimeStamp(activityTimestamp);
			activity.setUserId(activityUserId);

			if (type.equals("INPUT") || type.equals("4PNTCHEK")) {
				rxActivities.add(activity);
			}
		}
		long rxEnd = System.currentTimeMillis();
		LOGGER.info(("Rx iteration time = " + (rxEnd - rxStart)));
		return rxActivities;
	}

	private void readRowsRxFill(BigtableDataClient dataClient, String storeId, String fillDate,
			List<ActivitiesBO> rxActivities, Map<String, HashSet<String>> rxIdFillIdsMap,
			Map<String, List<ActivitiesBO>> fillActivitiesMap) {
		// storeNbr#rxId#fillDate#rxFillId#DAW#activityTimestamp#activityUserId
		LOGGER.info("Querying table : " + rxFillTableId);
		long rxfQueryStart = System.currentTimeMillis();
		Query rxFillQuery = Query.create(rxFillTableId);
		rxActivities.stream().collect(Collectors.groupingBy(ActivitiesBO::getRxId)).keySet().forEach(id -> {
			rxFillQuery.prefix(storeId + "#" + id + "#");
		});
		ServerStream<Row> rxFillRows = dataClient.readRows(rxFillQuery);
		long rxfQueryEnd = System.currentTimeMillis();
		LOGGER.info(("Fill dataClient.readRows = " + (rxfQueryEnd - rxfQueryStart)));

		long rxfStart = System.currentTimeMillis();

		for (Row r : rxFillRows) {
			LOGGER.info("Fill rowkey >>> " + r.getKey().toStringUtf8());
			String[] keys = r.getKey().toStringUtf8().split("#");
			String rxId = keys[1];
			String fillId = keys[3];
			String fillActivityUserId = keys[6];
			String fillActivityTimestamp = keys[5];

			String fill_date = keys[2];
			Boolean isValidFillActivity = false;
			if (fillDate == null || fillDate.isEmpty() || fillDate.equalsIgnoreCase("null")) {
				isValidFillActivity = true;
			} else if (fillDate.equals(fill_date)) {
				isValidFillActivity = true;
			}

			if (isValidFillActivity) {
				if (rxIdFillIdsMap.containsKey(rxId)) {
					rxIdFillIdsMap.get(rxId).add(fillId);
				} else {
					rxIdFillIdsMap.put(rxId, new HashSet<String>(Arrays.asList(fillId)));
				}
			}

			long fillts = 0;
			String type = null;
			List<RowCell> fillActivityTypeCells = r.getCells("Fill", "type");
			if (fillActivityTypeCells != null) {
				for (RowCell rowCell : fillActivityTypeCells) {
					if (rowCell.getTimestamp() > fillts) {
						fillts = rowCell.getTimestamp();
						type = rowCell.getValue().toStringUtf8();
					}
				}
			}

			ActivitiesBO activity = new ActivitiesBO();
			activity.setRxId(rxId);
			activity.setType(type);
			activity.setTimeStamp(fillActivityTimestamp);
			activity.setUserId(fillActivityUserId);

			if (isValidFillActivity && (type.equals("FILLED") || type.equals("VSULCHEK") || type.equals("DURCHK")
					|| type.equals("COUNSEL"))) {
				if (fillActivitiesMap.containsKey(fillId)) {
					fillActivitiesMap.get(fillId).add(activity);
				} else {
					fillActivitiesMap.put(fillId, new ArrayList<ActivitiesBO>(Arrays.asList(activity)));
				}
			}
		}
		long rxfEnd = System.currentTimeMillis();
		LOGGER.info(("Fill iteration time = " + (rxfEnd - rxfStart)));
		LOGGER.info("rxId fillIds map -> " + rxIdFillIdsMap.toString());
		LOGGER.info("valid fill IDs -> " + fillActivitiesMap.keySet().toString());
	}
	
	private RxActivityBO getHardcodedResponse() {
		List<DataBO> data = new ArrayList<>();
		List<HeaderBO> header = new ArrayList<>();

		String date = "11/06/2020";
		Integer storeId = 5534;
		String appName = "Connexus Pharmacy System";
		String store = "Wal-Mart Pharmacy10-5533";
		String reportName = "Activity Report";
		String details = "5533 LOOP 410 NORTHWEST 5025 TRUTH OR CONSEQUENCE TRU COTRUTH OR CONSEQUENCE SC - 72712";
		String note = "* Blank store number indicates local store activity";

		header.add(new HeaderBO("Rx Nbr", "rxNbr"));
		header.add(new HeaderBO("Fill Nbr", "fillNbr"));
		header.add(new HeaderBO("Store Nbr", "storeNbr"));
		header.add(new HeaderBO("User Id", "userid"));
		header.add(new HeaderBO("User Name", "username"));
		header.add(new HeaderBO("Activity Date", "activityDate"));
		header.add(new HeaderBO("Station", "station"));

		return new RxActivityBO(storeId, date, appName, store, reportName, details, note, header, data);
	}
	
}
