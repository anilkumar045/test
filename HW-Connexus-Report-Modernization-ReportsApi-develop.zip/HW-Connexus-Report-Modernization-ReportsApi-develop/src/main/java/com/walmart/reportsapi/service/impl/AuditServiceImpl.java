package com.walmart.reportsapi.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmart.reportsapi.bo.audit.ControlledSubstanceRxDetailsBO;
import com.walmart.reportsapi.repository.AuditDao;
import com.walmart.reportsapi.service.AuditService;
@Service
public class AuditServiceImpl implements AuditService {
	private static final Logger LOGGER = LoggerFactory.getLogger(AuditServiceImpl.class);
	
	@Autowired
	private AuditDao auditDao;
	
	@Override
	public ControlledSubstanceRxDetailsBO getControlledSubstanceRxDetailsService(String storeId, String fromDate,
			String toDate) {
		
		ControlledSubstanceRxDetailsBO controlledSubstanceRxDetails = null;
		
		try {
			controlledSubstanceRxDetails = auditDao.getControlledSubstanceRxDetailsRepository(storeId, fromDate, toDate);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return controlledSubstanceRxDetails;
	}

}
