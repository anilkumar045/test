
/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report API team, Primary :vn50w1f
 * Date: 2021/1/1
 * Version: 0.1
 * Description: This Controller class is responsible for getting  the RxActivity
 * report details based on input request parameters from the big data tables
 * TABLES: rxDec, fill_December, System_User
 * The output is written to
 * 1. Request and Responses are generated in the JSON Format
 * 2. Big table is primarily used for Reports
 * 
 */

package com.walmart.reportsapi.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.walmart.reportsapi.bo.rxreports.RxActivityBO;
import com.walmart.reportsapi.service.RxReportsService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * RxActivity Controller class is used get the RxActivity report details based
 * on input request parameters
 */
@RestController
@RequestMapping("/rxreport")
public class RxReportsController {

	private static final Logger LOGGER = LoggerFactory.getLogger(RxReportsController.class);

	@Autowired
	private RxReportsService rxReportsService;

	@RequestMapping(value = "/rx-activity", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "Get rxreport Details by rxNumber  and fillDate")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error") })

	@GetMapping(produces = "application/Json")
	public RxActivityBO getRxActivityReportDetails(@RequestParam(value = "storeId") String storeId,
			@RequestParam(value = "rxNumber") String rxNumber,
			@RequestParam(required = false, value = "fillDate") String fillDate) throws Exception {

		LOGGER.info("[RxActivityController][getRxActivityDetails] Methos starts");

		RxActivityBO rxactivity = null;

		try {
			if (rxNumber != null) {

				rxactivity = rxReportsService.getRxActivityReportService(storeId, rxNumber, fillDate);
			}

		} catch (Exception e) {
			LOGGER.error(
					"[RxActivityController][getRxActivityDetails] Exception occurred while getting the RxActivityDetails :"
							+ e.getMessage(),
					e);

		}

		return rxactivity;

	}

}
