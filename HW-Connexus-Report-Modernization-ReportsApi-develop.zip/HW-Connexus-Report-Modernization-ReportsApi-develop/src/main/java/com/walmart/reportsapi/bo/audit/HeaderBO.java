package com.walmart.reportsapi.bo.audit;

public class HeaderBO {

	private String label;
	private String id;

	public HeaderBO() {
		super();

	}

	public HeaderBO(String label, String id) {
		super();
		this.label = label;
		this.id = id;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "HeaderBO [label=" + label + ", id=" + id + "]";
	}

}
