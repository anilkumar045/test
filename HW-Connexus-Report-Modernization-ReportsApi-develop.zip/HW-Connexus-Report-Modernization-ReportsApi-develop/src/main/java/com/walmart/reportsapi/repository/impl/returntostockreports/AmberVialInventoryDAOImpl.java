/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report API team, Primary :Srilekha kothapally(vn5101f)
 * Date: 2020/10/14
 * Version: 0.1
 * Description: AmberVialInventory DAO implementation class is used get the AmberVialInventory
 * report details based on input request parameters from BigTable
 * TABLES: rts_vial_crt,rts_vial_change,rts_vial_id, DrugModel, pharmacy_item_cost,fill_December
 * The output is written to
 * 1. Request and Responses are generated in the JSON Format
 * 2. Informix and CosMos DB tables which is primarily used for Reports
 * 
 */
package com.walmart.reportsapi.repository.impl.returntostockreports;

import static com.google.cloud.bigtable.data.v2.models.Filters.FILTERS;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.google.api.gax.rpc.ServerStream;
import com.google.cloud.bigtable.data.v2.BigtableDataClient;
import com.google.cloud.bigtable.data.v2.models.Filters.InterleaveFilter;
import com.google.cloud.bigtable.data.v2.models.Query;
import com.google.cloud.bigtable.data.v2.models.Row;
import com.google.cloud.bigtable.data.v2.models.RowCell;
import com.walmart.reportsapi.bo.audit.HeaderBO;
import com.walmart.reportsapi.bo.returntostockreports.AmberVialInventoryActivityBO;
import com.walmart.reportsapi.bo.returntostockreports.AmberVialInventoryBO;
import com.walmart.reportsapi.bo.returntostockreports.AmberVialInventoryDataBO;
import com.walmart.reportsapi.bo.returntostockreports.AmberVialInventoryStoreDetailsBO;
import com.walmart.reportsapi.constants.ReportsApiConstants;
import com.walmart.reportsapi.exception.ReportApiServiceException;
import com.walmart.reportsapi.repository.ReturnToStockReportsDao;

@Repository
public class AmberVialInventoryDAOImpl implements ReturnToStockReportsDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(AmberVialInventoryDAOImpl.class);

	AmberVialInventoryActivityBO amberVialInventoryActivityBO = null;

	String projectId = ReportsApiConstants.PROJECT_ID;
	String instanceId = ReportsApiConstants.INSTANCE_ID;
	String rtsVialTableId = ReportsApiConstants.RTS_VIAL_CRT_TABLE_ID;
	String rtsVialTableId2 = ReportsApiConstants.RTS_VIAL_CHANGE_TABLE_ID;
	String rtsVialTableId3 = ReportsApiConstants.RTS_VIAL_ID_TABLE_ID;
	String piTableId = ReportsApiConstants.PP_TABLE_ID;
	String rxfTableId = ReportsApiConstants.RXF_TABLE_ID;
	String picostTableId = ReportsApiConstants.PIC_TABLE_ID;

	List<AmberVialInventoryBO> amberBO;
	List<AmberVialInventoryDataBO> finalData;
	int rowCount = 0;

	@Override
	public AmberVialInventoryActivityBO getAmberVialInventoryReport(String fromDate, String toDate, Integer storeId,
			Integer reportOption, Integer fromVialId, Integer toVialId) throws ReportApiServiceException {

		amberVialInventoryActivityBO = new AmberVialInventoryActivityBO();
		amberBO = new ArrayList<AmberVialInventoryBO>();
		finalData = new ArrayList<AmberVialInventoryDataBO>();
		String from = "";
		String to = "";

		try {
			SimpleDateFormat targetFormat = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat originalFormat = new SimpleDateFormat("MM/dd/yyyy");

			getHeaderDetails(storeId, fromDate.split(" ")[0], toDate.split(" ")[0]);

			from = targetFormat.format(originalFormat.parse(fromDate.split(" ")[0])) + " 00:00:00";
			to = targetFormat.format(originalFormat.parse(toDate.split(" ")[0])) + " 23:59:59";
			LOGGER.info("formatted input dates : " + from + " and " + to);

		} catch (Exception e) {
			LOGGER.error("Error while parsing input date : " + e.getMessage());
		}

		LOGGER.info("Creating BigTable Data Client");
		try (BigtableDataClient dataClient = BigtableDataClient.create(projectId, instanceId)) {

			// If created date radio button is selected, report option= 4
			if (reportOption == 4) {
				LOGGER.info("Querying " + rtsVialTableId + " bigtable with range row filter using create_ts");
				readRowsRtsVialCrt(dataClient, from, to);
			}

			// If last change radio button is selected, report option = 5
			else if (reportOption == 5) {
				LOGGER.info("Querying " + rtsVialTableId2 + " bigtable with range row filter using last_change_ts");
				readRowsRtsVialChange(dataClient, from, to);
			}

			// If Vial range is selected, report option=6
			else if (reportOption == 6) {
				LOGGER.info("Querying " + rtsVialTableId3 + " bigtable with range row filter using rtsVialId");
				readRowsRtsVialId(dataClient, fromVialId, toVialId);
			}

			if (!amberBO.isEmpty()) {
				LOGGER.info("Querying DrugModel table using mdsFamId");
				readRowsDrugModel(dataClient);

				LOGGER.info("Querying fill_December(rx_fill) table using rxfId, storeNbr");
				readRowsFill(dataClient, storeId);

				LOGGER.info("Querying pharmacy_item_cost table using mdsFamId");
				readRowsPharmacyItemCost(dataClient);

			}

			long responseBuildStart = System.currentTimeMillis();
			LOGGER.info(("Start time for response building" + new Timestamp(responseBuildStart)));

			for (AmberVialInventoryBO a : amberBO) {
				AmberVialInventoryDataBO dataBO = new AmberVialInventoryDataBO();
				dataBO.setVialId(Integer.parseInt(a.getRtsVialId()));
				dataBO.setNdc(a.getNdcNumber());
				dataBO.setDrugDescription(a.getShortName());
				dataBO.setOriginalCost(a.getCostAmt());
				dataBO.setCurrentQuantity(a.getItem_qty());
				dataBO.setOriginalQuantity(a.getFillQty());
				dataBO.setCreateDate(a.getCreatets());
				dataBO.setExpirationDate(a.getVialExpirationDate());
				dataBO.setUserId(a.getLastChangeUSerId());
				dataBO.setTimeStamp(a.getLastChangets());
				dataBO.setStatus(a.getRtsVialStatusDescription());

				finalData.add(dataBO);

			}

			long responseBuildEnd = System.currentTimeMillis();
			LOGGER.info(("End time for response building" + new Timestamp(responseBuildEnd)));
			LOGGER.info(("Difference in millis = " + (responseBuildEnd - responseBuildStart)));
			// LOGGER.info("Printing finalData : " + finalData);
			if (finalData != null) {
				amberVialInventoryActivityBO.setData(finalData);
			}
			LOGGER.info("Amber Vial Inventory Report completed");
		} catch (IOException e) {

			e.printStackTrace();
		}

		return amberVialInventoryActivityBO;
	}

	private void readRowsRtsVialCrt(BigtableDataClient dataClient, String from, String to) {

		long rtsQueryStart = System.currentTimeMillis();
		LOGGER.info(("Start time for read rts_vial:" + new Timestamp(rtsQueryStart)));

		// Querying rts_vial_crt table with create_ts
		Query rtsVialQuery = Query.create(rtsVialTableId).range(from, to);
		ServerStream<Row> rxRows = dataClient.readRows(rtsVialQuery);

		long rtsQueryEnd = System.currentTimeMillis();

		LOGGER.info(("End time for read rts_vial:" + new Timestamp(rtsQueryEnd)));
		LOGGER.info(("Difference in millis = " + (rtsQueryEnd - rtsQueryStart)));
		long rtsJavaStart = System.currentTimeMillis();
		LOGGER.info(("Start time for Java Processing for Rts table:" + new Timestamp(rtsJavaStart)));
		for (Row row : rxRows) {
			AmberVialInventoryBO av = new AmberVialInventoryBO();
			String rowKey = row.getKey().toStringUtf8();
			String[] keys = rowKey.split("#");
			Integer size = keys.length;
			if (size == 3) {
				av.setCreatets(keys[0]);
				// LOGGER.info("CreateTS:" + keys[0]);
				av.setMdsFamId(keys[1]);
				// LOGGER.info("MDSFamId:" + keys[1]);
				av.setRx_fill_id(keys[2]);
				// LOGGER.info("RXFillId:" + keys[2]);
				for (RowCell c : row.getCells("colf1", "rtsVialId")) {
					av.setRtsVialId(c.getValue().toStringUtf8());
					// LOGGER.info("Vial Id:" + av.getRtsVialId());
				}
				for (RowCell c : row.getCells("colf1", "itemqty")) {
					av.setItem_qty(c.getValue().toStringUtf8());
					// LOGGER.info("Item qty:" + av.getItem_qty());
				}
				for (RowCell c : row.getCells("colf1", "vialExpirationDate")) {
					av.setVialExpirationDate(c.getValue().toStringUtf8());
					// LOGGER.info("vialExpirationDate:" +
					// av.getVialExpirationDate());
				}
				for (RowCell c : row.getCells("colf1", "lastChangeUSerId")) {
					av.setLastChangeUSerId(c.getValue().toStringUtf8());
					// LOGGER.info("LastChangeUSerId:" +
					// av.getLastChangeUSerId());
				}
				for (RowCell c : row.getCells("colf1", "lastChangets")) {
					av.setLastChangets(c.getValue().toStringUtf8());
					// LOGGER.info("LastChangeTs:" + av.getLastChangets());
				}
				for (RowCell c : row.getCells("colf1", "rtsVialStatusCode")) {
					av.setRtsVialStatusCode(c.getValue().toStringUtf8());
					// LOGGER.info("RtsVialStatusCode:" +
					// av.getRtsVialStatusCode());
				}
				for (RowCell c : row.getCells("colf1", "rtsVialStatusDescription")) {
					av.setRtsVialStatusDescription(c.getValue().toStringUtf8());
					// LOGGER.info("RtsVialStatusDescription:" +
					// av.getRtsVialStatusDescription());
				}

				amberBO.add(av);
			}
		}
		long rtsJavaEnd = System.currentTimeMillis();
		LOGGER.info("Size of amberBO:" + amberBO.size());
		LOGGER.info(("End time for Java Processing for rts_vial_crt table:" + new Timestamp(rtsJavaEnd)));
		LOGGER.info(("Difference in millis = " + (rtsJavaEnd - rtsJavaStart)));
	}

	private void readRowsRtsVialChange(BigtableDataClient dataClient, String from, String to) {
		// Querying rts_vial_change table with last_change_ts
		Query rtsVialQuery = Query.create(rtsVialTableId2).range(from, to);
		ServerStream<Row> rxRows = dataClient.readRows(rtsVialQuery);
		long rtsQueryStart = System.currentTimeMillis();
		long rtsQueryEnd = System.currentTimeMillis();

		LOGGER.info(("End time for read rts_vial:" + new Timestamp(rtsQueryEnd)));
		LOGGER.info(("Difference in millis = " + (rtsQueryEnd - rtsQueryStart)));
		long rtsJavaStart = System.currentTimeMillis();
		LOGGER.info(("Start time for Java Processing for Rts table:" + new Timestamp(rtsJavaStart)));
		for (Row row : rxRows) {
			AmberVialInventoryBO av = new AmberVialInventoryBO();
			String rowKey = row.getKey().toStringUtf8();
			String[] keys = rowKey.split("#");
			Integer size = keys.length;
			if (size == 3) {
				av.setLastChangets(keys[0]);
				// LOGGER.info("LastChangets:" + keys[0]);
				av.setMdsFamId(keys[1]);
				// LOGGER.info("MDSFamId:" + keys[1]);
				av.setRx_fill_id(keys[2]);
				// LOGGER.info("RXFillId:" + keys[2]);
				for (RowCell c : row.getCells("colf1", "createts")) {
					av.setCreatets(c.getValue().toStringUtf8());
					// LOGGER.info("Create TS:" + av.getCreatets());
				}

				for (RowCell c : row.getCells("colf1", "rtsVialId")) {
					av.setRtsVialId(c.getValue().toStringUtf8());
					// LOGGER.info("RtsVialId:" + av.getRtsVialId());
				}
				for (RowCell c : row.getCells("colf1", "itemqty")) {
					av.setItem_qty(c.getValue().toStringUtf8());
					// LOGGER.info("Itemqty:" + av.getItem_qty());
				}
				for (RowCell c : row.getCells("colf1", "vialExpirationDate")) {
					av.setVialExpirationDate(c.getValue().toStringUtf8());
					// LOGGER.info("VialExpirationDate:" +
					// av.getVialExpirationDate());
				}
				for (RowCell c : row.getCells("colf1", "lastChangeUSerId")) {
					av.setLastChangeUSerId(c.getValue().toStringUtf8());
					// LOGGER.info("lastChangeUSerId:" +
					// av.getLastChangeUSerId());
				}

				for (RowCell c : row.getCells("colf1", "rtsVialStatusCode")) {
					av.setRtsVialStatusCode(c.getValue().toStringUtf8());
					// LOGGER.info("RtsVialStatusCode:" +
					// av.getRtsVialStatusCode());
				}
				for (RowCell c : row.getCells("colf1", "rtsVialStatusDescription")) {
					av.setRtsVialStatusDescription(c.getValue().toStringUtf8());
					// LOGGER.info("rtsVialStatusDescription:" +
					// av.getRtsVialStatusDescription());
				}

				amberBO.add(av);
			}
		}
		long rtsJavaEnd = System.currentTimeMillis();
		LOGGER.info("Size of amberBO:" + amberBO.size());
		LOGGER.info(("End time for Java Processing for rts_vial_change table:" + new Timestamp(rtsJavaEnd)));
		LOGGER.info(("Difference in millis = " + (rtsJavaEnd - rtsJavaStart)));
	}

	private void readRowsRtsVialId(BigtableDataClient dataClient, Integer fromVialId, Integer toVialId) {
		// String fromId = Integer.toString(fromVialId);
		// String toId = Integer.toString(toVialId);
		Query rtsVialQuery = Query.create(rtsVialTableId3);
		for (int i = fromVialId; i <= toVialId; i++) {
			rtsVialQuery.prefix(i + "#");
		}

		ServerStream<Row> rxRows = dataClient.readRows(rtsVialQuery);
		long rtsQueryStart = System.currentTimeMillis();
		long rtsQueryEnd = System.currentTimeMillis();

		LOGGER.info(("End time for read rts_vial" + new Timestamp(rtsQueryEnd)));
		LOGGER.info(("Difference in millis = " + (rtsQueryEnd - rtsQueryStart)));
		long rtsJavaStart = System.currentTimeMillis();
		LOGGER.info(("Start time for Java Processing for Rts table:" + new Timestamp(rtsJavaStart)));
		for (Row row : rxRows) {
			AmberVialInventoryBO av = new AmberVialInventoryBO();
			String rowKey = row.getKey().toStringUtf8();
			LOGGER.info("rowKey for rts_vial_id : " + rowKey);
			String[] keys = rowKey.split("#");
			Integer size = keys.length;
			if (size == 3) {
				av.setRtsVialId(keys[0]);
				// LOGGER.info("RtsVialId:" + keys[0]);
				av.setMdsFamId(keys[1]);
				// LOGGER.info("MDSFamId:" + keys[1]);

				av.setRx_fill_id(keys[2]);
				// LOGGER.info("RXFillId:" + keys[2]);

				for (RowCell c : row.getCells("colf1", "createts")) {
					av.setCreatets(c.getValue().toStringUtf8());
					// LOGGER.info(av.getRtsVialId());
				}

				for (RowCell c : row.getCells("colf1", "itemqty")) {
					av.setItem_qty(c.getValue().toStringUtf8());
					// LOGGER.info(av.getItem_qty());
				}
				for (RowCell c : row.getCells("colf1", "vialExpirationDate")) {
					av.setVialExpirationDate(c.getValue().toStringUtf8());
					// LOGGER.info(av.getVialExpirationDate());
				}
				for (RowCell c : row.getCells("colf1", "lastChangeUSerId")) {
					av.setLastChangeUSerId(c.getValue().toStringUtf8());
					// LOGGER.info(av.getLastChangeUSerId());
				}

				for (RowCell c : row.getCells("colf1", "lastChangets")) {
					av.setLastChangets(c.getValue().toStringUtf8());
					// LOGGER.info(av.getLastChangets());
				}
				for (RowCell c : row.getCells("colf1", "rtsVialStatusCode")) {
					av.setRtsVialStatusCode(c.getValue().toStringUtf8());
					// LOGGER.info(av.getRtsVialStatusCode());
				}
				for (RowCell c : row.getCells("colf1", "rtsVialStatusDescription")) {
					av.setRtsVialStatusDescription(c.getValue().toStringUtf8());
					// LOGGER.info(av.getRtsVialStatusDescription());
				}
				amberBO.add(av);
			}

		}

		long rtsJavaEnd = System.currentTimeMillis();
		LOGGER.info("Size of amberBO:" + amberBO.size());
		LOGGER.info(("End time for Java Processing for Rts table:" + new Timestamp(rtsJavaEnd)));
		LOGGER.info(("Difference in millis = " + (rtsJavaEnd - rtsJavaStart)));

	}

	private void readRowsDrugModel(BigtableDataClient dataClient) {
		// Querying DrugModel table with mdsFamId
		Query piQuery = Query.create(piTableId);

		amberBO.stream().collect(Collectors.groupingBy(AmberVialInventoryBO::getMdsFamId)).keySet().forEach(id -> {
			piQuery.prefix(id);
		});

		long piQueryStart = System.currentTimeMillis();
		LOGGER.info(("Start time for reading DrugModel:" + new Timestamp(piQueryStart)));
		ServerStream<Row> piRows = dataClient.readRows(piQuery);

		long piQueryEnd = System.currentTimeMillis();

		LOGGER.info(("End time for read DrugModel" + new Timestamp(piQueryEnd)));
		LOGGER.info(("Difference in millis = " + (piQueryEnd - piQueryStart)));
		long piJavaStart = System.currentTimeMillis();
		LOGGER.info(("Start time for Java Processing for DrugModel table:" + new Timestamp(piJavaStart)));
		rowCount = 0;
		for (Row r : piRows) {
			rowCount++;
			String rowkey = r.getKey().toStringUtf8();
			// LOGGER.info(" rowkey -> " + rowkey);
			String mdsFamId = rowkey.split("#")[0];
			// LOGGER.info(" mdsFamId -> " + mdsFamId);
			String ndcNumber = "";
			String shortName = "";
			for (RowCell c : r.getCells("drug", "ndcNumber")) {
				ndcNumber = c.getValue().toStringUtf8();
				// LOGGER.info("ndcNumber" + ndcNumber);
			}

			for (RowCell c : r.getCells("drug", "shortName")) {
				shortName = c.getValue().toStringUtf8();
				// LOGGER.info("shortName" + shortName);
			}

			final String nbcNumberFinal = ndcNumber;
			final String shortNameFinal = shortName;

			amberBO.stream().forEach(obj -> {
				if (obj.getMdsFamId().equals(mdsFamId)) {
					obj.setNdcNumber(nbcNumberFinal);
					obj.setShortName(shortNameFinal);
				}
			});
		}

		long piJavaEnd = System.currentTimeMillis();
		LOGGER.info(("End time for Java Processing for DrugModel table:" + new Timestamp(piJavaEnd)));
		LOGGER.info(("Difference in millis = " + (piJavaEnd - piJavaStart)));
		LOGGER.info("DrugModel Volume : " + rowCount);
	}

	private void readRowsFill(BigtableDataClient dataClient, Integer storeId) {
		String storeNbr = String.valueOf(storeId);

		InterleaveFilter rxfFilter = FILTERS.interleave();
		amberBO.stream().collect(Collectors.groupingBy(AmberVialInventoryBO::getRx_fill_id)).keySet()
				.forEach(rx_fillid -> {
					rxfFilter.filter(FILTERS.key().regex("^.+#" + rx_fillid + "#.+$"));
				});
		Query rxfQuery = Query.create(rxfTableId).prefix(storeNbr).filter(rxfFilter);
		long rxfQueryStart = System.currentTimeMillis();
		LOGGER.info(("Start time to read rx_fill:" + new Timestamp(rxfQueryStart)));

		ServerStream<Row> rxfRows = dataClient.readRows(rxfQuery);

		long rxfQueryEnd = System.currentTimeMillis();
		LOGGER.info(("End time to read rx_fill:" + new Timestamp(rxfQueryEnd)));
		LOGGER.info(("Difference in millis = " + (rxfQueryEnd - rxfQueryStart)));

		long rxfJavaStart = System.currentTimeMillis();
		LOGGER.info(("Start time for Java Processing of rx_fill:" + new Timestamp(rxfJavaStart)));

		rowCount = 0;
		for (Row rxf : rxfRows) {
			rowCount++;
			String rowkey = rxf.getKey().toStringUtf8();
			String rxfId = rowkey.split("#")[3];
			// LOGGER.info("rxfId" + rxfId);

			String fillQuantity = "";

			for (RowCell cell : rxf.getCells("Fill", "fillQty")) {
				fillQuantity = cell.getValue().toStringUtf8();
				// LOGGER.info("fillQuantity" + fillQuantity);
			}

			final String fillQuantityFinal = fillQuantity;
			amberBO.stream().forEach(obj -> {
				if (obj.getRx_fill_id().equals(rxfId)) {
					obj.setFillQty(fillQuantityFinal);
				}
			});

		}
		long rxfJavaEnd = System.currentTimeMillis();
		LOGGER.info(("End time for Java Processing of rx_fill" + new Timestamp(rxfJavaEnd)));
		LOGGER.info(("Difference in millis = " + (rxfJavaEnd - rxfJavaStart)));
		LOGGER.info("Volume of rx_fill : " + rowCount);
	}

	private void readRowsPharmacyItemCost(BigtableDataClient dataClient) {

		Query picostQuery = Query.create(picostTableId);

		amberBO.stream().collect(Collectors.groupingBy(AmberVialInventoryBO::getMdsFamId)).keySet()
				.forEach(mdsFamId -> {
					picostQuery.prefix(mdsFamId);
				});

		long picostQueryStart = System.currentTimeMillis();
		LOGGER.info(("Start time to read pharmacy_item_cost:" + new Timestamp(picostQueryStart)));

		ServerStream<Row> picostRows = dataClient.readRows(picostQuery);
		// ServerStream<Row> picostRows1 = dataClient.readRows(picostQuery);

		long picostQueryEnd = System.currentTimeMillis();
		LOGGER.info(("End time to read pharmacy_item_cost:" + new Timestamp(picostQueryEnd)));
		LOGGER.info(("Difference in millis = " + (picostQueryEnd - picostQueryStart)));

		long picostJavaStart = System.currentTimeMillis();
		LOGGER.info(("Start time for Java Processing of pharmacy_item_cost:" + new Timestamp(picostJavaStart)));

		List<LocalDate> dateList = new ArrayList<>();
		rowCount = 0;
		for (Row picost : picostRows) {
			rowCount++;
			String rowkey = picost.getKey().toStringUtf8();
			String mdsFamId = rowkey.split("#")[0];
			// LOGGER.info("mdsFamId : " + mdsFamId);
			String costAmt = "";
			String costTypeCode = "";
			String effectiveDate = "";

			for (RowCell cell : picost.getCells("drug", "costAmt")) {
				costAmt = cell.getValue().toStringUtf8();
				// LOGGER.info("costAmt" + costAmt);
			}
			for (RowCell cell : picost.getCells("drug", "costTypeCode")) {
				costTypeCode = cell.getValue().toStringUtf8();
				// LOGGER.info("costTypeCode" + costTypeCode);
			}
			for (RowCell cell : picost.getCells("drug", "effectiveDate")) {
				effectiveDate = cell.getValue().toStringUtf8();
				// LOGGER.info("effectiveDate :" + effectiveDate);
				// DateTimeFormatter formatter =
				// DateTimeFormatter.ofPattern("yyyy/MM/dd");
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				LocalDate effctvDate = LocalDate.parse(effectiveDate, formatter);
				dateList.add(effctvDate);
				// System.out.println("Checking the date format :" +
				// effctvDate);
			}

			final String CostAmtFinal = costAmt;
			final String costTypeCodeFinal = costTypeCode;
			final String effectiveDateFinal = effectiveDate;

			amberBO.stream().forEach(obj -> {
				if (obj.getMdsFamId().equals(mdsFamId)) {
					obj.setCostAmt(CostAmtFinal);
					obj.setCostTypeCode(costTypeCodeFinal);
					obj.setEffectiveDate(effectiveDateFinal);

				}
			});

		}
		LOGGER.info("Volume of pharmacy_item_cost : " + rowCount);

		LocalDate maxdate = dateList.stream().max(Comparator.comparing(LocalDate::toEpochDay)).get();

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String maxEffectiveDate = formatter.format(maxdate);
		System.out.println("Checking the maxEffectiveDate :" + maxEffectiveDate);

		List<AmberVialInventoryBO> filteredamberBO = amberBO.stream()
				.filter(obj -> obj.getCostTypeCode() != null && obj.getEffectiveDate() != null
						&& obj.getCostTypeCode().equals("3001") && obj.getEffectiveDate().equals(maxEffectiveDate))
				.collect(Collectors.toList());

		System.out.println("Size of filteredamberBO :" + filteredamberBO.size());

		amberBO = new ArrayList<>();
		amberBO.addAll(filteredamberBO);

		long picostJavaEnd = System.currentTimeMillis();
		LOGGER.info(("End time for Java Processing of pharmacy_item_cost:" + new Timestamp(picostJavaEnd)));
		LOGGER.info(("Difference in millis = " + (picostJavaEnd - picostJavaStart)));
	}

	// @PostConstruct
	public void getHeaderDetails(Integer storeId, String from, String to) {

		Integer storeNumber = storeId;
		String appName = "Connexus Pharmacy System";
		String store = "Sam's Pharmacy10-" + storeNumber;
		String reportName = "AMBER VIAL INVENTORY";

		List<AmberVialInventoryStoreDetailsBO> storeDetails = new ArrayList<>();
		List<HeaderBO> header = new ArrayList<>();

		storeDetails.add(new AmberVialInventoryStoreDetailsBO(storeNumber, appName, store, reportName));

		header.add(new HeaderBO("Vial ID", "vialId"));
		header.add(new HeaderBO("NDC", "ndc"));
		header.add(new HeaderBO("Drug Description", "drugDescription"));
		header.add(new HeaderBO("Original Quantity", "originalQuantity"));
		header.add(new HeaderBO("Original Cost", "originalCost"));
		header.add(new HeaderBO("Current Quantity", "currentQuantity"));
		header.add(new HeaderBO("Create Date", "createDate"));
		header.add(new HeaderBO("Expiration Date", "expirationDate"));
		header.add(new HeaderBO("User ID", "userId"));
		header.add(new HeaderBO("Time Stamp", "timeStamp"));
		header.add(new HeaderBO("Status", "status"));

		amberVialInventoryActivityBO.setStoreDetails(storeDetails);
		amberVialInventoryActivityBO.setHeader(header);
		
	}
}
