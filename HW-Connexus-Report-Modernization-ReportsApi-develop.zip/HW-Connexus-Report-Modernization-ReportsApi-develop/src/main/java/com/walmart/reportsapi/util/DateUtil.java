package com.walmart.reportsapi.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DateUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(DateUtil.class);

	public static Date getDate(String date) {
		Date d = null;
		try {
			d = new SimpleDateFormat("dd/mm/yyyy HH:MM:SS").parse(date);
		} catch (ParseException e) {

			LOGGER.error("[DateUtil][getDate] Exception occurred while parsing the date :" + e.getMessage(), e);
		}
		return d;
	}

	public static String getDateForTimeinMillis(String timeInMillis) {
		if (null == timeInMillis || "".equals(timeInMillis)) {
			return null;
		}

		String d = null;
		try {
			Date date = new Date(Long.parseLong(timeInMillis));
			d = new SimpleDateFormat("YYYY-MM-dd").format(date);
		} catch (Exception e) {

			LOGGER.error("[DateUtil][getDate] Exception occurred while parsing the date :" + e.getMessage(), e);
		}
		return d;
	}
	
	public static String formatFromDate(String fromDate){
		SimpleDateFormat targetFormat = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat originalFormat = new SimpleDateFormat("MM/dd/yyyy");

		String from=null;
		try {
			from = targetFormat.format(originalFormat.parse(fromDate.split(" ")[0])) + " 00:00:00";
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return from;
	}
	
	public static String formatToDate(String toDate){
		SimpleDateFormat targetFormat = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat originalFormat = new SimpleDateFormat("MM/dd/yyyy");

		String to=null;
		try {
			to = targetFormat.format(originalFormat.parse(toDate.split(" ")[0])) + " 23:59:59";
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return to;
	}
	
	public static String formatDate(String date){
		SimpleDateFormat targetFormat = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat originalFormat = new SimpleDateFormat("MM/dd/yyyy");

		String formatDate=null;
		try {
			formatDate = targetFormat.format(originalFormat.parse(date.split(" ")[0]));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return formatDate;
	}

}
