package com.walmart.reportsapi.exception;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class ExceptionHandleAdvisor extends ResponseEntityExceptionHandler {
	
	@ExceptionHandler(ReportApiServiceException.class)
	public ResponseEntity<Object> handleReportAPIServiceException(ReportApiServiceException e, WebRequest webRequest){
		
		Map<String, Object> responseMap=new LinkedHashMap<>();
		responseMap.put("Error", e.getMessage());
		return new ResponseEntity<>(responseMap, HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
