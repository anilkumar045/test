package com.walmart.reportsapi.bo.audit;

import java.util.List;

public class ControlledSubstanceRxDetailsBO {
	private List<ControlledSubstanceStoreDetailsBO> storeDetails;
	private List<HeaderBO> header;
	private List<ControlledSubstanceRxDetailsDataBO> data;
	
	public ControlledSubstanceRxDetailsBO() {
		super();
		
	}

	public ControlledSubstanceRxDetailsBO(List<ControlledSubstanceStoreDetailsBO> storeDetails, List<HeaderBO> header,
			List<ControlledSubstanceRxDetailsDataBO> data) {
		super();
		this.storeDetails = storeDetails;
		this.header = header;
		this.data = data;
	}

	public List<ControlledSubstanceStoreDetailsBO> getStoreDetails() {
		return storeDetails;
	}

	public void setStoreDetails(List<ControlledSubstanceStoreDetailsBO> storeDetails) {
		this.storeDetails = storeDetails;
	}

	public List<HeaderBO> getHeader() {
		return header;
	}

	public void setHeader(List<HeaderBO> header) {
		this.header = header;
	}

	public List<ControlledSubstanceRxDetailsDataBO> getData() {
		return data;
	}

	public void setData(List<ControlledSubstanceRxDetailsDataBO> data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "ControlledSubstanceRxDetailsBO [storeDetails=" + storeDetails + ", header=" + header + ", data=" + data
				+ "]";
	}
	
}
