package com.walmart.reportsapi.bo.pharmacistreports;

import java.util.List;

public class FourPointCheckPharmacistBO {

	private String pharmacistName;

	private List<FourPointCheckDataBO> data;

	public FourPointCheckPharmacistBO(String pharmacistName, List<FourPointCheckDataBO> data) {
		super();
		this.pharmacistName = pharmacistName;
		this.data = data;
	}

	public String getPharmacistName() {
		return pharmacistName;
	}

	public void setPharmacistName(String pharmacistName) {
		this.pharmacistName = pharmacistName;
	}

	public List<FourPointCheckDataBO> getData() {
		return data;
	}

	public void setData(List<FourPointCheckDataBO> data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "FourPtCheckPharmacistBO [pharmacistName=" + pharmacistName + ", data=" + data + ", getPharmacistName()="
				+ getPharmacistName() + ", getData()=" + getData() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}

}
