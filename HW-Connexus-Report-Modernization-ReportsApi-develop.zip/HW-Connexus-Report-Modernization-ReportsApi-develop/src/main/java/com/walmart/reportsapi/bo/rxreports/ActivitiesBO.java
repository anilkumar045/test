package com.walmart.reportsapi.bo.rxreports;

public class ActivitiesBO {

	private String rxId;
	
	private String type;
	private String userId;
	private String timeStamp;
	public String getRxId() {
		return rxId;
	}
	public void setRxId(String rxId) {
		this.rxId = rxId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	@Override
	public String toString() {
		return "ActivitiesBO [rxId=" + rxId + ", type=" + type + ", userId=" + userId + ", timeStamp=" + timeStamp
				+ "]";
	}
	
}
