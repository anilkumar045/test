package com.walmart.reportsapi.repository;

import com.walmart.reportsapi.bo.audit.ControlledSubstanceRxDetailsBO;

public interface AuditDao {

	ControlledSubstanceRxDetailsBO getControlledSubstanceRxDetailsRepository(String storeId, String fromDate,
			String toDate) throws Exception;

}
