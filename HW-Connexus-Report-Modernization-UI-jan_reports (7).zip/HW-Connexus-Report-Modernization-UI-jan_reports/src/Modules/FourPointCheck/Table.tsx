import React, { ReactElement } from 'react';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import {StyledTableBody, StyledTable, StyledTableHead, StyledTableHeaderRow, StyledTableHeaderCell, StyledTableBodyCell} from '../Common/Table.styled.js'

type props = {
  data: {
    [field:string]:any;
  }[] | null;
  header: { [label: string]: string }[];
};

const CustomTable: React.FC<props> = ({
  data: patientData,
  header: rows,
}): ReactElement => {
  return !patientData ? (
    <h3> NO DATA FOUND </h3>
  ) : (
    <StyledTable
      aria-labelledby="tableTitle"
      id="reportTable"
    >
      <StyledTableHead>
        <StyledTableHeaderRow>
          {rows.map((row) => (
            <StyledTableHeaderCell key={row.id}>
              {row.label}
            </StyledTableHeaderCell>
          ))}
        </StyledTableHeaderRow>
      </StyledTableHead>
      <StyledTableBody id="reportTableBody" >
        {patientData ? (
          patientData.map((n) => (
            <TableRow
              id={`reportTableRow${n.userId}`}
              hover
              tabIndex={-1}
              key={`reportTableRow${n.userId}`}
            >
              {rows.map((row) => (
                <StyledTableBodyCell
                  key={`reportTableRow${n[row.id]}`}
                  style={{
                    width: '12.5%',
                  }}
                >
                  {n[row.id]}
                </StyledTableBodyCell>
              ))}
            </TableRow>
          ))
        ) : (
          <TableRow hover tabIndex={-1}>
            <>
              <TableCell colSpan={12}>No Records Found</TableCell>
            </>
          </TableRow>
        )}
      </StyledTableBody>
    </StyledTable>
  );
};

CustomTable.defaultProps = {
  data: [],
  header: [],
};

// CustomTable.propTypes = {
//   data: PropTypes.arrayOf(PropTypes.object),
//   header: PropTypes.arrayOf(PropTypes.object),
// };

export default CustomTable;