import React, { useState, useEffect } from 'react';
import { Grid } from '@material-ui/core';
import moment from 'moment';
import Table from './Table';
import PrintWrapper from '../Common/PrintReport';
import { API_URL, getConfig, getReportDetails } from '../../settings';
import { getApi } from '../Common/AxiosCall';
import {
  ReportContainer,
  ParaContainer,
  UnderlinedParaContainer,
  HeaderContainer,
} from '../../assets/common.styled';
import { RouteComponentProps } from 'react-router';
/**s
 * FourPointCheck Component
 */

type props = {
  location: { search: string; pathname: string };
};
type date = {
  date: string;
  pharmacists: {
    pharmacistName: string;
    data: { [field: string]: number | string }[];
  }[];
};
type dataProps = {
  appName: string;
  store: string;
  reportName: string;
  details: string;
  dates: date[];
  header: { [field: string]: string }[];
  note: string;
} | null;

export const FourPointCheck: React.FC<RouteComponentProps> = (
  props,
) => {
  const [data, updateData] = useState<dataProps>(null);
  const [loading, updateLoading] = useState<boolean>(true);
  const [error, updateError] = useState<null | string>(null);
  const { location } = props;
  const { search, pathname = '' } = location;
  const params = new URLSearchParams(search);
  const fromDate = params.get('fromDate');
  const toDate = params.get('toDate');
  const key = pathname.substr(1);
  const apiHeader = {};
  const URL = API_URL + getConfig(key);
  const storeId = params.get('storeId');
  useEffect(() => {
    getApi(
      URL,
      { fromDate, toDate },
      apiHeader,
      (res) => {
        updateData(res.data);
        updateLoading(false);
        updateError(null);
      },
      (err) => {
        updateData(null);
        updateLoading(false);
        updateError(err);
      },
    );
  }, []);

  if (loading) {
    return <div>Loading ....</div>;
  }
  if (error) {
    return <div>{`Error :${error}`}</div>;
  }
  if (data) {
    const currentReport: string = getReportDetails(key).reportName;
    const {
      appName,
      store,
      reportName,
      details,
      dates,
      header,
      note,
    } = data;

    return (
      <ReportContainer>
        <Grid container spacing={4}>
          <Grid item xs={4}>
            <ParaContainer>{`Store # : ${storeId}`}</ParaContainer>
            <ParaContainer>
              {`Report Date : ${moment().format('MM/DD/YYYY')}`}
            </ParaContainer>
          </Grid>
          <Grid item xs={4}>
            <HeaderContainer>{appName}</HeaderContainer>
            <HeaderContainer>{store}</HeaderContainer>
            <HeaderContainer>{reportName}</HeaderContainer>
          </Grid>
          <Grid item xs={4}>
            <ParaContainer>{details}</ParaContainer>
          </Grid>
        </Grid>
        <UnderlinedParaContainer />
        <ParaContainer>
          {` 
        From : ${moment(fromDate, 'MM/DD/YYYY').format('MM/DD/YYYY')} 
        To : ${moment(toDate, 'MM/DD/YYYY').format('MM/DD/YYYY')}`}
        </ParaContainer>
        <UnderlinedParaContainer />
        <div>
          {dates && dates.length === 0 && (
            <p className="empty-table-body">No Records Found</p>
          )}
          {dates &&
            dates.length > 0 &&
            dates.map((datum: date) => {
              let count = 0;
              return (
                <div key={datum.date}>
                  <HeaderContainer>
                    {` 
                  Date: ${datum.date}`}
                  </HeaderContainer>
                  {datum.pharmacists.length === 0 ? (
                    <Table data={datum.pharmacists} header={header} />
                  ) : (
                    datum.pharmacists.map((pharmacists, index) => {
                      count += pharmacists.data.length;
                      return (
                        <div key={pharmacists.pharmacistName}>
                          <HeaderContainer>
                            {`Pharmacist : ${pharmacists.pharmacistName}`}
                          </HeaderContainer>
                          <Table
                            data={pharmacists.data}
                            header={header}
                          />
                          <HeaderContainer>
                            {`Total ${currentReport} done by 
                          ${pharmacists.pharmacistName} 
                          ${pharmacists.data.length}`}
                          </HeaderContainer>
                          {datum.pharmacists.length === index + 1 && (
                            <HeaderContainer>
                              {`Total ${currentReport} on ${datum.date} 
                            ${count}`}
                            </HeaderContainer>
                          )}
                          <UnderlinedParaContainer />
                        </div>
                      );
                    })
                  )}
                </div>
              );
            })}
        </div>
        <h6>{note}</h6>
      </ReportContainer>
    );
  }
  return null;
};

export default PrintWrapper(FourPointCheck);
