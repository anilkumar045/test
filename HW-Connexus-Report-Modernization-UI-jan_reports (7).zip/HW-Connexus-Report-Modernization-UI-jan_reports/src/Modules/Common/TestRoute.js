import PropTypes from 'prop-types';
import React from 'react';
import { Route } from 'react-router-dom';
import LatencyTest from './LatencyTest';

/* TestRoute instantiates new LatencyTest when the route path gets hit */
/* Logs the date/time, and passes the test to be executed in the child component/s to run test and log time taken */
/* Can be a parent of one or more components */
/* Add attribute "e2eTest" to Route to mark for testing and setup test in Component - see 4 Point Check */

const TestRoute = ({ children }) => {
  const renderRoutes = () => {
    const routeElements = Array.isArray(children)
      ? children
      : [children];

    return routeElements.map((route, idx) => {
      const { component: Component, e2eTest, ...rest } = route.props;
      const key = idx;
      return (
        <Route
          key={key}
          {...rest}
          render={(props) => {
            const test = new LatencyTest('E2E Test:');
            if (e2eTest) test.start('URL HIT:');

            test.run = () =>
              e2eTest
                ? test.end('Component Rendered w/ Response Data:')
                : console.log(
                    'Test is setup in Component but not on Route, go to App.js and add "e2eTest" attribute to Route',
                  );

            return <Component {...props} test={test} />;
          }}
        />
      );
    });
  };
  return <>{renderRoutes()}</>;
};

TestRoute.propTypes = {
  children: PropTypes.oneOfType([
    PropTypes.arrayOf(PropTypes.element),
    PropTypes.element,
  ]).isRequired,
};

export default TestRoute;

// Example:
// componentDidMount() {
//   /* "test" destructured from props, passed from TestRoute */
//   const { location, test } = this.props;
//   ...
//
//   getApi(
//    ...
//       this.setState(
//         {
//           data: res.data,
//           loading: false,
//           error: null,
//         },

//         /* Latency Test executed asynchronously upon completion of response data being set to state */
//         test.run,
//       );

//     ...
//   );
//  }
