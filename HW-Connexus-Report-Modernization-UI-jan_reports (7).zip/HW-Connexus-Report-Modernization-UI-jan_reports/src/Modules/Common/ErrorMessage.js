import React from 'react';

const ErrorMessage = (props) => {
  const { error } = props;
  return <div>{`Error :${error}`}</div>;
}

export default ErrorMessage;
