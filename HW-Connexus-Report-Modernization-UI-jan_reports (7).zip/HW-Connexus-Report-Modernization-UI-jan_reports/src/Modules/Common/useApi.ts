/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Edward Robinson(vn50zua) / Chinmoy Pradhan(vn50w1s)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This function (React Custom Hook) is responsible for making an api request
 * and passing the response and error values to the invoking component as a state object.
 * The request details are passed as into the function as params (url, queryParams, header).
 *
 */

import React from 'react';
import { getApi } from './AxiosCall';

export const apiStates = {
  LOADING: 'LOADING',
  SUCCESS: 'SUCCESS',
  ERROR: 'ERROR',
};

interface Data {
  state: string;
  error: string;
  data: any;
}

/**
 *
 * @description React Custom Hook makes api call and manages state
 * @param url URL
 * @param queryParams Query Params
 * @param header Headers
 * @returns data object containing state, response data and error
 */
export const useApi = (
  url: string,
  queryParams: object,
  header: object,
) => {
  // useState hook returns state and set state method
  const [data, setData] = React.useState<Data>({
    state: apiStates.LOADING,
    error: '',
    data: null,
  });

  // setPartData updates state w/ prev state and new state
  const setPartData = (partialData: object) =>
    setData({ ...data, ...partialData });

  React.useEffect(() => {
    setPartData({
      state: apiStates.LOADING,
    });
    getApi(
      url,
      queryParams,
      header,
      ({ data }) => {
        setPartData({
          state: apiStates.SUCCESS,
          data,
        });
      },
      (error) => {
        setPartData({
          state: apiStates.ERROR,
          error,
        });
      },
    );
  }, []);
  return data;
};
