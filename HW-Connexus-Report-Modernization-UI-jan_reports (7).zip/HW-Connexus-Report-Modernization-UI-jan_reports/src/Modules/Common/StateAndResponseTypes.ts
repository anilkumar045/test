export interface ResponseData<D, H> {
  appDetails: AppDetails;
  tableHeader: H[];
  reportData: D[];
  [key: string]: string | number | D[] | H[] | AppDetails;
}

export interface AppDetails {
  storeId: number;
  appName: string;
  storeName: string;
  storeAddress: string;
  reportName: string;
}

export interface UseApiHookState<T> {
  state: string;
  data: T | null;
  error: Error | string | null;
}
