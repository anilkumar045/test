import styled from 'styled-components';
import Table from '@material-ui/core/Table';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import TableCell from '@material-ui/core/TableCell';
import TableBody from '@material-ui/core/TableBody';

export const StyledTable = styled(Table)`
  margin-top: 3px;
`;

export const StyledTableHead = styled(TableHead)`
  width: 100%;
`;

export const StyledTableHeaderRow = styled(TableRow)`
  background-color: '#fffacd';
  border-top: 1px solid #000;
  border-bottom: 1px solid #000;
`;

export const StyledTableHeaderCell = styled(TableCell)`
  padding: 1px 1px;
  font-size: 11px;
  border-bottom: 0px;
  font-weight: bold;
  color: inherit;
  line-height: '24px';
`;

export const StyledTableBody = styled(TableBody)`
  border-bottom: 1px solid #000;
`;

export const StyledTableBodyCell = styled(TableCell)`
  padding: 4px 6px 4px 6px;
  font-size: 11px;
  border-bottom: 0px;
`;

export const StyledEmptyTableRow = styled(TableRow)`
  text-align: center;
  color: red;
`;

export const StyledEmptyTableCell = styled(TableCell)`
  text-align: center;
  color: red;
`;
