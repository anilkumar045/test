import axios from 'axios';
import LatencyTest from './LatencyTest';

/**
 * @desc get Api function
 * @param {string} URL - Api Url.
 * @param {object} params - Query String for Api.
 * @param {object} header - header for Api.
 * @param {function} success - success callback.
 * @param {function} failure - failure callback.
 * @return {function} invole the call back function based on Promise.
 */

export const getApi = (
  URL,
  queryParams,
  header = {},
  success,
  failure
) => {
  console.log('get api hit before api test');
  const test = new LatencyTest('API Test:');
  const { location = {} } = window;
  const { search } = location;
  const allParams = new URLSearchParams(search);
  const storeId = allParams.get('storeId');
  const params = { ...queryParams, storeId };

  // Latency Test - START
  test.start('Request Sent:');
  axios
    .get(URL, { params, header })
    .then((response) => {
      // Latency Test - END
      test.end('Response Received:');

      if (success) {
        success(response);
      }

    })
    .catch(({ message }) => {
      if (failure) {
        failure(message);
      }

    });
};

/**
 * @desc post Api function
 * @param {string} URL - Api Url.
 * @param {object} params - Payload for Api.
 * @param {object} query - Query String for Api.
 * @param {function} success - success callback.
 * @param {function} failure - failure callback.
 * @return {function} invole the call back function based on Promise.
 */
export const postApi = (
  URL,
  params = {},
  query = {},
  success,
  failure,
) => {
  axios
    .post(URL, params, query)
    .then((response) => {
      if (success) {
        success(response);
      }
    })
    .catch(({ message }) => {
      if (failure) {
        failure(message);
      }
    });
};
