import axios, { AxiosResponse, AxiosError } from 'axios';
import LatencyTest from './LatencyTest';

/**
 * @desc get Api function
 * @param URL - Api Url.
 * @param params - Query String for Api.
 * @param header - header for Api.
 * @param success - success callback.
 * @param failure - failure callback.
 * @return invole the call back function based on Promise.
 */

export const getApi = (
  URL: string,
  queryParams: {},
  header: {},
  success: (response: AxiosResponse) => void,
  failure: (message: string) => void,
) => {
  console.log('get api hit before api test');
  const test = new LatencyTest('API Test:');
  const { location } = window;
  const { search } = location;
  const allParams = new URLSearchParams(search);
  const storeId = allParams.get('storeId');
  const params = { ...queryParams, storeId };
  const headers = header; //should change throughout app
  // Latency Test - START
  test.start('Request Sent:');
  axios
    .get(URL, { params, headers })
    .then((response: AxiosResponse) => {
      // Latency Test - END
      test.end('Response Received:');

      if (success) {
        success(response);
      }
    })
    .catch(({ message }: Error) => {
      if (failure) {
        failure(message);
      }
    });
};

/**
 * @desc post Api function
 * @param {string} URL - Api Url.
 * @param {object} params - Payload for Api.
 * @param {object} query - Query String for Api.
 * @param {function} success - success callback.
 * @param {function} failure - failure callback.
 * @return {function} invole the call back function based on Promise.
 */
export const postApi = (
  URL: string,
  params: {},
  query: {},
  success: (response: AxiosResponse) => void,
  failure: (message: string) => void,
): void => {
  axios
    .post(URL, params, query)
    .then((response: AxiosResponse) => {
      if (success) {
        success(response);
      }
    })
    .catch(({ message }: Error) => {
      if (failure) {
        failure(message);
      }
    });
};
