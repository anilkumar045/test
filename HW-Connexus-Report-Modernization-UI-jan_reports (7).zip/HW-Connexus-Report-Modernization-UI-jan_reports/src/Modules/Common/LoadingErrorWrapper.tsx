import React from 'react';

interface Props {
  loading: boolean;
  error: string | null;
  children: React.ReactElement;
}

const ReportWrapper: React.FC<Props> = ({
  loading,
  error,
  children,
}: Props) => {
  if (loading) {
    return <div>Loading ....</div>;
  } else if (error) {
    return <div>{`Error :${error}`}</div>;
  }
  return children;
};

export default ReportWrapper;
