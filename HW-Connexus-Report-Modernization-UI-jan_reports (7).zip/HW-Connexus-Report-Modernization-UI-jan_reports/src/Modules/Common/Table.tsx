/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Edward Robinson(vn50zua)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for returning the
 * Common Table w/ data to be rendered by any Report leveraging this component via import.
 *
 */

import React, { FC } from 'react';
import TableRow from '@material-ui/core/TableRow';
import {
  StyledTable,
  StyledTableHead,
  StyledTableHeaderRow,
  StyledTableHeaderCell,
  StyledTableBody,
  StyledTableBodyCell,
  StyledEmptyTableRow,
  StyledEmptyTableCell,
} from './Table.styled';

interface GenericHeader {
  [key: string]: string;
}

interface GenericData {
  [key: string]: string | boolean | number;
}

interface GenericTableProps {
  data: GenericData[];
  header: GenericHeader[];
  footer?: JSX.Element;
}

const Table: FC<GenericTableProps> = <
  D extends GenericData,
  H extends GenericHeader,
  F
>({
  data: patientData,
  header: rows,
  footer,
}: {
  data: D[];
  header: H[];
  footer?: F;
}) => (
  <StyledTable aria-labelledby="tableTitle" id="reportTable">
    <StyledTableHead>
      <StyledTableHeaderRow>
        {rows.map((row) => (
          <StyledTableHeaderCell key={row.id}>
            {row.label}
          </StyledTableHeaderCell>
        ))}
      </StyledTableHeaderRow>
    </StyledTableHead>
    <StyledTableBody id="reportTableBody">
      {patientData.length ? (
        patientData.map((n, index) => (
          <TableRow
            id={`reportTableRow${index}`}
            hover
            tabIndex={-1}
            key={`${n.unique}`}
          >
            {rows.map((row) => (
              <StyledTableBodyCell
                key={`${n.unique} - ${n[row.id || '']}`}
              >
                {n[row.id || '']}
              </StyledTableBodyCell>
            ))}
          </TableRow>
        ))
      ) : (
        <StyledEmptyTableRow hover tabIndex={-1}>
          <>
            <StyledEmptyTableCell colSpan={12}>
              No Records Found
            </StyledEmptyTableCell>
          </>
        </StyledEmptyTableRow>
      )}
    </StyledTableBody>
    {footer}
  </StyledTable>
);

export default Table;
