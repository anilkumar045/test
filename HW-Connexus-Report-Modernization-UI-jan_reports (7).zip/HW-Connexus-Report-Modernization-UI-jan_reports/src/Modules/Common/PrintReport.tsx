import React, { FC } from 'react';
import ReactToPrint from 'react-to-print';
import { Button, ButtonGroup } from '@material-ui/core';
import { withRouter, RouteComponentProps } from 'react-router-dom';

export default (WrapperComponent: FC<RouteComponentProps>) => (
  props: RouteComponentProps,
) => {
  const Comp = withRouter(WrapperComponent);
  let componentRef: HTMLDivElement | null = null;
  return (
    <div>
      <ReactToPrint
        trigger={() => (
          <div className="button-container">
            <ButtonGroup
              variant="contained"
              color="primary"
              aria-label="contained primary button group"
            >
              <Button style={{ fontSize: '10px' }}>Print</Button>
            </ButtonGroup>
          </div>
        )}
        content={() => componentRef}
      />
      <div
        ref={(el) => {
          componentRef = el;
        }}
      >
        <Comp {...props} />
      </div>
    </div>
  );
};
