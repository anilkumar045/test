/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Reports team, Primary : Chinmoy Pradhan(vn50w1s)
 * Date: 2020/11/13
 * Version: 0.1
 * Description: This Functional Component is responsible for rendering Fourpoint Correction Report.
 * This component extracts query parameters via the URL and returns detailed or summary report component.
 */

import React from 'react';
import FourPTRphCorrectionDetail from './FourPTRphCorrectionDetail';
import FourPTRphCorrectionSummary from './FourPTRphCorrectionSummary';
import { RouteComponentProps } from 'react-router';

/**
 * Will call the Bagging summary or bagging detail depend on the parameter.
 * @param {Params} props  Params
 */

const FourPTRphCorrectionMain: React.FC<RouteComponentProps> = (props) => {
  const { location } = props;
  const { search } = location;
  const params = new URLSearchParams(search);
  const isSummaryReport = params.get('isSummaryReport');

  return isSummaryReport === 'True' ? (
    <FourPTRphCorrectionSummary {...props} />
  ) : (
      <FourPTRphCorrectionDetail {...props} />
    );
};

export default FourPTRphCorrectionMain;
