/** ********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Reports team, Primary : Chinmoy Pradhan(vn50w1s)
 * Date: 2020/11/13
 * Version: 0.1
 * Description: This Functional Component is responsible for rendering Fourpoint Correction detailed Report.
 * This component requests data from the API and renders that data in a UI table to be viewed
 * by the user.The initial request is originated in Connexus. The details of the request are
 * received as query parameters via the URL.
 *
 */

import { Grid } from '@material-ui/core';
import React from 'react';
import moment from 'moment';
import PrintWrapper from '../Common/PrintReport';
import { API_URL, getConfig } from '../../settings';
import Table from '../Common/Table';
import { useApi, apiStates } from '../Common/useApi';
import Loader from '../Common/Loader';
import ErrorMessage from '../Common/ErrorMessage';
import {
  ReportContainer,
  ParaContainer,
} from './../../assets/common.styled';
import {
  HeaderContainer,
  UnderlinedContainer,
  UpperlinedContainer,
  BoldContainer,
  ColoredParaContainer,
} from './FourPTRPhCorrections.styled';
import { FourPointDetailedType } from './FourPTRPhCorrections.types';
import { CORRECTION_DETAILS } from './Constant';
import { RouteComponentProps } from 'react-router';

export const FourPTRphCorrectionDetail: React.FC<RouteComponentProps> = ({
  location: { search, pathname },
}) => {
  const params = new URLSearchParams(search);
  const storeId = params.get('storeId');
  const fromDate = params.get('fromDate');
  const toDate = params.get('toDate');
  const key = pathname.substr(1);
  const header = {};
  const URL = API_URL + getConfig(key);

  /**
   * useEffect
   * @desc react hook for making Api call
   */

  const { state, error, data }: FourPointDetailedType = useApi(
    '4PT-Rph-corrections-detailed.json',
    {},
    header,
  );
  /**
   * render
   * @return {ReactElement} markup
   */

  switch (state) {
    case apiStates.ERROR:
      return <ErrorMessage error={error} />;
    case apiStates.SUCCESS:
      if (data) {
        const {
          appDetails: { appName, store, reportName, details },
        } = data;
        return (
          <ReportContainer>
            <Grid container spacing={3} justify="space-between">
              <Grid item xs>
                <ParaContainer>Store # :{storeId}</ParaContainer>
                <ParaContainer>
                  Report Date :{moment().format('MM/DD/YYYY')}
                </ParaContainer>
                <br />
                {toDate != null && fromDate != null ? (
                  <ParaContainer>
                    {` From : ${moment(fromDate, 'MM/DD/YYYY').format(
                      'MM/DD/YYYY',
                    )} 
                    To : ${moment(toDate, 'MM/DD/YYYY').format(
                      'MM/DD/YYYY',
                    )}`}
                  </ParaContainer>
                ) : (
                  <ParaContainer></ParaContainer>
                )}
              </Grid>
              <Grid item xs>
                <HeaderContainer>{appName}</HeaderContainer>
                <HeaderContainer>{store}</HeaderContainer>
                <HeaderContainer>{reportName}</HeaderContainer>
              </Grid>
              <Grid item xs={4}>
                <ParaContainer>{details}</ParaContainer>
              </Grid>
            </Grid>
            <hr />
            <BoldContainer>Pharmacist:</BoldContainer>
            <Grid container spacing={1}>
              <Grid item xs={12}>
                <Table
                  data={data.reportData.correctionRecords}
                  header={data.TableHeader}
                />
              </Grid>
            </Grid>
            <Grid container>
              <Grid item xs={5}>
                <UnderlinedContainer>
                  <h3>CORRECTION INFORMATION FOR RPH</h3>
                </UnderlinedContainer>
              </Grid>
            </Grid>
            <Grid container>
              <Grid item xs={5}>
                <ParaContainer>
                  Total prescription Correction <br />
                  (Max of 1 correction per Rx#)
                </ParaContainer>
              </Grid>
              <Grid item xs={1}>
                <ParaContainer>
                  {
                    data.reportData.correctionInformation
                      .totalPrescriptionCorrections
                  }
                </ParaContainer>
              </Grid>
            </Grid>

            <Grid container>
              <Grid item xs={5}>
                <ParaContainer>Total 4PT Completed</ParaContainer>
              </Grid>
              <Grid item xs={1}>
                <UnderlinedContainer>
                  <ParaContainer>
                    {
                      data.reportData.correctionInformation
                        .total4ptCompleted
                    }
                  </ParaContainer>
                </UnderlinedContainer>
              </Grid>
            </Grid>

            <Grid container>
              <Grid item xs={5}>
                <ParaContainer>
                  Percentage of Correction Entries
                </ParaContainer>
              </Grid>
              <Grid item xs={1}>
                <ColoredParaContainer>
                  {
                    data.reportData.correctionInformation
                      .percentageOfCorrection
                  }
                  %
                </ColoredParaContainer>
              </Grid>
            </Grid>

            <Grid container>
              <Grid item xs={5}>
                <UnderlinedContainer>
                  <h3>4PT CORRECTION DETAILS</h3>
                </UnderlinedContainer>
              </Grid>
              <Grid item xs={1}></Grid>
            </Grid>

            {CORRECTION_DETAILS.map(
              (item: { id: string; value: string }) => (
                <Grid container key={item.id}>
                  <Grid item xs={5}>
                    <ParaContainer>{item.value}</ParaContainer>
                  </Grid>
                  &nbsp;
                  <Grid item xs={1}>
                    <ParaContainer>
                      {data.reportData.correctionDetails[item.id]}
                    </ParaContainer>
                  </Grid>
                </Grid>
              ),
            )}

            <Grid container>
              <Grid item xs={5}>
                <UpperlinedContainer>
                  <p>Total</p>
                </UpperlinedContainer>
              </Grid>
              &nbsp;
              <Grid item xs={2}>
                <UpperlinedContainer>
                  <p>{data.reportData.correctionDetails.total}</p>
                </UpperlinedContainer>
              </Grid>
            </Grid>
          </ReportContainer>
        );
      }
    default:
      return <Loader />;
  }
};
export default PrintWrapper(FourPTRphCorrectionDetail);
