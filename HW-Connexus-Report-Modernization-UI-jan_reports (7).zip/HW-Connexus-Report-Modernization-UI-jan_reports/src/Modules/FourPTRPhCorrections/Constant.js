export const CORRECTION_DETAILS = [
  { id: 'patientName', value: 'Patient Name' },
  { id: 'patientDOB', value: 'Patient Date Of Birth' },
  { id: 'writtenDate', value: 'Written Date' },
  { id: 'prescribedProduct', value: 'Prescribed Product' },
  { id: 'prescribedQty', value: 'Prescribed Qty' },
  { id: 'dispensedQty', value: 'dispensedQty' },
  { id: 'refil', value: 'refil' },
  { id: 'daysSupply', value: 'daysSupply' },
  { id: 'strength', value: 'strength' },
  { id: 'sig', value: 'sig' },
  { id: 'DAW', value: 'DAW' },
  { id: 'prescriberName', value: 'prescriberName' },
  { id: 'prescriberDEA', value: 'prescriberDEA' },
];

export const SUMMARY_DETAILS = [
  {
    label: "Pharmacist's Name",
    id: 'pharmacistName',
  },
  {
    label: 'User Id',
    id: 'userId',
  },
  {
    label: 'Store Number',
    id: 'storeNumber',
  },
  {
    label:
      'Number Of 4PT Corrections (Maximum of one RX per User One Rx may have been corrected by multiple users)',
    id: 'numberOfCorrection',
  },
];

export const INPUT_USER_CORRECTED_RX = [
  {
    label: "Associate's Name",
    id: 'associateName',
  },
  {
    label: 'User Id',
    id: 'userId',
  },
  {
    label: 'Store Number',
    id: 'storeNumber',
  },
  {
    label: 'Total Identified Entries',
    id: 'totalIdentifiedEntries',
  },
];

export const TOTAL_BREAK_DOWN = [
  {
    label: "Pharmacist's Name",
    id: 'pharmacistName',
  },
  {
    label: 'User Id',
    id: 'userId',
  },
  {
    label: 'Store Number',
    id: 'storeNumber',
  },
  {
    label:
      'Total 4PT completed (One Rx may have gone through 4PT more than once)  ',
    id: 'total4ptCompleted',
  },
];
