import styled from 'styled-components';
import Table from '@material-ui/core/Table';
import TableRow from '@material-ui/core/TableRow';
import TableCell from '@material-ui/core/TableCell';
import TableBody from '@material-ui/core/TableBody';
import TableHead from '@material-ui/core/TableHead';

type props = {
  width: string;
};

export const StyledTable = styled(Table) `
  margin-top: 3px;
`;

export const StyledTableHead = styled(TableHead) `
  width: 100%;
`;

export const StyledTableFooterRow = styled(TableRow) `
  border-bottom: 0px;
`;

export const StyledFooterTableCellLined = styled(TableCell) `
  padding: 0px;
  font-size: 11px;
  border-top: 1px solid black;
  border-bottom: 0px;
`;
export const StyledFooterTableCell = styled(TableCell) `
  padding: 0px;
  font-size: 11px;
  border-bottom: 0px;
`;

export const StyledTableHeaderRow = styled(TableRow) `
  background-color: '#fffacd';
`;

export const StyledEmptyTableRow = styled(TableRow) `
  text-align: center;
  color: red;
`;

export const StyledEmptyTableCell = styled(TableCell) `
  text-align: center;
  color: red;
`;

export const StyledTableHeaderCell = styled(TableCell) `
  padding: 1px 1px;
  font-size: 11px;
  border-bottom: 0px;
  font-weight: bold;
  color: inherit;
  line-height: '24px';
`;

export const StyledTableBodyCell = styled(TableCell) `
  padding: 1px 1px 1px 1px;
  font-size: 11px;
  border-bottom: 0px;
`;

export const StyledTableBody = styled(TableBody) `
  margin-top: 3px;
`;

export const ReportContainer = styled.div`
  background-color: #fffacd;
  padding: 15px;
  font-size: 11px;
`;

export const ColoredParaContainer = styled.div`
  margin: 0px;
  background-color:yellow;
  border: 1px solid black;
`;

export const HeaderContainer = styled.h5`
  margin: 0px;
`;

export const SectionHeaderContainer = styled.div`
  border-top: 1px solid black;
  border-bottom: 1px solid black;
  margin-top: 30px;
  margin-bottom: 10px;
  h2 {
    margin: 5px;
  }
`;

export const UnderlinedContainer = styled.div`
  border-bottom: 1px solid black;
`;

export const UpperlinedContainer = styled.div`
  border-top: 1px solid black;
`;

export const ColumnContainer = styled.col`
  width: ${(props: props) => props.width || ''};
`;

export const BoldContainer = styled.div`
  font-weight: bold;
`;