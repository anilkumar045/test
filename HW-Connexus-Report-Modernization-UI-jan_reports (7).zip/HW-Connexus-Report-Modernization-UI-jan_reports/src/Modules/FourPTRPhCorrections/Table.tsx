/** ********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Reports team, Primary : Chinmoy Pradhan(vn50w1s)
 * Date: 2020/11/13
 * Version: 0.1
 * Description: This Functional Component is responsible for rendering Fourpoint Correction tables.
 * This component recieves data from the props and renders that data in a UI table to be viewed
 * by the user.The initial request is originated in Connexus. The details of the request are
 * received as query parameters via the URL.
 *
 */

import React, { ReactElement, Fragment, FC } from 'react';
import TableRow from '@material-ui/core/TableRow';
import {
  StyledTable,
  StyledTableHeaderRow,
  StyledTableHeaderCell,
  StyledTableBodyCell,
  StyledEmptyTableRow,
  StyledEmptyTableCell,
  StyledTableBody,
  ColumnContainer,
  StyledTableHead,
} from './FourPTRPhCorrections.styled';

type props = {
  data:
    | {
        [field: string]: any;
      }[]
    | null;
  header: { [label: string]: string }[];
  footer: ReactElement;
};

type patientDataType = {
  [field: string]: any;
};
type rowsType = {
  [label: string]: string;
};

interface IHeaderObject {
  id: string;
  label: string;
  [field: string]: string;
}
interface ICorrectionDetails {
  patientName: number;
  patientDOB: number;
  writtenDate: number;
  prescribedProduct: number;
  prescribedQty: number;
  dispensedQty: number;
  refil: number;
  daysSupply: number;
  strength: number;
  sig: number;
  DAW: number;
  prescriberName: number;
  prescriberDEA: number;
  total: number;
}
interface ITotalBreakdownType {
  pharmacistName: string;
  userId: string;
  storeNumber: number;
  total4ptCompleted: number;
}
interface IInputUsersType {
  associateName: string;
  userId: string;
  storeNumber: number;
  totalIdentifiedEntries: number;
}

interface IUserSummaryDetailsType {
  pharmacistName: string;
  userId: string;
  storeNumber: number;
  numberOfCorrection: number;
}
interface ICorrectionInformationType {
  totalPrescriptionCorrections: number;
  total4ptCompleted: number;
  percentageOfCorrection: number;
}

interface IFourPTRphCorrectionSummaryPatientData {
  userSummaryDetails: IUserSummaryDetailsType[];
  inputUsers: IInputUsersType[];
  totalBreakDown: ITotalBreakdownType[];
  correctionInformation: ICorrectionInformationType;
  correctionDetails: ICorrectionDetails[];
}

type records = {
  [field: string]: number | string;
}[];

type dataProps = {
  userSummaryDetails: records[];
  inputUsers: records[];
  totalBreakDown: records[];

  correctionInformation: {
    totalPrescriptionCorrections: number;
    total4ptCompleted: number;
    percentageOfCorrection: number;
  }[];
  correctionDetails: {
    [key: string]: number | string;
    total: number;
  }[];
};

interface FourPTRPhCorrectionTableProps {
  data: dataProps[];
  header: IHeaderObject[];
}

interface GenericObjProps {
  unique?: number;
  id?: string;
  label?: string;
  [key: string]: string | boolean | number | undefined;
}

interface GenericTableProps {
  data: GenericObjProps[];
  header: GenericObjProps[];
  footer?: {} | undefined;
}

const CustomTable: FC<GenericTableProps> = <
  D extends GenericObjProps,
  H extends GenericObjProps,
  F
>({
  data: patientData,
  header: rows,
  footer,
}: {
  data: D[];
  header: H[];
  footer?: F;
}) => {
  return (
    <StyledTable aria-labelledby="tableTitle" id="reportTable">
      <colgroup>
        <ColumnContainer width="35%" />
        <ColumnContainer width="10%" />
        <ColumnContainer width="8%" />
        <ColumnContainer width="30%" />
      </colgroup>
      <StyledTableHead>
        <StyledTableHeaderRow>
          {rows.map((row, index: number) =>
            index == 0 ? (
              <StyledTableHeaderCell key={row.id}>
                {row.label}
              </StyledTableHeaderCell>
            ) : (
              <StyledTableHeaderCell key={row.id}>
                {row.label}
              </StyledTableHeaderCell>
            ),
          )}
        </StyledTableHeaderRow>
      </StyledTableHead>
      <StyledTableBody>
        {patientData && patientData.length ? (
          patientData.map((n: any, index: number) => (
            <TableRow
              id={`reportTableRow${index}`}
              hover
              tabIndex={-1}
              key={n.unique}
            >
              {rows.map((row: any) => (
                <StyledTableBodyCell key={n.unique + n[row.id]}>
                  {n[row.id]}
                </StyledTableBodyCell>
              ))}
            </TableRow>
          ))
        ) : (
          <StyledEmptyTableRow hover tabIndex={-1}>
            <Fragment>
              <StyledEmptyTableCell colSpan={12}>
                No Records Found
              </StyledEmptyTableCell>
            </Fragment>
          </StyledEmptyTableRow>
        )}
      </StyledTableBody>
      {footer}
    </StyledTable>
  );
};

CustomTable.defaultProps = {
  data: [],
  header: [],
};

export default CustomTable;
