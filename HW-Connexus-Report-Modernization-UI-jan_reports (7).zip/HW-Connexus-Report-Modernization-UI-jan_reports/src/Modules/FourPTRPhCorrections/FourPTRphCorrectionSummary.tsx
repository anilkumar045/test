/** ********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Reports team, Primary : Chinmoy Pradhan(vn50w1s)
 * Date: 2020/11/13
 * Version: 0.1
 * Description: This Functional Component is responsible for rendering Fourpoint Correction Summary Report.
 * This component requests data from the API and renders that data in a UI table to be viewed
 * by the user.The initial request is originated in Connexus. The details of the request are
 * received as query parameters via the URL.
 *
 */
import { Grid } from '@material-ui/core';
import React from 'react';
import moment from 'moment';
import PrintWrapper from '../Common/PrintReport';
import { API_URL, getConfig } from '../../settings';
import Table from './Table';
import { useApi, apiStates } from '../Common/useApi';
import Loader from '../Common/Loader';
import ErrorMessage from '../Common/ErrorMessage';
import { RouteComponentProps } from 'react-router';
import {
  ReportContainer,
  ParaContainer,
} from './../../assets/common.styled';
import {
  HeaderContainer,
  SectionHeaderContainer,
  UnderlinedContainer,
  UpperlinedContainer,
  StyledTableFooterRow,
  StyledFooterTableCell,
  StyledFooterTableCellLined,
  ColoredParaContainer,
} from './FourPTRPhCorrections.styled';
import { FourPointSummaryType } from './FourPTRPhCorrections.types';
import {
  CORRECTION_DETAILS,
  SUMMARY_DETAILS,
  INPUT_USER_CORRECTED_RX,
  TOTAL_BREAK_DOWN,
} from './Constant';


const calculateSum = (
  arr: {
    [field: string]: number | string;
  }[],
  key: string,
) => {
  let sum = 0;
  for (let x of arr) {
    const current = x[key];
    if (typeof current === 'number') sum = sum + current;
  }
  return sum;
};

export const FourPTRPhCorrectionSummary: React.FC<RouteComponentProps> = (
  props,
) => {
  const { location } = props;
  const { search, pathname } = location;
  const params = new URLSearchParams(search);
  const storeId = params.get('storeId');
  const fromDate = params.get('fromDate');
  const toDate = params.get('toDate');
  const key = pathname.substr(1);
  const header = {};
  const URL = API_URL + getConfig(key);
  /**
   * useApi
   * @desc react hook for making Api call
   */

  const { state, error, data }: FourPointSummaryType = useApi(
    '4PT-Rph-corrections-summary.json',
    {},
    header,
  );

  /**
   * render
   * @return {ReactElement} markup
   */
  switch (state) {
    case apiStates.ERROR:
      return <ErrorMessage error={error} />;
    case apiStates.SUCCESS:
      if (data) {
        const footerComponent = (
          <StyledTableFooterRow>
            <StyledFooterTableCellLined>
              Total
            </StyledFooterTableCellLined>
            <StyledFooterTableCell></StyledFooterTableCell>
            <StyledFooterTableCell></StyledFooterTableCell>
            {data && (
              <StyledFooterTableCellLined>
                {calculateSum(
                  data.reportData.userSummaryDetails,
                  'numberOfCorrection',
                )}
              </StyledFooterTableCellLined>
            )}
          </StyledTableFooterRow>
        );
        const footerComponentCorrectedRx = (
          <StyledTableFooterRow>
            <StyledFooterTableCellLined>
              Total
            </StyledFooterTableCellLined>
            <StyledFooterTableCell></StyledFooterTableCell>
            <StyledFooterTableCell></StyledFooterTableCell>
            {data && (
              <StyledFooterTableCellLined>
                {calculateSum(
                  data.reportData.inputUsers,
                  'totalIdentifiedEntries',
                )}
              </StyledFooterTableCellLined>
            )}
          </StyledTableFooterRow>
        );

        const footerComponentTotalBreakDown = (
          <StyledTableFooterRow>
            <StyledFooterTableCellLined>
              Total
            </StyledFooterTableCellLined>
            <StyledFooterTableCell></StyledFooterTableCell>
            <StyledFooterTableCell></StyledFooterTableCell>
            {data && (
              <StyledFooterTableCellLined>
                {calculateSum(
                  data.reportData.totalBreakDown,
                  'total4ptCompleted',
                )}
              </StyledFooterTableCellLined>
            )}
          </StyledTableFooterRow>
        );
        if (data) {
          // const currentReport: string =  getReportDetails(key).reportName;
          const {
            appDetails: { appName, store, reportName, details },
          } = data;
          return (
            <ReportContainer>
              <Grid container spacing={3} justify="space-between">
                <Grid item xs>
                  <ParaContainer>Store # :{storeId}</ParaContainer>
                  <ParaContainer>
                    Report Date :{moment().format('MM/DD/YYYY')}
                  </ParaContainer>
                  <br />
                  {toDate != null && fromDate != null ? (
                    <ParaContainer>
                      {` From : ${moment(
                        fromDate,
                        'MM/DD/YYYY',
                      ).format('MM/DD/YYYY')} 
                        To : ${moment(toDate, 'MM/DD/YYYY').format(
                          'MM/DD/YYYY',
                        )}`}
                    </ParaContainer>
                  ) : (
                    <ParaContainer></ParaContainer>
                  )}
                </Grid>
                <Grid item xs>
                  <HeaderContainer>{appName}</HeaderContainer>
                  <HeaderContainer>{store}</HeaderContainer>
                  <HeaderContainer>{reportName}</HeaderContainer>
                </Grid>
                <Grid item xs={4}>
                  <ParaContainer>{details}</ParaContainer>
                </Grid>
              </Grid>
              <hr />
              <SectionHeaderContainer>
                <h2>Store User Summary Details</h2>
              </SectionHeaderContainer>
              <Grid container spacing={1}>
                <Grid item xs={12}>
                  <Table
                    data={data.reportData.userSummaryDetails}
                    header={SUMMARY_DETAILS}
                    footer={footerComponent}
                  />
                </Grid>
              </Grid>
              <Grid container>
                <Grid item xs={5}>
                  <UnderlinedContainer>
                    <h3>CORRECTION INFORMATION FOR STORE</h3>
                  </UnderlinedContainer>
                </Grid>
                <Grid item xs={1}></Grid>
              </Grid>
              <Grid container>
                <Grid item xs={5}>
                  <ParaContainer>
                    Total prescription Correction <br />
                    (Max of 1 correction per Rx#)
                  </ParaContainer>
                </Grid>
                <Grid item xs={1}>
                  <ParaContainer>
                    {
                      data.reportData.correctionInformation
                        .totalPrescriptionCorrections
                    }
                  </ParaContainer>
                </Grid>
              </Grid>

              <Grid container>
                <Grid item xs={5}>
                  <ParaContainer>Total 4PT Completed</ParaContainer>
                </Grid>
                <Grid item xs={1}>
                  <UnderlinedContainer>
                    <ParaContainer>
                      {
                        data.reportData.correctionInformation
                          .total4ptCompleted
                      }
                    </ParaContainer>
                  </UnderlinedContainer>
                </Grid>
              </Grid>

              <Grid container>
                <Grid item xs={5}>
                  <ParaContainer>
                    Percentage of Correction Entries
                  </ParaContainer>
                </Grid>
                <Grid item xs={1}>
                  <ColoredParaContainer>
                    {
                      data.reportData.correctionInformation
                        .percentageOfCorrection
                    }
                    %
                  </ColoredParaContainer>
                </Grid>
              </Grid>

              <Grid container>
                <Grid item xs={5}>
                  <UnderlinedContainer>
                    <h3>4PT CORRECTION DETAILS</h3>
                  </UnderlinedContainer>
                </Grid>
                <Grid item xs={1}></Grid>
              </Grid>

              {CORRECTION_DETAILS.map((item) => (
                <Grid container key={item.id}>
                  <Grid item xs={5}>
                    <ParaContainer>{item.value}</ParaContainer>
                  </Grid>
                  &nbsp;
                  <Grid item xs={1}>
                    <ParaContainer>
                      {data.reportData.correctionDetails[item.id]}
                    </ParaContainer>
                  </Grid>
                </Grid>
              ))}

              <Grid container>
                <Grid item xs={5}>
                  <UpperlinedContainer>
                    <p>Total</p>
                  </UpperlinedContainer>
                </Grid>
                &nbsp;
                <Grid item xs={2}>
                  <UpperlinedContainer>
                    <p>{data.reportData.correctionDetails.total}</p>
                  </UpperlinedContainer>
                </Grid>
              </Grid>
              <Grid container>
                <Grid item xs={5}>
                  <UnderlinedContainer>
                    <h3>INPUT USER FOR CORRECTED RX</h3>
                  </UnderlinedContainer>
                </Grid>
              </Grid>

              <Grid container spacing={1}>
                <Grid item xs={12}>
                  <Table
                    data={data.reportData.inputUsers}
                    header={INPUT_USER_CORRECTED_RX}
                    footer={footerComponentCorrectedRx}
                  />
                </Grid>
              </Grid>

              <h3>4PT TOTAL BREAK DOWN</h3>
              <Grid container spacing={1}>
                <Grid item xs={12}>
                  <Table
                    data={data.reportData.totalBreakDown}
                    header={TOTAL_BREAK_DOWN}
                    footer={footerComponentTotalBreakDown}
                  />
                </Grid>
              </Grid>
            </ReportContainer>
          );
        }
      }
    default:
      return <Loader />;
  }
};
export default PrintWrapper(FourPTRPhCorrectionSummary);
