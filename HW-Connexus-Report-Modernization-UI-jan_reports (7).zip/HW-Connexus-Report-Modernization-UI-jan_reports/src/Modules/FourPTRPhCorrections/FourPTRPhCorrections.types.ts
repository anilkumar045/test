interface FourPointDetailedDataProps {
  appDetails: {
    appName: string;
    store: string;
    reportName: string;
    details: string;
  };
  TableHeader: { label: string; id: string }[];
  reportData: {
    pharmacist: string;
    correctionRecords: {
      dateTime: string;
      rx: number;
      inputUser: string;
      correction: number;
    }[];
    correctionInformation: {
      totalPrescriptionCorrections: number;
      total4ptCompleted: number;
      percentageOfCorrection: number;
    };
    correctionDetails: {
      [key: string]: number;
      patientName: number;
      patientDOB: number;
      writtenDate: number;
      prescribedProduct: number;
      prescribedQty: number;
      dispensedQty: number;
      refil: number;
      daysSupply: number;
      strength: number;
      sig: number;
      DAW: number;
      prescriberName: number;
      prescriberDEA: number;
      total: number;
    };
  };
  note: string;
}

export interface FourPointDetailedType {
  state: string;
  error: string;
  data: FourPointDetailedDataProps | null;
}

interface FourPointSummaryDataType {
  appDetails: {
    appName: string;
    store: string;
    reportName: string;
    details: string;
  };
  reportData: {
    userSummaryDetails: {
      pharmacistName: string;
      userId: string;
      storeNumber: number;
      numberOfCorrection: number;
    }[];
    inputUsers: {
      associateName: string;
      userId: string;
      storeNumber: number;
      totalIdentifiedEntries: number;
    }[];
    totalBreakDown: {
      pharmacistName: string;
      userId: string;
      storeNumber: number;
      total4ptCompleted: number;
    }[];

    correctionInformation: {
      totalPrescriptionCorrections: number;
      total4ptCompleted: number;
      percentageOfCorrection: number;
    };
    correctionDetails: {
        [key: string]: number;
        patientName: number;
        patientDOB: number;
        writtenDate: number;
        prescribedProduct: number;
        prescribedQty: number;
        dispensedQty: number;
        refil: number;
        daysSupply: number;
        strength: number;
        sig: number;
        DAW: number;
        prescriberName: number;
        prescriberDEA: number;
        total: number;
    };
  };
  note: string;
}

export interface FourPointSummaryType {
  state: string;
  error: string;
  data: FourPointSummaryDataType | null;
}
