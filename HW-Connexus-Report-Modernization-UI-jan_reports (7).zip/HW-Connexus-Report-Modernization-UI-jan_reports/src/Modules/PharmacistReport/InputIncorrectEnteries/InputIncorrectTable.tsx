/** ********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author: ADM Reports Team Primary: 
 * Date: 2021/1/6
 * Version: 0.1
 * Description: A report in the Connexus Report Moderinization project
 */
import React from 'react';
import TableRow from '@material-ui/core/TableRow';
import {
  StyledTable,
  StyledTableHead,
  StyledTableBody,
  StyledTableBodyCell,
  StyledEmptyTableRow,
  StyledEmptyTableCell,
  StyledTableHeaderRow,
  StyledTableHeaderCell,
} from './InputIncorrectEnteries.styled';

type Props = {
  footer?: string | null,
  halfWidth?: boolean | false,
  totalExist?: boolean | false,
  totalValue?: string | null,
  tableHeader?: boolean | true,
  bodyClassName?: string | 'report-table-body',
  data: {
    [field:string]:any;
  }[] | null;
  header: { [label: string]: string }[];
}

const CustomTable:React.FC<Props> = ({
  footer,
  halfWidth,
  totalExist,
  totalValue,
  tableHeader,
  header: rows,
  bodyClassName,
  data: patientData,
}: Props) => (
  <StyledTable
    aria-labelledby="tableTitle"
    id="reportTable"
    style={{ width: halfWidth ? '50%' : '100%' }}
  >
    {tableHeader !== false && (
    <StyledTableHead>
      <StyledTableHeaderRow>
        {rows.map(
          (row) => (
            <StyledTableHeaderCell
              key={row.id}
            >
              {row.label}
            </StyledTableHeaderCell>
          ),
        )}
      </StyledTableHeaderRow>
    </StyledTableHead>
    )}
    <StyledTableBody id="reportTableBody" className={bodyClassName}>
      {patientData && patientData.length
        ? (
          <React.Fragment key="has-records">
            {patientData.map((n, index) => (
              <TableRow
                id={`reportTableRow${index}`}
                hover
                tabIndex={-1}
                key={Math.random()}
              >
                {rows.map(
                  (row) => (
                    <StyledTableBodyCell
                      key={n.unique + n[row.id]}
                    >
                      {n[row.id]}
                    </StyledTableBodyCell>
                  )
                )}
              </TableRow>
            ))}
            {totalValue && totalExist ? (
              <TableRow
                hover
                key={Math.random()}
              >
                {Object.values(patientData[0]).map((row, rowNumber) => (
                  <StyledTableBodyCell
                    key={Math.random()}
                    className={`${rowNumber === 0 || rowNumber === Object.values(patientData[0]).length - 1 ? 'borderExist' : 'noborder'}`}
                  >{rowNumber === 0 ? 'Total'
                      : (
                        rowNumber === Object.values(patientData[0]).length - 1 && totalValue
                      )}
                  </StyledTableBodyCell>
                ))}
              </TableRow>
            ) : ''}
          </React.Fragment>
        ) : (
          <StyledEmptyTableRow
            hover
            tabIndex={-1}
            key={Math.random()}
          >
            <React.Fragment key="no-records">
              <StyledEmptyTableCell colSpan={12}>
                No Records Found
              </StyledEmptyTableCell>
            </React.Fragment>
          </StyledEmptyTableRow>
        )}
    </StyledTableBody>

    {footer}
  </StyledTable>
);

CustomTable.defaultProps = {
  footer: null,
  halfWidth: false,
  totalExist: false,
  totalValue: null,
  tableHeader: true,
  bodyClassName: 'report-table-body2',
};

export default CustomTable;
