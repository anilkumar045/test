import styled from 'styled-components';
import Table from '@material-ui/core/Table';
import TableRow from '@material-ui/core/TableRow';
import TableCell from '@material-ui/core/TableCell';
import TableBody from '@material-ui/core/TableBody';
import TableHead from '@material-ui/core/TableHead';

export const StyledTable = styled(Table)`
margin-top: 3px;
white-space: break-spaces;
`;

export const StyledTableHead = styled(TableHead)`
width:100%;
`;

export const StyledTableHeaderRow = styled(TableRow)`
background-color: '#fffacd';
border: none !important;
`;

export const StyledEmptyTableRow = styled(TableRow)`
text-align:center;
color:red;
`;

export const StyledEmptyTableCell = styled(TableCell)`
text-align:center;
color:red;
border-top: 1px solid #000;
border-bottom: 1px solid #000;
`;

export const StyledTableHeaderCell = styled(TableCell)`
padding: 1px 1px;
font-size: 11px;
border-bottom: 0px;
font-weight: bold;
color:inherit;
line-height: 15px !important;
`;

export const StyledTableBodyCell = styled(TableCell)`
padding: 1px 1px 1px 1px;
font-size: 11px;
border-bottom: 0px;
`;

export const StyledTableBody = styled(TableBody)`
margin-top: 3px;
`;

export const ReportContainer = styled.div`
background-color: #fffacd;
padding: 15px;
font-size: 11px;
`;

export const HeadingOne = styled.h1`
margin: 0px;
`;

export const HeadingFour = styled.h4`
margin: 0px;
text-align:center;
`;

export const ParaContainer = styled.p`
margin: 0px;
`;

export const Divider = styled.p`
border-bottom: 1px solid #000;
width: 100%;
`;

export const HalfDivider = styled.p`
border-bottom: 2px solid #000;
width: 50%;
`;

export const ParaTitle = styled.p`
margin-top: 25px;
margin-bottom: 0px;
font-weight: 700;
`;

export const HalfContent = styled.div`
width: 50% !important;
white-space: break-spaces;
`;

export const ParaHalfContainer= styled.p`
margin: 0px;
padding: 3px 0px !important;
`;