/** ********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author: ADM Reports Team Primary: 
 * Date: 2021/1/6
 * Version: 0.1
 * Description: A report in the Connexus Report Moderinization project
 */
import React from 'react';
import moment from 'moment';
import { Grid } from '@material-ui/core';

import Table from './InputIncorrectTable';
import {
  Divider,
  ParaTitle,
  HeadingOne,
  HalfDivider,
  HeadingFour,
  ParaContainer,
  ReportContainer,
} from './InputIncorrectEnteries.styled';
import Loader from '../../Common/Loader';
import ErrorMessage from '../../Common/ErrorMessage';
import { API_URL, getConfig } from '../../../settings';
import { useApi, apiStates } from '../../Common/useApi';

type props = {
  location: { search: string; pathname: string }
};

type dataProps={
  appName: string,
  store: string,
  reportName: string,
  details: string,
  summaryData: {
    note: string,
    incorectEnteries: {
      title: string,
      header: {[field: string]: string }[],
      data: {[field: string]: string }[],
      total: { value: string }
    },
    incorrectEntryPercent: {
      title: string,
      header: {[field: string]: string }[],
      data: {[field: string]: string }[]
    },
    fourPTCompleted: {
      title: string,
      header: {[field: string]: string }[],
      data: {[field: string]: string }[],
      total: { value: string }
    },
    storeTotals: {
      title: string,
      header: {[field: string]: string }[],
      data: {[field: string]: string }[]
    },
    incorrectEntryDetailes: {
      title: string,
      header: {[field: string]: string }[],
      data: {[field: string]: string }[],
      total: { value: string }
    },
    incorrectEntryIdentifiedBy: {
      title: string,
      header: {[field: string]: string }[],
      data: {[field: string]: string }[],
      total: { value: string }
    },
    percentOfInputCompleted: {
      title: string,
      header: {[field: string]: string }[],
      data: {[field: string]: string }[]
    },
  }
} | null;

type stateType = { state: string; error: string; data: dataProps };

/**
 * InputIncorrectEnteriesSummary Component
 */
export const InputIncorrectEnteriesSummary: React.FC<props> = ({
  location: { search, pathname },
}:props) => {
  const params: any = new URLSearchParams(search);
  const storeId = params.get('storeId');
  const fromDate = params.get('fromDate');
  const toDate = params.get('toDate');
  const key = pathname.substr(1);
  const apiHeader = {};
  const URL = API_URL + getConfig(key);

  /**
   * useApi
   * @desc react hook for making Api call
   */
  const { state, error, data }: stateType = useApi(
    'input-incorrect-enteries-summary.json',
    { fromDate, toDate },
    apiHeader,
  );

   /**
   * render
   * @return {ReactElement} markup
   */
  switch (state) {
    case apiStates.ERROR:
      return <ErrorMessage error={error} />;
    case apiStates.SUCCESS:
      return (
        <>
          {
          data && (
            <ReportContainer>
              <Grid container spacing={0}>
                <Grid item xs={4}>
                  <ParaContainer>{`Store # :${storeId}`}</ParaContainer>
                  <ParaContainer>{`Report Date :${moment().format('MM/DD/YYYY')}`}</ParaContainer>
                  <br />
                  <ParaContainer>{`From : ${fromDate} To : ${toDate}`}</ParaContainer>
                </Grid>
                <Grid item xs={4} className="text-center">
                  <HeadingFour>{data.appName}</HeadingFour>
                  <HeadingFour>{data.store}</HeadingFour>
                  <HeadingFour>{data.reportName}</HeadingFour>
                </Grid>
                <Grid item xs={4}>
                  <ParaContainer>{data.details}</ParaContainer>
                </Grid>
              </Grid>
              <Divider />
              <Grid container spacing={0} />
              <Divider />
              <Grid container spacing={0}>
                <HeadingOne>Store User Summary Details</HeadingOne>
              </Grid>
              <Divider />
              <Table
                data={data.summaryData.incorectEnteries.data}
                header={data.summaryData.incorectEnteries.header}
                totalExist
                totalValue={data.summaryData.incorectEnteries.total.value}
                bodyClassName=""
              />
    
              <Grid container spacing={0}>
                <Grid item xs={12}>
                  <ParaTitle>{data.summaryData.incorrectEntryPercent.title}</ParaTitle>
                </Grid>
              </Grid>
              <HalfDivider />
              <Table
                data={data.summaryData.incorrectEntryPercent.data}
                header={data.summaryData.incorrectEntryPercent.header}
                bodyClassName=""
              />
    
              <Grid container spacing={0}>
                <Grid item xs={12}>
                  <ParaTitle>{`${data.summaryData.fourPTCompleted.title}:`}</ParaTitle>
                </Grid>
              </Grid>
              <HalfDivider />
              <Table
                data={data.summaryData.fourPTCompleted.data}
                header={data.summaryData.fourPTCompleted.header}
                totalValue={data.summaryData.fourPTCompleted.total.value}
                totalExist
                bodyClassName=""
              />
              <br />
              <Divider />
              <Grid container spacing={0}>
                <HeadingOne>Store Totals</HeadingOne>
              </Grid>
              <Divider />
              <br />
    
              <Table
                data={data.summaryData.storeTotals.data}
                header={data.summaryData.storeTotals.header}
                halfWidth
                tableHeader={false}
                bodyClassName=""
              />
    
              <Grid container spacing={0}>
                <Grid item xs={12}>
                  <ParaTitle>
                    {`${data.summaryData.incorrectEntryDetailes.title}:`}
                  </ParaTitle>
                </Grid>
              </Grid>
              <Table
                data={data.summaryData.incorrectEntryDetailes.data}
                header={data.summaryData.incorrectEntryDetailes.header}
                totalValue={data.summaryData.incorrectEntryDetailes.total.value}
                totalExist
                halfWidth
                tableHeader={false}
                bodyClassName=""
              />
    
              <Grid container spacing={0}>
                <Grid item xs={12}>
                  <ParaTitle>{`${data.summaryData.incorrectEntryIdentifiedBy.title}:`}</ParaTitle>
                </Grid>
              </Grid>
              <HalfDivider />
              <Table
                data={data.summaryData.incorrectEntryIdentifiedBy.data}
                header={data.summaryData.incorrectEntryIdentifiedBy.header}
                totalValue={data.summaryData.incorrectEntryIdentifiedBy.total.value}
                totalExist
                bodyClassName=""
              />
    
              <Grid container spacing={0}>
                <Grid item xs={12}>
                  <ParaTitle>{`${data.summaryData.percentOfInputCompleted.title}:`}</ParaTitle>
                </Grid>
              </Grid>
              <HalfDivider />
              <Table
                data={data.summaryData.percentOfInputCompleted.data}
                header={data.summaryData.percentOfInputCompleted.header}
                totalExist
                bodyClassName=""
              />
    
              <br />
              <Divider />
              <Grid container spacing={0} alignItems="center">
                <Grid item className="summaryNote">
                  <ParaContainer>^^Note:</ParaContainer>
                </Grid>
                <Grid item xs>
                  {data.summaryData.note.split('\n').map((note:string) => <p key={Math.random()} className="pharma-header">{note}</p>)}
                </Grid>
              </Grid>
              <Divider />
              <Grid container spacing={0} />
              <Divider />
              <Grid container spacing={0} />
              <Divider />
    
            </ReportContainer>
          )
        }
        </>
      );
    default:
      return <Loader />;
  }

};

export default InputIncorrectEnteriesSummary;
