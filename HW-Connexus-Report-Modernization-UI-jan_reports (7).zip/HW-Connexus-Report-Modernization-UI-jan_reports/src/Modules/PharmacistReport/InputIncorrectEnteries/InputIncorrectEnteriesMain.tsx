/** ********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author: ADM Reports Team Primary:
 * Date: 2021/1/6
 * Version: 0.1
 * Description: Used to differentiate which InputIncorrecEntries screen will be shown to the user.
 */
import React from 'react';
import InputIncorrectEnteriesSummary from './InputIncorrectEnteriesSummary';
import InputIncorrectEnteriesDetailed from './InputIncorrectEnteriesDetailed';
import { RouteComponentProps } from 'react-router';
import PrintWrapper from '../../Common/PrintReport';

type props = {
  location: { search: string; pathname: string };
};

/**
 * Will call the input incorrect enteries summary or  detailed depend on the parameter.
 */
export const InputIncorrectEnteriesMain: React.FC<RouteComponentProps> = (
  props,
) => {
  const { location } = props;
  const { search, pathname } = location;
  const params = new URLSearchParams(search);
  const isSummaryReport = params.get('isSummaryReport');

  return isSummaryReport === 'True' ? (
    <InputIncorrectEnteriesSummary location={location} />
  ) : (
    <InputIncorrectEnteriesDetailed location={location} />
  );
};

export default PrintWrapper(InputIncorrectEnteriesMain);
