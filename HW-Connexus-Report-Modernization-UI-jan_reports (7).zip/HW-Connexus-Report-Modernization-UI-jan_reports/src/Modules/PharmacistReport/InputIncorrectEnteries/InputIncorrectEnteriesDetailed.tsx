/** ********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author: ADM Reports Team Primary: 
 * Date: 2021/1/6
 * Version: 0.1
 * Description: A report in the Connexus Report Moderinization project
 */
import React from 'react';
import moment from 'moment';
import { Grid, TextField } from '@material-ui/core';

import Table from './InputIncorrectTable';
import {
  Divider,
  ParaTitle,
  HalfDivider,
  HalfContent,
  HeadingFour,
  ParaContainer,
  ReportContainer,
  ParaHalfContainer,
} from './InputIncorrectEnteries.styled';
import Loader from '../../Common/Loader';
import ErrorMessage from '../../Common/ErrorMessage';
import { useApi, apiStates } from '../../Common/useApi';
import { API_URL, getConfig } from '../../../settings';

type props = {
  location: { search: string; pathname: string }
};

type dataProps={
  appName: string,
  store: string,
  reportName: string,
  details: string,
  detailedData: {
    user: string,
    jobCode: string,
    note: string,
    incorrectEntry: {
      title: string,
      header: {[field: string]: string }[],
      data: {[field: string]: string }[]
    },
    inputEntryInfo: {
      title: string,
      header: {[field: string]: string }[],
      data: {[field: string]: string }[]
    },
    incorrectEntryDetails: {
      title: string,
      header: {[field: string]: string }[],
      data: {[field: string]: string }[],
      total: { value: string }
    }
  }
} | null;

type stateType = { state: string; error: string; data: dataProps };

/**
 * InputIncorrectEnteriesDetailed Component
 */
export const InputIncorrectEnteriesDetailed: React.FC<props> = ({
  location: { search, pathname },
}: props) => {
  const params: any = new URLSearchParams(search);
  const storeId = params.get('storeId');
  const fromDate = params.get('fromDate');
  const toDate = params.get('toDate');
  const key = pathname.substr(1);
  const apiHeader = {};
  const URL = API_URL + getConfig(key);

  /**
   * useApi
   * @desc react hook for making Api call
   */
  const { state, error, data }: stateType = useApi(
    'input-incorrect-enteries-detailed.json',
    { fromDate, toDate },
    apiHeader,
  );

   /**
   * render
   * @return {ReactElement} markup
   */
  switch (state) {
    case apiStates.ERROR:
      return <ErrorMessage error={error} />;
    case apiStates.SUCCESS:
      return (
        <>
          {
            data && (
              <ReportContainer>
                <Grid container spacing={0}>
                  <Grid item xs={4}>
                    <ParaContainer>{`Store # :${storeId}`}</ParaContainer>
                    <ParaContainer>{`Report Date :${moment().format('MM/DD/YYYY')}`}</ParaContainer>
                    <br />
                    <ParaContainer>{`From : ${fromDate} To : ${toDate}`}</ParaContainer>
                  </Grid>
                  <Grid item xs={4} className="text-center">
                    <HeadingFour>{data.appName}</HeadingFour>
                    <HeadingFour>{data.store}</HeadingFour>
                    <HeadingFour>{data.reportName}</HeadingFour>
                  </Grid>
                  <Grid item xs={4}>
                    <ParaContainer>{data.details}</ParaContainer>
                  </Grid>
                </Grid>
                <Divider />
                <Grid container spacing={0}>
                  <HeadingFour>{`User: ${data.detailedData.user}`}</HeadingFour>
                </Grid>
                <br />
                <Grid container spacing={0}>
                  <HeadingFour>{`Job Code: ${data.detailedData.jobCode}`}</HeadingFour>
                </Grid>
                <Divider />
                <Table
                  data={data.detailedData.incorrectEntry.data}
                  header={data.detailedData.incorrectEntry.header}
                />
    
                <Grid container spacing={0}>
                  <Grid item xs={12}>
                    <ParaTitle>{`${data.detailedData.inputEntryInfo.title}:`}</ParaTitle>
                  </Grid>
                </Grid>
                <HalfDivider />
    
                <HalfContent>
                  <Grid container spacing={0}>
                    <Grid item xs={8}>
                      <ParaHalfContainer>
                        {data.detailedData.inputEntryInfo.data[0].name}
                      </ParaHalfContainer>
                    </Grid>
                    <Grid item xs={4}>
                      <ParaHalfContainer>
                        {data.detailedData.inputEntryInfo.data[0].value}
                      </ParaHalfContainer>
                    </Grid>
                  </Grid>
    
                  <Grid container spacing={0}>
                    <Grid item xs={8}>
                      <ParaHalfContainer>
                        {data.detailedData.inputEntryInfo.data[1].name}
                      </ParaHalfContainer>
                    </Grid>
                    <Grid item xs={4}>
                      <ParaHalfContainer>
                        {data.detailedData.inputEntryInfo.data[1].value}
                      </ParaHalfContainer>
                    </Grid>
                  </Grid>
    
                  <Grid container spacing={0}>
                    <Grid item xs={8}>
                      <ParaHalfContainer>
                        {data.detailedData.inputEntryInfo.data[2].name}
                      </ParaHalfContainer>
                    </Grid>
                    <Grid item xs={4} className="totalTextField">
                      <TextField
                        className="widthInherit"
                        variant="outlined"
                        inputProps={{
                          readOnly: true,
                          className: 'textFieldStyle',
                        }}
                        defaultValue={data.detailedData.inputEntryInfo.data[2].value}
                      />
                    </Grid>
                  </Grid>
                </HalfContent>
                <Grid container spacing={0}>
                  <Grid item xs={12}>
                    <ParaTitle>{`${data.detailedData.incorrectEntryDetails.title}:`}</ParaTitle>
                  </Grid>
                </Grid>
                <HalfDivider />
                <Table
                  data={data.detailedData.incorrectEntryDetails.data}
                  header={data.detailedData.incorrectEntryDetails.header}
                  totalValue={data.detailedData.incorrectEntryDetails.total.value}
                  totalExist
                  halfWidth
                  tableHeader={false}
                  bodyClassName=""
                />
                <br />
                <Divider />
                <Grid container spacing={0} alignItems="center">
                  <Grid item className="inputNote">
                    <ParaContainer>Note:</ParaContainer>
                  </Grid>
                  <Grid item xs>
                    <ParaContainer>{data.detailedData.note}</ParaContainer>
                  </Grid>
                </Grid>
                <Divider />
              </ReportContainer>
            )
          }
        </>
      );
    default:
      return <Loader />;
  }

};

export default InputIncorrectEnteriesDetailed;
