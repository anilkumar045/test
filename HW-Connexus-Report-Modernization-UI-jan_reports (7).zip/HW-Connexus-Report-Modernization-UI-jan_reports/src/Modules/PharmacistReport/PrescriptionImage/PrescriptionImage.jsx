import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Grid } from '@material-ui/core';
import Table from '../../Common/Table';
import PrintReport from '../../Common/PrintReport';
import { API_URL, getConfig } from '../../../settings';
import { getApi } from '../../Common/AxiosCalls';
/**
 * Prescription Image  report
 */
export class PrescriptionImage extends Component {
  /**
   * constructor
   * @param {object}    props
   */
  constructor(props) {
    super(props);
    /**
     * @type {object}
     * @property {list} data Handle a list of data which return from server side
     * @property {boolean} loading shows the content if flag is false which mean done with load
     * @property {string} error Handle error Message
     */
    this.state = {
      data: null,
      loading: true,
      error: null,
    };
  }
  
  /**
   * componentDidMount
   * @desc life cycle method for making Api call
   */
  componentDidMount() {
    const { location } = this.props;
    const { search, pathname = '' } = location;
    const params = new URLSearchParams(search);
    const rxnumber = params.get('rxnumber');
    const imagebytype = params.get('imagebytype');  // prdate or rxnumber
    const imagebydate = params.get('imagebydate');
    const imagebyminrnumber = params.get('imagebyminrnumber');
    const imagebymaxrnumber = params.get('imagebymaxrnumber');
    const key = pathname.substr(1);
    const URL = API_URL + getConfig(key);
    const header = {};
    getApi(
      URL,
      { rxnumber, imagebytype ,imagebydate,imagebyminrnumber,imagebymaxrnumber},
      header,
      (res) => {
        this.setState({
          data: this.testdate,
          loading: false,
          error: null,
        });
      },
      (err) => {
        this.setState({ data: this.testdate, error: null, loading: false });
      },
    );
  }
  /**
   * render
   * @return {ReactElement}  content for this component
   */
  render() {
    const { data, loading, error } = this.state;
    if (loading) {
      return <div>Loading ....</div>;
    }
    if (error) {
      return <div>{`Error :${error}`}</div>;
    }
    return (
      <div className="report-container">
        <Grid container spacing={24}>
          <Grid item xs={4}>
            <p className="para">{`Store # :${data.storeId}`}</p>
            <p className="para">{`Report Date :${data.date}`}</p>
          </Grid>
          <Grid item xs={4}>
            <h5 className="pharma-header">{data.appName}</h5>
            <h5 className="pharma-header">{data.storename}</h5>
            <h5 className="pharma-header">{data.reportName}</h5>
          </Grid>
          <Grid item xs={4}>
          </Grid>
        </Grid>
        <hr style={{backgroundColor:"black",height:"0.1px"}}></hr>
        <Grid container spacing={24}>
          <Grid item xs={2}>
            <p className="para">{`Patient:`}</p>
            <br></br>
            <br></br>
            <br></br>
            <p className="para">{`Date Of Birth:`}</p>
          </Grid>
          <Grid item xs={6}>
            <p className="para">{`${data.patience.name}`}</p>
            <p className="para">{`${data.patience.address.address1}`}</p>
            <p className="para">{`${data.patience.address.citystatezip}`}</p>
            <br></br>
            <p className="para">{`${data.dateofbirth}`}</p>
          </Grid>
          <Grid item xs={4}>
            <p className="para">{`${data.store.name}`}</p>
            <p className="para">{`${data.store.address.address1}`}</p>
            <p className="para">{`${data.store.address.citystatezip}`}</p>
            <br></br>
            <p className="para">{`NABP Number :${data.nabpnumeber}`}</p>
            <p className="para">{`ID :${data.id}`}</p>
          </Grid>
        </Grid>        
        <hr style={{backgroundColor:"black",height:"0.1px"}}></hr>
        <Grid container spacing={24}>
          <Grid item xs={4}>
          </Grid>
          <Grid item xs={4}>
            <h5 className="pharma-header">{data.reportName}</h5>
          </Grid>
          <Grid item xs={4}>
          </Grid>
        </Grid>        
       {        
        data.imagesurl.map((urldata,i) =>(
          <>
          <hr style={{backgroundColor:"black"}}></hr>
          <Grid container spacing={24}>
            <Grid item xs={4}>
            </Grid>
            <Grid item xs={4}> 
              <h6>Rx # : {urldata.rxnumber} Scanned On : {urldata.scannedate} </h6>
            </Grid>
            <Grid item xs={4}>
            </Grid>
          </Grid>               
          <Grid container spacing={24}>
            <Grid item xs={12}>
             <img key={i} src= {(window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port: '')) + urldata.imgurl}  width="100%"  />          
            </Grid>
          </Grid>
          </>
        )) 
        }
        <br></br>        
        <br></br>          
          <Grid container spacing={24}>
          <Grid item xs={2}>
            <p className="para">{`Reported Date:`}</p>
            <br></br>    
            <p className="para">{`Attested To By:`}</p>
          </Grid>
          <Grid item xs={6}>
            <p className="para">{`${data.date}`}</p>
            <br></br>    
            <p className="para">{`${data.attestedtoby}`}</p>
          </Grid>
          <Grid item xs={4}>
            <p className="signature-value" />
            <br></br>          
            <br></br>      
            <p>Registered Pharmacist  </p>
          </Grid>
        </Grid>            
      </div>
    );
  }
}

PrescriptionImage.propTypes = {
  location: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default PrintReport(PrescriptionImage);
