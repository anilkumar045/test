/** ********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author: ADM Reports Team Primary:
 * Date: 2021/1/6
 * Version: 0.1
 * Description: A report in the Connexus Report Moderinization project
 */
import React from 'react';
import { Grid } from '@material-ui/core';
import Table from '../Common/Table';
import Loader from '../Common/Loader';
import ErrorMessage from '../Common/ErrorMessage';
import { useApi, apiStates } from '../Common/useApi';
import PrintWrapper from '../Common/PrintReport';
import { API_URL, getConfig } from '../../settings';
import {
  Divider,
  HeadingFour,
  HeadingFive,
  ParaContainer,
  ReportContainer,
} from './RegulatoryPatientProfileReport.styled';
import { RouteComponentProps } from 'react-router';


declare global {
  interface Window {
    getData: string;
  }
}

type props = {
  location: { search: string; pathname: string };
};
type dataProps = {
  storeNumber: string;
  reportDate: string;
  appName: string;
  store: string;
  patient: string;
  reportName: string;
  birthDate: string;
  header: { [field: string]: string }[];
  data: { [field: string]: string }[];
  note: string;
} | null;

type stateType = { state: string; error: string; data: dataProps };

/**
 * Regulatory Patient Profile Report Component
 */

export const RegulatoryPatientProfileReport: React.FC<RouteComponentProps> = (props) => {
  const { location } = props;
  const { search, pathname = '' } = location;
  const params = new URLSearchParams(search);
  const startFillDate = params.get('startFillDate');
  const endFillDate = params.get('endFillDate');
  const patientId = params.get('patientId');
  const cashPayRestInd = params.get('cashPayRestInd');
  const storeId = params.get('storeId');
  const header = {};
  const key = pathname.substr(1);
  const URL = API_URL + getConfig(key);

  /**
    * useApi
    * @desc react hook for making Api call
    */
  const { state, error, data }: stateType = useApi(
    URL,
    { startFillDate, endFillDate, patientId, cashPayRestInd, storeId, },
    header,
  );

  /**
    * render
    * @return {ReactElement} markup
    */
  switch (state) {
    case apiStates.ERROR:
      return <ErrorMessage error={error} />;
    case apiStates.SUCCESS:
      window.getData = JSON.stringify(data);
      return (
        <React.Fragment>
          {data && (
            <ReportContainer>
              <Grid container spacing={4}>
                <Grid item xs={4}>
                  <ParaContainer>{`Store #: ${data.storeNumber}`}</ParaContainer>
                  <ParaContainer>{`Report Date: ${data.reportDate}`}</ParaContainer>
                </Grid>
                <Grid item xs={4}>
                  <HeadingFour>{data.appName}</HeadingFour>
                  <HeadingFour>{data.store}</HeadingFour>
                  <HeadingFour>{data.reportName}</HeadingFour>
                </Grid>
              </Grid>
              <Divider />
              <Grid container spacing={4}>
                <Grid item>
                  <HeadingFour>Patient:</HeadingFour>
                </Grid>
                <Grid item xs={2}>
                  <ParaContainer>{data.patient}</ParaContainer>
                </Grid>
              </Grid>
              <br />
              <Grid container spacing={3}>
                <Grid item>
                  <HeadingFour>BirthDate:</HeadingFour>
                </Grid>
                <Grid item>
                  <ParaContainer>{data.birthDate}</ParaContainer>
                </Grid>
              </Grid>
              <Divider />
              <ParaContainer>{`Below is a list of your Pharmacy Orders for the date range of : ${startFillDate} To ${endFillDate}`}</ParaContainer>
              <br />
              <Table data={data.data} header={data.header} />
              <br />
              <Grid container spacing={4}>
                <Grid item xs={4}>
                  <ParaContainer>{`Report Date : ${data.reportDate}`}</ParaContainer>
                  <ParaContainer>Attested To By :</ParaContainer>
                </Grid>
              </Grid>
              <Divider />
              <HeadingFive>{data.note}</HeadingFive>
            </ReportContainer>

          )
          }
        </React.Fragment>
      )

    default:
      return <Loader />;
  }
};

export default PrintWrapper(RegulatoryPatientProfileReport);
