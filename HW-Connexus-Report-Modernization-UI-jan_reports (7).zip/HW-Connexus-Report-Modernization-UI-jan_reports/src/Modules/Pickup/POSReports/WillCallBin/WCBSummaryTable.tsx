/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Edward Robinson(vn50zua)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for returning the
 * Will Call Bin Summary Table to be rendered by Will Call Bin Summary Report.
 *
 */

import { TableCell, TableRow } from '@material-ui/core';
import React, { FC } from 'react';
import { HeaderObject, SummaryObject } from './WCBReport.types';
import {
  StyledSummaryTable,
  StyledTable,
  StyledTableHeaderRow,
  StyledSummaryTableHeaderCell,
  StyledTableBody,
  StyledSummaryTableBodyCell,
  StyledTableHead,
} from './WillCallBin.styled';

const SummaryTable: FC<{
  data: SummaryObject[];
  header: HeaderObject[];
  footer: JSX.Element;
}> = ({ data: summaryTableData, header: rows, footer }) => (
  <>
    <StyledSummaryTable aria-labelledby="tableTitle">
      <StyledTableHead>
        <StyledTableHeaderRow>
          {rows.map((row, index) => {
            const width = index === 0 ? '10%' : 'inherit';
            return (
              <StyledSummaryTableHeaderCell
                key={row.id}
                width={width}
              >
                {row.label}
                {row.label === 'Day' && <div>#</div>}
                {row.label === 'Rx' && <div>Count</div>}
              </StyledSummaryTableHeaderCell>
            );
          })}
        </StyledTableHeaderRow>
      </StyledTableHead>
      <StyledTableBody id="reportTableBody">
        {summaryTableData.length ? (
          summaryTableData.map((n, index) => (
            <TableRow
              id={`reportTableRow${index}`}
              hover
              tabIndex={-1}
              key={`${n.id}`}
            >
              {rows.map((row) => (
                <StyledSummaryTableBodyCell
                  key={`${row.id} - ${n.id}`}
                >
                  {n[row.id]}
                </StyledSummaryTableBodyCell>
              ))}
            </TableRow>
          ))
        ) : (
          <TableRow hover tabIndex={-1}>
            <>
              <TableCell colSpan={12}>
                <div role="alert">
                  Please enter correct Data and Search
                </div>
              </TableCell>
            </>
          </TableRow>
        )}
      </StyledTableBody>
    </StyledSummaryTable>
    <StyledTable aria-labelledby="tableTitle" id="reportTable">
      {footer}
    </StyledTable>
  </>
);

export default SummaryTable;
