/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Edward Robinson(vn50zua)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for conditionally rendering both
 * Will Call Bin Detail and Summary Reports. This component requests data from the API and
 * renders that data in a UI table to be viewed by the user. The initial request is
 * originated in Connexus. The details of the request are received as query parameters via the URL.
 *
 */

import moment from 'moment';
import React, { FC } from 'react';
import { API_URL, getConfig } from '../../../../settings';
import { WillCallBinDetailed } from './WillCallBinDetailed';
import { WillCallBinSummary } from './WillCallBinSummary';
import PrintWrapper from '../../../Common/PrintReport';
import {
  WCBInitialState,
  Script,
  SummaryObject,
  WCBResponseData,
  WCBResponseAndError,
} from './WCBReport.types';
import { RouteComponentProps } from 'react-router';
import { apiStates, useApi } from '../../../Common/useApi';
import ReportWrapper from '../../../Common/LoadingErrorWrapper';

/**
 * WillCallBinMain Smart Component
 */
export const WillCallBinMain: FC<RouteComponentProps> = (props) => {
  /**
   * @type Initial State
   * @property data Input Data
   * @property loading Loading Flag
   * @property error Error Message
   * @property footerData Calculated totals for bottom of Detail/Summary Reports
   * @property summaryTableData Calculated table data for Summary Report
   * @property notes Object used for conditionally rendering notes at bottom of Detail Report
   */
  const initialState: WCBInitialState = {
    data: {
      appDetails: {
        storeId: 0,
        appName: '',
        storeName: '',
        storeAddress: '',
        reportName: '',
      },
      tableHeader: [],
      reportData: [],
    },
    footerData: {
      totalUnsoldPres: 0,
      totalUnsoldOrders: 0,
      totalUnsoldPresCost: 0,
      totalUnsoldPresPrice: 0,
      totalNewPres: 0,
      totalRefillPres: 0,
      totalPresUsingMess: 0,
    },
    summaryTableData: [],
    notes: {
      isWarning: false,
      isLockout: false,
      wasNotified: false,
      isEnrolled: false,
      incompleteScripts: false,
    },
  };

  // Get/Build URL and Query Params for API call
  const { location } = props;
  const { search, pathname = '' } = location;
  const params = new URLSearchParams(search);
  const queryParams: { [key: string]: string | boolean } = {};
  Array.from(params.keys()).forEach((key) => {
    let value: string | boolean;
    if (key === 'isSummaryReport') {
      value = params.get(key) === 'True' ? true : false;
    } else value = params.get(key) || 'Not Found';
    queryParams[key] = value;
  });
  let { isSummaryReport } = queryParams;
  const key = pathname.substr(1);
  const header = {};
  const URL = 'will-call-bin.json' || API_URL + getConfig(key);

  const {
    state: status,
    data: responseData,
    error,
  }: WCBResponseAndError = useApi(URL, queryParams, header);

  const data = responseData || initialState.data;

  /**
   *
   * @description parses all data for report
   * @param data response data
   * @param isSummaryReport boolean used to conditionally parse summary report data
   * @returns parsed data for reports
   */
  const parseResponseData = (
    data: WCBResponseData | null,
    isSummaryReport: string | boolean,
  ) => {
    if (data) {
      const footerData = getFooterData(data);

      const summaryTableData = isSummaryReport
        ? getSummaryTableData(data)
        : initialState.summaryTableData;

      const reportName = isSummaryReport
        ? 'WILL CALL BIN SUMMARY REPORT'
        : data.appDetails.reportName;

      const { notes, annotatedTableData } = !isSummaryReport
        ? getAnnotatedTableData(data)
        : {
            notes: initialState.notes,
            annotatedTableData: data.reportData,
          };

      const parsedResponseData = {
        ...data,
        appDetails: {
          ...data.appDetails,
          reportName,
        },
        reportData: annotatedTableData,
      };

      return {
        data: parsedResponseData,
        footerData,
        summaryTableData,
        notes,
      };
    }
  };

  /**
   *
   * @description adds annotations to patient names
   * @param prescriptions array of prescriptions
   * @returns annotated table data
   */
  const getAnnotatedTableData = ({
    reportData: prescriptions,
  }: {
    reportData: Script[];
  }) => {
    const notes = { ...initialState.notes };

    const MIN_PICKUP_DAYS = 20;
    const MAX_PICKUP_DAYS = 29;
    const currentDate = moment('20201207', 'YYYYMMDD');
    let daysDiff = 0;

    const annotatedTableData = prescriptions.map((script) => {
      let notify = '';
      let asteriskString = '';
      let orderIdentifier = '';
      let readyReminderEnrolledString = '';
      const activityTs = moment(script.activityTs, 'MM-DD-YYYY');

      if (script.activityTs) {
        daysDiff = moment(currentDate).diff(activityTs, 'days');
      }

      if (daysDiff > MIN_PICKUP_DAYS && daysDiff <= MAX_PICKUP_DAYS) {
        asteriskString = '*';
        notes.isWarning = true;
      }

      if (daysDiff > MAX_PICKUP_DAYS) {
        asteriskString = '**';
        notes.isLockout = true;
      }

      if (script.patNotifyInd === 1) {
        notify = '^';
        notes.wasNotified = true;
      }

      if (script.patientEnrolled) {
        readyReminderEnrolledString = '&';
        notes.isEnrolled = true;
      }

      if (script.rxCount > 0) {
        orderIdentifier = '#';
        notes.incompleteScripts = true;
      }

      const noteStringBuilder =
        readyReminderEnrolledString +
        asteriskString +
        notify +
        orderIdentifier;

      return {
        ...script,
        patient: `${noteStringBuilder}${script.patient}`,
      };
    });
    return { annotatedTableData, notes };
  };

  /**
   *
   * @description calculates totals for summary table
   * @param prescriptions array of prescriptions
   * @returns summary table data
   */
  const getSummaryTableData = ({
    reportData: prescriptions,
  }: {
    reportData: Script[];
  }) => {
    const summaryTableMap: { [key: string]: SummaryObject } = {};

    prescriptions.forEach(({ day }, id) => {
      if (!summaryTableMap[day])
        summaryTableMap[day] = { id, dayNo: day, rxCount: 0 };
      summaryTableMap[day].rxCount += 1;
    });

    return Object.values(summaryTableMap);
  };

  /**
   *
   * @description calculates totals for footer
   * @param prescriptions array of prescriptions
   * @returns footer data
   */
  const getFooterData = ({
    reportData: prescriptions,
  }: {
    reportData: Script[];
  }) => {
    const footerData = {
      ...initialState.footerData,
      totalUnsoldPres: prescriptions.length,
    };

    const orderTracker = new Set();
    prescriptions.forEach((script) => {
      if (script.patNotifyInd === 1)
        footerData.totalPresUsingMess += 1;

      if (script.newOrRefill === 'N') footerData.totalNewPres += 1;
      if (script.newOrRefill === 'R') footerData.totalRefillPres += 1;

      footerData.totalUnsoldPresPrice = Number.parseFloat(
        (footerData.totalUnsoldPresPrice + script.price).toFixed(2),
      );
      footerData.totalUnsoldPresCost = Number.parseFloat(
        (footerData.totalUnsoldPresCost + script.cost).toFixed(2),
      );

      if (!orderTracker.has(script.orderId)) {
        orderTracker.add(script.orderId);
        footerData.totalUnsoldOrders += 1;
      }
    });

    return footerData;
  };

  const state =
    parseResponseData(data, isSummaryReport) || initialState;

  return (
    <ReportWrapper
      loading={status === apiStates.LOADING}
      error={status === apiStates.ERROR ? error : null}
    >
      {isSummaryReport ? (
        <WillCallBinSummary {...props} state={state} />
      ) : (
        <WillCallBinDetailed {...props} state={state} />
      )}
    </ReportWrapper>
  );
};

export default PrintWrapper(WillCallBinMain);
