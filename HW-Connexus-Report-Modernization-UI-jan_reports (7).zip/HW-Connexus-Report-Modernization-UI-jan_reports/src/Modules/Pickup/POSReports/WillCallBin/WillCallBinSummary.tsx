/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Edward Robinson(vn50zua)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for returning the
 * Will Call Bin Summary Report to be conditionally rendered by Will Call Bin Main.
 *
 */

import { Grid } from '@material-ui/core';
import moment from 'moment';
import React, { FC } from 'react';
import {
  HeaderContainer,
  ParaContainer,
  ReportContainer,
} from './../../../../assets/common.styled';
import { WCBSummaryState } from './WCBReport.types';
import SummaryTable from './WCBSummaryTable';
import footerComponent from './WillCallBinFooter';
import { StyledGrideHeaderContainer } from '../../../Audit/TempUser/TempUser.styled';

/**
 * WillCallBinSummary Component
 */
export const WillCallBinSummary: FC<{ state: WCBSummaryState }> = ({
  state,
}) => {
  const { data, footerData, summaryTableData } = state;
  const { appDetails } = data;

  const customSummaryHeaders = [
    {
      id: 'dayNo',
      label: 'Day',
    },
    {
      id: 'rxCount',
      label: 'Rx',
    },
  ];

  return (
    <ReportContainer>
      <Grid container spacing={10}>
        <Grid item xs={2}>
          <ParaContainer>{`Store #: ${appDetails.storeId}`}</ParaContainer>
          <ParaContainer>{`Report Date: ${moment().format(
            'MM/DD/YYYY',
          )}`}</ParaContainer>
        </Grid>
        <StyledGrideHeaderContainer item xs={7}>
          <HeaderContainer>{appDetails.appName}</HeaderContainer>
          <HeaderContainer>{appDetails.storeName}</HeaderContainer>
          <HeaderContainer>{appDetails.reportName}</HeaderContainer>
        </StyledGrideHeaderContainer>
        <StyledGrideHeaderContainer item xs={3}>
          <HeaderContainer>{appDetails.storeAddress}</HeaderContainer>
        </StyledGrideHeaderContainer>
      </Grid>
      <SummaryTable
        data={summaryTableData}
        header={customSummaryHeaders}
        footer={footerComponent(footerData)}
      />
    </ReportContainer>
  );
};
