/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Edward Robinson(vn50zua)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for returning the
 * Will Call Bin Detail Table to be rendered by Will Call Bin Detail Report.
 *
 */

import { TableCell, TableRow } from '@material-ui/core';
import React, { FC } from 'react';
import { Script, HeaderObject } from './WCBReport.types';
import {
  StyledTable,
  StyledTableHeaderRow,
  StyledTableHeaderCell,
  StyledTableBody,
  StyledTableRow,
  StyledTableBodyCell,
  StyledTableHead,
} from './WillCallBin.styled';

const WillCallBinDetailedTable: FC<{
  data: Script[];
  header: HeaderObject[];
  footer: JSX.Element;
}> = ({ data: prescriptions, header: rows, footer }) => {
  /**
   * @desc checks patient name for notation, returns classname for matching style
   * @param data - patient object
   * @return classname string
   */
  const notationClassName = (n: Script) => {
    const regexMatchArr = n.patient.match(/(\*)/g);

    const asteriskArr = regexMatchArr ? regexMatchArr : [];

    switch (asteriskArr.length) {
      case 1:
        return 'yellow';
      case 2:
        return 'orangered';
      default:
        return '';
    }
  };

  return (
    <StyledTable aria-labelledby="tableTitle" id="reportTable">
      <StyledTableHead>
        <StyledTableHeaderRow>
          {rows.map((row) => (
            <StyledTableHeaderCell key={row.id}>
              {row.label}
            </StyledTableHeaderCell>
          ))}
        </StyledTableHeaderRow>
      </StyledTableHead>
      <StyledTableBody id="reportTableBody">
        {prescriptions.length ? (
          prescriptions.map((n, index) => (
            <StyledTableRow
              id={`reportTableRow${index}`}
              hover
              tabIndex={-1}
              key={`${n.unique}`}
              bgcolor={notationClassName(n)}
            >
              {rows.map((row) => (
                <StyledTableBodyCell key={`${row.id} - ${n.unique}`}>
                  {n[row.id]}
                </StyledTableBodyCell>
              ))}
            </StyledTableRow>
          ))
        ) : (
          <TableRow hover tabIndex={-1}>
            <>
              <TableCell colSpan={12}>
                <div role="alert">
                  Please enter correct Data and Search
                </div>
              </TableCell>
            </>
          </TableRow>
        )}
      </StyledTableBody>
      {footer}
    </StyledTable>
  );
};

export default WillCallBinDetailedTable;
