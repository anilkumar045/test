/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Edward Robinson(vn50zua)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This function is responsible for returning the
 * Will Call Bin Footer to be rendered by Will Call Bin Reports.
 *
 */

import React from 'react';
import { TableFooter, TableRow } from '@material-ui/core';
import { FooterData } from './WCBReport.types';
import {
  StyledFooterPara,
  StyledSpan,
  StyledSummaryTableFooterCell,
} from './WillCallBin.styled';

/**
 *
 * @description function - binds data to a table footer
 * @param props footer data
 * @returns table footer
 */
const footerComponent = (props: FooterData) => {
  const {
    totalUnsoldPres,
    totalUnsoldOrders,
    totalUnsoldPresCost,
    totalUnsoldPresPrice,
    totalNewPres,
    totalRefillPres,
    totalPresUsingMess,
  } = props;

  return (
    <TableFooter>
      <TableRow>
        <StyledSummaryTableFooterCell>
          <StyledFooterPara>
            Total Unsold Prescriptions :
            <StyledSpan color={'red'}>{totalUnsoldPres}</StyledSpan>
          </StyledFooterPara>
          <StyledFooterPara>
            Total Unsold Orders :
            <StyledSpan color={'red'}>{totalUnsoldOrders}</StyledSpan>
          </StyledFooterPara>
          <StyledFooterPara>
            Total Unsold Prescriptions cost :
            <StyledSpan
              color={'blue'}
            >{`$${totalUnsoldPresCost}`}</StyledSpan>
          </StyledFooterPara>
          <StyledFooterPara>
            Total Unsold Prescriptions price :
            <StyledSpan
              color={'blue'}
            >{`$${totalUnsoldPresPrice}`}</StyledSpan>
          </StyledFooterPara>
          <StyledFooterPara>
            Total New Prescriptions :
            <StyledSpan color={'blue'}>{totalNewPres}</StyledSpan>
          </StyledFooterPara>
          <StyledFooterPara>
            Total Refill Prescriptions :
            <StyledSpan color={'blue'}>{totalRefillPres}</StyledSpan>
          </StyledFooterPara>
          <StyledFooterPara>
            Total Prescriptions using Prescription Messaging :
            <StyledSpan color={'blue'}>
              {totalPresUsingMess}
            </StyledSpan>
          </StyledFooterPara>
        </StyledSummaryTableFooterCell>
      </TableRow>
    </TableFooter>
  );
};

export default footerComponent;
