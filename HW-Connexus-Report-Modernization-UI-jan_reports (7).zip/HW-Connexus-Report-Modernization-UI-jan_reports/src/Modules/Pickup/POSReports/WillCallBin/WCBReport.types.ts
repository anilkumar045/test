/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Edward Robinson(vn50zua)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This file is responsible for providing custom types via
 * TypeScript interfaces for Will Call Bin Reports.
 *
 */

import {
  ResponseData,
  UseApiHookState,
} from '../../../Common/StateAndResponseTypes';

export interface WCBInitialState {
  data: WCBResponseData;
  footerData: FooterData;
  summaryTableData: SummaryObject[];
  notes: Notes;
}

export interface WCBResponseData
  extends ResponseData<Script, HeaderObject> {
  reportData: Script[];
  tableHeader: HeaderObject[];
}

export interface WCBSummaryState extends WCBInitialState {
  footerData: FooterData;
  summaryTableData: SummaryObject[];
}

export interface WCBDetailsState extends WCBInitialState {
  footerData: FooterData;
  notes: Notes;
}

export interface Script {
  unique: number;
  orderId: number;
  patient: string;
  rx: number;
  dispMethod: string;
  qty: number;
  dispensedItem: string;
  day: number;
  color: string;
  bag: number;
  pdc: string;
  price: number;
  cost: number;
  primaryIns: string;
  secondaryIns: string;
  patientPhone: string;
  patNotifyInd: number;
  newOrRefill: string;
  activityTs: string;
  patientEnrolled: boolean;
  rxCount: number;
  [key: string]: string | boolean | number;
}

export interface HeaderObject {
  id: string;
  label: string;
  [key: string]: string;
}

export interface SummaryObject {
  id: number;
  dayNo: number;
  rxCount: number;
  [key: string]: number;
}

export interface FooterData {
  totalUnsoldPres: number;
  totalUnsoldOrders: number;
  totalUnsoldPresCost: number;
  totalUnsoldPresPrice: number;
  totalNewPres: number;
  totalRefillPres: number;
  totalPresUsingMess: number;
}

export interface Notes {
  isWarning: boolean;
  isLockout: boolean;
  wasNotified: boolean;
  isEnrolled: boolean;
  incompleteScripts: boolean;
}

export interface WCBResponseAndError
  extends UseApiHookState<WCBResponseData> {
  data: WCBResponseData | null;
}
