/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Edward Robinson(vn50zua)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for returning the
 * Will Call Bin Detail Report to be conditionally rendered by Will Call Bin Main.
 *
 */

import { Grid } from '@material-ui/core';
import React, { FC } from 'react';
import moment from 'moment';
import footerComponent from './WillCallBinFooter';
import { WCBDetailsState } from './WCBReport.types';
import {
  ReportContainer,
  ParaContainer,
  HeaderContainer,
} from './../../../../assets/common.styled';
import {
  WarningNotes,
  LockoutsNotes,
  Notes,
  NotesContainer,
} from './WillCallBin.styled';
import WillCallBinDetailedTable from './WCBDetailedTable';
import { StyledGrideHeaderContainer } from '../../../Audit/TempUser/TempUser.styled';
/**
 * WillCallBinDetailed Component
 */
export const WillCallBinDetailed: FC<{ state: WCBDetailsState }> = ({
  state,
}) => {
  const { data, footerData, notes } = state;
  const { appDetails, reportData, tableHeader } = data;

  const {
    isWarning,
    isLockout,
    wasNotified,
    isEnrolled,
    incompleteScripts,
  } = notes;

  return (
    <ReportContainer>
      <Grid container spacing={10}>
        <Grid item xs={2}>
          <ParaContainer>{`Store #: ${appDetails.storeId}`}</ParaContainer>
          <ParaContainer>{`Report Date: ${moment().format(
            'MM/DD/YYYY',
          )}`}</ParaContainer>
        </Grid>
        <StyledGrideHeaderContainer item xs={7}>
          <HeaderContainer>{appDetails.appName}</HeaderContainer>
          <HeaderContainer>{appDetails.storeName}</HeaderContainer>
          <HeaderContainer>{appDetails.reportName}</HeaderContainer>
        </StyledGrideHeaderContainer>
        <StyledGrideHeaderContainer item xs={3}>
          <HeaderContainer>{appDetails.storeAddress}</HeaderContainer>
        </StyledGrideHeaderContainer>
      </Grid>
      <WillCallBinDetailedTable
        data={reportData}
        header={tableHeader}
        footer={footerComponent(footerData)}
      />

      <NotesContainer>
        {isWarning && (
          <WarningNotes>NOTE: * denotes Pickup WARNINGS</WarningNotes>
        )}
        {isLockout && (
          <LockoutsNotes>
            NOTE: ** denotes Pickup LOCKOUTS
          </LockoutsNotes>
        )}
        {wasNotified && (
          <Notes>
            NOTE: ^ denotes Patient received order ready text/voice
            message.
          </Notes>
        )}
        {incompleteScripts && (
          <Notes>
            NOTE: # denotes Patient not notified due to all
            prescriptions in order not being complete.
          </Notes>
        )}
        {isEnrolled && (
          <Notes>
            NOTE: & denotes Patient enrolled for messaging.
          </Notes>
        )}
      </NotesContainer>
    </ReportContainer>
  );
};
