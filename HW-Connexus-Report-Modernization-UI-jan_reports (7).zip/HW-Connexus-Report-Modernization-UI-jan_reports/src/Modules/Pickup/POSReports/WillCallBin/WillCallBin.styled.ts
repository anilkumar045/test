/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Edward Robinson(vn50zua)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This file is responsible for providing Styled Components
 * for Will Call Bin Reports.
 *
 */

import styled from 'styled-components';
import {
  TableHead,
  Table,
  TableRow,
  TableCell,
  TableBody,
} from '@material-ui/core';

type Props = {
  bgcolor: string;
  color: string;
  width: string;
};

export const Notes = styled.p`
  margin: 2px 0;
  font-size: 1.3em;
`;

export const WarningNotes = styled(Notes)`
  background-color: yellow;
`;
export const LockoutsNotes = styled(Notes)`
  background-color: red;
`;
export const StyledTable = styled(Table)`
  margin-top: 3px;
`;

export const StyledTableHead = styled(TableHead)`
  width: 100%;
`;

export const StyledTableHeaderRow = styled(TableRow)`
  background-color: #fffacd;
  border-top: 1px solid #000;
  border-bottom: 1px solid #000;
`;

export const StyledTableHeaderCell = styled(TableCell)`
  padding: 10px 6px;
  font-size: 11px;
  border-bottom: 0px;
  font-weight: bold;
  color: inherit;
  line-height: 24px;
`;

export const StyledSummaryTableHeaderCell = styled(
  StyledTableHeaderCell,
)`
  line-height: 1rem;
  width: ${(props: Props) => props.width || ''};
`;

export const StyledTableBody = styled(TableBody)`
  border-bottom: 1px solid #000;
`;

export const StyledTableRow = styled(TableRow)`
  background-color: ${(props: Props) => props.bgcolor || ''};
`;

export const StyledTableBodyCell = styled(TableCell)`
  padding: 4px 6px 4px 6px;
  font-size: 11px;
  border: 1px solid white;
`;

export const StyledSummaryTable = styled(Table)`
  word-wrap: break-word;
  table-layout: fixed;
  width: 100%;
`;

export const StyledSummaryTableBodyCell = styled(StyledTableBodyCell)`
  border: none;
  border-bottom: 0px;
`;

export const StyledSummaryTableFooterCell = styled(TableCell)`
  margin: 0;
  color: black;
  text-align: left;
  padding: 10px 0 0 0;
`;
export const StyledFooterPara = styled.p`
  margin: 0;
  padding: 0;
  font-size: 0.9em;
  font-weight: bold;
  line-height: 1.5;
`;

export const StyledSpan = styled.span`
  color: ${(props: Props) => props.color || ''};
`;

export const NotesContainer = styled.div`
  text-align: left;
`;
