import { Grid } from '@material-ui/core';
import React, { Component } from 'react';
import PrintWrapper from '../../../Common/PrintReport';
import { API_URL, getConfig } from '../../../../settings';
import Table from '../../../Common/Table';
import { getApi } from "../../../Common/AxiosCalls";

export class BaggingDetail extends Component {
  constructor(props) {
    super(props);
    /**
     * @type {object}
     * @property {object} data Input Data
     * @property {boolean} loading Loading Flag
     * @property {string} error Error Message
     */
    this.state = {
      data: null,
      loading: true,
      error: null,
    };
  }
  /**
       * componentDidMount
       * @desc life cycle method for making Api call
    */
  componentDidMount() {
    const { location } = this.props;
    const { search, pathname = '' } = location;
    const params = new URLSearchParams(search);
    const queryParams = {};
    [...params.keys()].forEach((key) => {
      queryParams[key] = params.get(key);
    });
    const key = pathname.substr(1);
    const header = {};
    const URL = API_URL + getConfig(key);

    getApi(
      URL,
      queryParams,
      header,
      (res) => {
        this.setState({ data: res.data, loading: false, error: null });
      },
      (err) => {
        this.setState({ data: null, error: err, loading: false });
      },
    );
  }

  /**
  * render
  * @return {ReactElement} markup
  */
  render() {
    const { data, loading, error } = this.state;
    if (loading) {
      return <div>Loading ....</div>
    }
    if (error) {
      return <div>Error : {error}</div>
    }
    const pharmacist = {
      "Pharmacist": 0,
      "Non-Pharmacist": 0,
    }
    /**
     * Doing the Calculation for Pharmacist and Non Pharmacist
     */
    for (var i = 0; i < data.data.length; i++) {
      pharmacist[data.data[i].jobClass]++
    }
    return (
      <div className="report-container" >
        <Grid container spacing={3} justify="space-between">
          <Grid item xs>
            <p className="para">
              Store # :
              {data.storeId}
            </p>
            <p className="para">
              Report Date :
              {data.reportDate}
            </p>
          </Grid>
          <Grid item xs>
            <h5 className="pharma-header">{data.appName}</h5>
            <h5 className="pharma-header">{data.store}</h5>
            <br />
            <h5 className="pharma-header">{data.reportName}</h5>
          </Grid>
          <Grid item xs>
            <p className="para">{data.dateFrom}</p>
            <p className="para">{data.dateTo}</p>
            <p className="para">{data.address}</p>
            <p className="para">{data.detail}</p>
          </Grid>
        </Grid>
        <Grid container spacing={24}>
          <Grid item xs={12}>
            <Table
              data={data.data}
              header={data.header}
            />
          </Grid>
        </Grid>
        <Grid
          style={{
            fontSize: '100%', margin: '0', color: 'black', textAlign: 'left', padding: '10px 0 0 0',
          }}
        >
          Total Order Bagged :
              <span className="red bold">{pharmacist["Pharmacist"] + pharmacist["Non-Pharmacist"]}</span>
          <br />
          Orders Bagged by Pharmacist :
            <span className="red bold">{pharmacist["Pharmacist"]}</span>
          <br />
          Orders Bagged by Non Pharmacist  :
            <span className="red bold"> {pharmacist["Non-Pharmacist"]}</span>
          <br />
          <span style={{ fontSize: '120%' }}>Note: ^Denote Patient Has been Auto Notified</span>
        </Grid>
      </div>
    )
  }
}
export default PrintWrapper(BaggingDetail);