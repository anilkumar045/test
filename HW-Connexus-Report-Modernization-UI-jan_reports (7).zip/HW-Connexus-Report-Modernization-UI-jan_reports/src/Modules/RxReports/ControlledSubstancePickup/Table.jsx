import React, { Component, Fragment } from 'react';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import '../../../assets/table.css';

export default class CustomTable extends Component {
  render() {
    const { data: patientData, header: rows } = this.props;
    return (
      <Table aria-labelledby="tableTitle" id="reportTable" className="report-table">
        <TableHead style={{ width: '100%', borderTop: '1px solid #000', borderBottom: '1px solid #000' }}>
          <TableRow className="table-header-row" style={{ border: '0px', height: '22px' }}>
            {rows.map(
              (row) => (
                <TableCell
                  className="table-header-cell"
                  style={{ padding: '0px 10px' }}
                  key={row.id}
                >
                  {row.label1}
                </TableCell>
              ),
              this,
            )}
          </TableRow>
          <TableRow className="table-header-row" style={{ border: '0px', height: '22px' }}>
            {rows.map(
              (row) => (
                <TableCell
                  className="table-header-cell"
                  style={{ padding: '0px 10px' }}
                  key={row.id}
                >
                  {row.label2}
                </TableCell>
              ),
              this,
            )}
          </TableRow>
          <TableRow className="table-header-row" style={{ border: '0px', height: '22px' }}>
            {rows.map(
              (row) => (
                <TableCell
                  className="table-header-cell"
                  style={{ padding: '0px 10px' }}
                  key={row.id}
                >
                  {row.label3}
                </TableCell>
              ),
              this,
            )}
          </TableRow>
        </TableHead>
        <TableBody id="reportTableBody" className="report-table-body">
          {patientData.length > 0 ? (
            patientData.map((n, index) => (
              <TableRow
                id={`reportTableRow${index}`}
                hover
                tabIndex={-1}
                key={n.unique}
              >
                {rows.map(
                  (row) => (
                    <TableCell key={n.unique + n[row.data1]} style={{ padding: '4px 6px 4px 6px', fontSize: '11px', borderBottom: '0px' }}>
                      {n[row.data1]}
                      {' '}
                      <br />
                      {' '}
                      {n[row.data2]}
                      {' '}
                      <br />
                      {' '}
                      {n[row.data3]}
                    </TableCell>
                  ),
                  this,
                )}
              </TableRow>

            ))
          ) : (
              <TableRow
                hover
                tabIndex={-1}
              >
                <Fragment>
                  <TableCell colSpan={12}>
                    <div className="alert alert-warning" role="alert">
                      Please enter correct Data and Search
									</div>
                  </TableCell>

                </Fragment>

              </TableRow>

            )}

        </TableBody>
      </Table>
    );
  }
}
