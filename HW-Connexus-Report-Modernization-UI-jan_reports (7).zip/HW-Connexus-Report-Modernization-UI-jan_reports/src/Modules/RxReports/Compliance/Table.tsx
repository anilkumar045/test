/** ********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Naga Krishna Koyya(vn50zub)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for rendering the Compliance Table
 * Report. This component take data from the parent component and renders that data in a UI table
 * to be viewed by the user.
 *
 */
import React, {Fragment } from 'react';
import {
  StyledTable,
  StyledTableHead,
  StyledTableHeaderRow,
  StyledTableHeaderCell,
  StyledTableBody,
  StyledTableBodyCell,
  StyledEmptyTableRow,
  StyledEmptyTableCell
} from './Compliance.styled';

import TableRow from '@material-ui/core/TableRow';
import '../../../assets/table.css';

/**
  * Change the table header depend on user search by drug or not.
  * @param {String} label the Label for header
  * @param {String} drug true for user search by drug and false for not.
  */
export function setTableHeader(label: string, drug: string) {
  if (drug === "true" && label === "DrugName") {
    label = "Patient";
  }
  if (drug !== "true" && label === "Qty") {
    label = "";
  }
  return label
}
/**
 * Change table data depend on user search by drug or not.
 * @param {List} data Table data
 * @param {String} row the Label for header
 * @param {String} drug true for user search by drug and false for not.
 */
export function setTableBody(data:GenericObjProps, row: string, drug: string) {
  if (row === "drugName" && drug !== "true") {
    return (
      <div>{data["drugName"]}<br />Qty: {data["quantity"]}</div>
    )
  }
  if (row === "quantity" && drug !== "true") {
    return ""
  }
  return data[row]

}
interface GenericObjProps {
  unique?: number;
  id?: string;
  label?: string;
  [key: string]: string | boolean | number |undefined;
}

interface GenericTableProps {
  data: GenericObjProps[];
  header: GenericObjProps[];
  drug: string;
}
 /**
   * render
   * @return {ReactElement}  content for this component
   */
const CustomTable : React.FC<GenericTableProps> = <
D extends GenericObjProps,
H extends GenericObjProps,
F extends string
>({
data: patientData,
header: rows,
drug :checkDrug,
}: {
data: D[];
header: H[];
drug: F;
}) => (
    <StyledTable aria-labelledby="tableTitle" id="reportTable" className="report-table">
      <StyledTableHead>
        <StyledTableHeaderRow >
          {rows.map((row, index: number) => (
            <StyledTableHeaderCell
              key={index}

            >
         
             {row.label&&setTableHeader(row.label, checkDrug)}
            </StyledTableHeaderCell>
          )
          )}
        </StyledTableHeaderRow>
      </StyledTableHead>
      <StyledTableBody id="reportTableBody">
        {patientData.length > 0 ? (
          patientData.map((n, index: number) => (
            <TableRow
              id={`reportTableRow${index}`}
              hover
              tabIndex={-1}
              key={index}
            >
              {rows.map(
                (row, index: number) => (

                  <StyledTableBodyCell key={index}>

                    {row.id&&setTableBody(n, row.id, checkDrug)}
                  </StyledTableBodyCell>
                )
              )}
            </TableRow>

          ))
        ) : (
            <StyledEmptyTableRow
              hover
              tabIndex={-1}
            >
              <Fragment>
                <StyledEmptyTableCell colSpan={12}>
                  <div className="alert alert-warning" role="alert">
                    No Record Found
									</div>
                </StyledEmptyTableCell >
              </Fragment>
            </StyledEmptyTableRow>
          )}
      </StyledTableBody>
    </StyledTable>
  )

export default CustomTable;
