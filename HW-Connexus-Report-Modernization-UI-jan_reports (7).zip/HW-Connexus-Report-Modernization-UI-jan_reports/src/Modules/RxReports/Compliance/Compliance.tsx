/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Feng Lin(vn5101e)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for rendering the compliance Report.
 * This component requests data from the API and renders that data in a UI table to be viewed
 * by the user. The initial request is originated in Connexus. The details of the request are
 * received as query parameters via the URL.
 *
 */
import { Grid } from '@material-ui/core';
import PrintWrapper from '../../Common/PrintReport';
import CustomTable from './Table';
import { API_URL, getConfig } from '../../../settings';
import React, { useEffect, useState } from 'react';
import {
  SideContainer,
  ReportContainer,
  ParaContainer,
  HeaderContainer,
  UnderlinedContainer,
} from './Compliance.styled';
import { useApi, apiStates } from '../../Common/useApi';
import { RouteComponentProps } from 'react-router';
import ReportWrapper from '../../Common/LoadingErrorWrapper';

/**
 * Compliance Component
 */
interface IHeader {
  complianceIndex: string;
  dateRange: string;
  drugName: string;
  dueDate: string;
  header: { [field: string]: string }[];
  includeDeceasedPatientsData: string;
  nextFillDate: string;
  showPatientIndex: string;
  showPrescriberIndex: string;
}
interface IData {
  appName: String;
  date: String;
  reportName: String;
  store: String;
  storeId: number;
  data: { [field: string]: string }[];
  complianceSummaryHeaderBO: IHeader;
}
type StateType = {
  state: string;
  error: string;
  data: IData;
};
type Props = {
  location: Location;
};
export const Compliance: React.FC<RouteComponentProps> = ({
  location,
}:RouteComponentProps) => {
  /**
   * Create an initial state from this component
   * @property {list} data Handle a list of data which return from server side
   */
  const initialState: IData = {
    appName: '',
    date: '',
    reportName: '',
    store: '',
    storeId: 0,
    data: [],
    complianceSummaryHeaderBO: {
      complianceIndex: '',
      dateRange: '',
      drugName: '',
      dueDate: '',
      header: [],
      includeDeceasedPatientsData: '',
      nextFillDate: '',
      showPatientIndex: '',
      showPrescriberIndex: '',
    },
  };

  /**
   *  Get and build the URL and parameter for API call
   */
  const [response, setResponse] = useState(initialState);
  const { search, pathname = '' } = location;
  const params = new URLSearchParams(search);
  const queryParams: { [key: string]: string } = {};
  Array.from(params.keys()).forEach((key) => {
    queryParams[key] = params.get(key) || '';
  });
  const key = pathname.substr(1);
  const URL = API_URL + getConfig(key);
  const header = {};

  /**
   * useApi
   * @desc react hook for making Api call
   */
  const { state, error, data }: StateType = useApi(
    URL,
    queryParams,
    header,
  );

  /**
   * useEffect
   * @desc created data session in window object and sent it to .net team
   */
  useEffect(() => {
    if (data && state === apiStates.SUCCESS) {
      setResponse(data);
    }
  }, [data, state]);

  /**
   * render
   * @return {ReactElement}  content for this component
   */

  return (
    <ReportWrapper
      loading={state === apiStates.LOADING}
      error={state === apiStates.ERROR ? error : null}
    >
      <ReportContainer>
        <Grid container spacing={10}>
          <Grid item xs={4}>
            <ParaContainer>{`Store # :${response.storeId}`}</ParaContainer>
            <ParaContainer>
              {`Report Date :${response.date}`}
            </ParaContainer>
            <br />
            <ParaContainer>
              {response.complianceSummaryHeaderBO.complianceIndex ===
              'Y'
                ? response.complianceSummaryHeaderBO.dateRange
                : 'Next Fill Date: ' +
                  response.complianceSummaryHeaderBO.dueDate}
            </ParaContainer>
          </Grid>
          <Grid item xs={4}>
            <HeaderContainer>{response.appName}</HeaderContainer>
            <HeaderContainer>{response.store}</HeaderContainer>
            <HeaderContainer>{response.reportName}</HeaderContainer>
            <HeaderContainer>
              {`By Next Fill Date ${
                response.complianceSummaryHeaderBO
                  .showPatientIndex === 'Y'
                  ? ', Patient'
                  : ''
              } 
              ${
                response.complianceSummaryHeaderBO
                  .showPrescriberIndex === 'Y'
                  ? ', Physician'
                  : ''
              } ${
                response.complianceSummaryHeaderBO
                  .includeDeceasedPatientsData === 'true'
                  ? ', DRUG'
                  : ''
              }`}
            </HeaderContainer>
          </Grid>
        </Grid>
        {/* Add the one column for Drug name, if user search by drug. */}
        {response.complianceSummaryHeaderBO
          .includeDeceasedPatientsData === 'true' && (
          <div>
            <UnderlinedContainer />
            <SideContainer>
              {`Drug: ${response.complianceSummaryHeaderBO.drugName}`}
            </SideContainer>
          </div>
        )}
        <UnderlinedContainer />
        <SideContainer>
          {`Due Date: ${response.complianceSummaryHeaderBO.dueDate}`}
        </SideContainer>

        <CustomTable
          data={response.data}
          header={response.complianceSummaryHeaderBO.header}
          drug={
            response.complianceSummaryHeaderBO
              .includeDeceasedPatientsData
          }
        />
      </ReportContainer>
    </ReportWrapper>
  );
};

export default PrintWrapper(Compliance);
