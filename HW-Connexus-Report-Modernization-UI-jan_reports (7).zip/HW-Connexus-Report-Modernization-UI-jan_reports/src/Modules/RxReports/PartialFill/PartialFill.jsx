import React, { Component } from 'react';
// import PropTypes from 'prop-types';
import { Grid } from '@material-ui/core';
import Table from './Table';
import PrintReport from '../../Common/PrintReport';
import { getApi } from '../../Common/AxiosCalls';
import { API_URL, getConfig } from '../../../settings';
/**
 * Partail Fill report
 */
export class PartialFill extends Component {
  /**
   * constructor
   * @param {object} props
   */
  constructor(props) {
    super(props);
    /**
     * @type {object}
     * @property {list} data Handle a list of data which return from server side
     * @property {boolean} loading Will show the content if loading is false - finished loading
     * @property {string} error Handle error Message
     */
    this.state = {
      data: null,
      loading: true,
      error: null,
    };
  }

  /**
   * componentDidMount
   * @desc life cycle method for making Api call
   */
  componentDidMount() {
    const { location } = this.props;
    const { search, pathname = '' } = location;
    const params = new URLSearchParams(search);
    const fromDate = params.get('fromDate');
    const toDate = params.get('toDate');
    const replayOut = params.get('replayOut');
    const sortOption = params.get('sortOption');
    const header = {};
    const key = pathname.substr(1);
    const URL = API_URL + getConfig(key);
    getApi(
      URL,
      {fromDate,toDate,replayOut,sortOption},
      header,
      (res) => {
        this.setState({ data: res.data, loading: false, error: null });
      },
      (err) => {
        this.setState({ data: null, error: err, loading: false });
      },
    );
  }

  /**
   * render
   * @return {ReactElement}  content for this component
   */
  render() {
    const { data, loading, error } = this.state;
    if (loading) {
      return <div>Loading ....</div>;
    }
    if (error) {
      return <div>{`Error: ${error}`}</div>;
    }
    return (
      <div className="report-container">
        <Grid container spacing={3} justify="space-between">
          <Grid item xs>
            <p className="para">{`Store #: ${data.storeId}`}</p>
            <p className="para">{`Report Date: ${data.date}`}</p>
            <p>{data.dateRange}</p>
          </Grid>
          <Grid item xs>
            <h5 className="pharma-header">{data.appName}</h5>
            <h5 className="pharma-header">{data.store}</h5>
            <h5 className="pharma-header">{data.reportName}</h5>
            <h5 className="pharma-header">{data.reportLayout}</h5>
          </Grid>
          <Grid item xs>
            <p className="para">{data.dateRange}</p>
            <p className="para">{data.details}</p>
          </Grid>
        </Grid>
        <Grid container spacing={24}>
          <Grid item xs={12}>
            <Table data={data.data.fillData} header={data.fillHeader} noOfRows={2}/>
          </Grid>
        </Grid>
        <Grid container spacing={24}>
          <Grid item xs={12}>
            <Table
              data={data.data.totalData}
              header={data.header}
              noOfRows={1}
            />
          </Grid>
        </Grid>
      </div>
    );
  }
}

export default PrintReport(PartialFill);
