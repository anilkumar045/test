import React, { Component, Fragment } from 'react';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';

import './CurrentOnHoldInventorySummaryStyle.css';

export class CurrentOnHoldInventorySummaryTable extends Component {
  render() {
    const { data: patientData, header: rows, footer, title, centerTitle } = this.props;
    return (

      // First mini report header must be centered. Assign class based on centerTitle prop
      <div>
        {
          (centerTitle) ?
            (<h4 className={"onHoldInventorySummaryReportTitle-header-first"}>{title}</h4>)
            :
            (<h4 className={"onHoldInventorySummaryReportTitle-header"}>{title}</h4>)
        }
        {/* Table Works by extracting the headers for the mini report. */}
        <Table aria-labelledby="tableTitle" id="reportTable" className="report-table-COHI">
          <TableHead style={{ width: '100%' }}>
            <TableRow className="table-header-row">
              {rows.map(
                (row, index) => (
                  <TableCell
                    className="table-header-cell-COHI"
                    key={row.id}
                  >
                    {row.label}
                  </TableCell>
                ),
                this,
              )}
            </TableRow>
          </TableHead>
          {/* The last column must have text-align properties of "right".
            You must also but a little bit of padding on the last row of each mini report. 
        */}
          <TableBody id="reportTableBody" className="report-table-body-COHI" style={{ paddingBottom: "50px" }}>
            {
              patientData.map((n, index) => (
                <TableRow
                  id={`reportTableRow${index}`}
                  className="report-table-body-row-COHI"
                  hover
                  tabIndex={-1}
                  key={n.unique}
                >
                  {rows.map(
                    (row, index) => (
                      // (((rows.length-1) === index) || ((rows.length-2 ===index) && (rows.length-2 !== 0))) */}
                      ((rows.length - 1) === index)
                        ?
                        (
                          <TableCell key={n.unique + n[row.id]}
                            style={{
                              fontSize: '11px',
                              textAlign: "right",
                            }}
                            className=
                            "report-table-body-cell"                          >
                            {n[row.id]}
                          </TableCell>
                        )
                        :
                        (
                          <TableCell
                            key={n.unique + n[row.id]}
                            style={{
                              fontSize: '11px',
                            }}
                            className=
                            "report-table-body-cell"
                          >
                            {n[row.id]}
                          </TableCell>
                        )))}
                </TableRow>
              ))}
          </TableBody>
          {footer}
        </Table>
      </div>
    );
  }
}

CurrentOnHoldInventorySummaryTable.defaultProps = {
  footer: null
}
