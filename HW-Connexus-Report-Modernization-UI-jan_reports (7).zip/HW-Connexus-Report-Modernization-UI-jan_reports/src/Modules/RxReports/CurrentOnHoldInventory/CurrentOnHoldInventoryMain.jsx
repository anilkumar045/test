import PropTypes from 'prop-types';
import React from 'react';

import { CurrentOnHoldInventorySummary } from './CurrentOnHoldInventorySummary';
import { CurrentOnHoldInventoryDetails } from './CurrentOnHoldInventoryDetails';

const CurrentOnHoldInventoryMain = (props) => {
  const { location } = props;
  const { search } = location;
  const params = new URLSearchParams(search);
  const isSummaryReport = params.get('isSummaryReport');

  return isSummaryReport === 'True' ? (
    <CurrentOnHoldInventorySummary {...props} />
  ) : (
    <CurrentOnHoldInventoryDetails {...props} />
  );
};

CurrentOnHoldInventoryMain.propTypes = {
  location: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default CurrentOnHoldInventoryMain;
