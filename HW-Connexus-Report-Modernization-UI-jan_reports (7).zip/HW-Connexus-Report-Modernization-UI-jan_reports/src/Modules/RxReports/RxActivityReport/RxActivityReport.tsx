import React, { useState, useEffect, FC } from 'react';
import PropTypes from 'prop-types';
import { Grid } from '@material-ui/core';
import moment from 'moment';
import Table from '../../Common/Table';
import PrintWrapper from '../../Common/PrintReport';
import { API_URL, getConfig } from '../../../settings';
import { getApi } from '../../Common/AxiosCall';
import { RouteComponentProps } from 'react-router';

/**
 * RxActivityReport Component
 */

interface RxActivityReportProps {
  location: { search: string; pathname: string };
}

interface RxActivityReportData {
  note: string;
  storeId: string;
  date: string;
  appName: string;
  store: string;
  reportName: string;
  details: string;
  header: { [field: string]: string }[];
  data: { [field: string]: string }[];
}

export const RxActivityReport: FC<RouteComponentProps> = (props) => {
  const [data, updateData] = useState<RxActivityReportData | null>(
    null,
  );
  const [loading, updateLoading] = useState<boolean>(true);
  const [error, updateError] = useState<null | string>(null);

  const { location } = props;
  const { search, pathname = '' } = location;
  const params = new URLSearchParams(search);
  const rxNumber = params.get('rxNumber');
  const fillDate = params.get('fillDate');
  const header = {};
  const key = pathname.substr(1);
  const apiHeader = {};
  const URL = API_URL + getConfig(key);
  const storeId = params.get('storeId');

  useEffect(() => {
    getApi(
      URL,
      { rxNumber, fillDate },
      apiHeader,
      (res) => {
        updateData(res.data);
        updateLoading(false);
        updateError(null);
      },
      (err) => {
        updateData(null);
        updateLoading(false);
        updateError(err);
      },
    );
  }, []);

  if (loading) {
    return <div>Loading ....</div>;
  }
  if (error) {
    return <div>{`Error :${error}`}</div>;
  }
  if (data) {
    return (
      <div className="report-container">
        <Grid container spacing={1}>
          <Grid item xs={4}>
            <p className="para">Store # :{storeId}</p>
            <p className="para">
              Report Date :{moment().format('MM/DD/YYYY')}
            </p>
          </Grid>
          <Grid item xs={4}>
            <h5 className="pharma-header">{data.appName}</h5>
            <h5 className="pharma-header">{data.store}</h5>
            <h5 className="pharma-header">{data.reportName}</h5>
          </Grid>
          <Grid item xs={4}>
            <p className="para">{data.details}</p>
          </Grid>
        </Grid>
        <Table data={data.data} header={data.header} />
        <h5>{data.note} </h5>
      </div>
    );
  }
  return null;
};

export default PrintWrapper(RxActivityReport);
