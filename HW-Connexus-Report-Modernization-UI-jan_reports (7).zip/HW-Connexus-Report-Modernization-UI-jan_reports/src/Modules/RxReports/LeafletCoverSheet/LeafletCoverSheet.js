import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Grid } from '@material-ui/core';
import Table from '../../Common/Table';
import PrintWrapper from '../../Common/PrintReport';
import { API_URL, getConfig } from '../../../settings';
import { getApi } from '../../Common/AxiosCalls';

/**
 * Leaflet Cover Sheet Component
 */
export class LeafletCoverSheet extends Component {
  /**
   * constructor
   * @param {object} props
   */
  constructor(props) {
    super(props);
    /**
     * @type {object}
     * @property {list} data Handle a list of data which return from server side
     * @property {boolean} loading shows the content if flag is false which mean done with load
     * @property {string} error Handle error Message
     */
    this.state = {
      data: null,
      loading: true,
      error: null,
    };
  }

  /**
   * componentDidMount
   * @desc life cycle method for making Api call
   */
  componentDidMount() {
    const { location } = this.props;
    const { search, pathname = '' } = location;
    const params = new URLSearchParams(search);
    const startSoldDate = params.get('startSoldDate');
    const endSOldDate = params.get('endSOldDate');
    const header = {};
    const key = pathname.substr(1);
    const URL = API_URL + getConfig(key);
    getApi(
      URL,
      { startSoldDate, endSOldDate },
      header,
      (res) => {
        this.setState({
          data: res.data,
          loading: false,
          error: null,
        });
      },
      (err) => {
        this.setState({ data: null, error: err, loading: false });
      },
    );
    // axios.get(URL, { params: { startSoldDate, endSOldDate } })
    //   .then(({ data }) => this.setState({ data, loading: false, error: null }))
    //   .catch(({ message }) => this.setState({ data: null, error: message, loading: false }));
  }

  /**
   * render
   * @return {ReactElement}  content for this component
   */
  render() {
    const { data, loading, error } = this.state;
    if (loading) {
      return <div>Loading ....</div>;
    }
    if (error) {
      return <div>{`Error :${error}`}</div>;
    }
    return (
      <div className="report-container">
        <Grid container spacing={24}>
          <Grid item xs={4}>
            <p className="para">{`Store # :${data.storeId}`}</p>
            <p className="para">{`Report Date :${data.date}`}</p>
          </Grid>
          <Grid item xs={4}>
            <h5 className="pharma-header">{data.appName}</h5>
            <h5 className="pharma-header">{data.store}</h5>
            <h5 className="pharma-header">{data.reportName}</h5>
          </Grid>
        </Grid>
        <br />
        <p className="para">
          {`${data.dateRange.from} to
          ${data.dateRange.to}`}
        </p>
        <Table data={data.data} header={data.header} />
      </div>
    );
  }
}

LeafletCoverSheet.propTypes = {
  location: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default PrintWrapper(LeafletCoverSheet);
