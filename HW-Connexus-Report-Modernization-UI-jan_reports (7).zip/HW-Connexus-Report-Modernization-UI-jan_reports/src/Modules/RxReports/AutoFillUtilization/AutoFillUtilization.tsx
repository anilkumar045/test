/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Nick Steen (vn50vbw)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for rendering the AutoFillUtilization Report.
 * This component requests data from the API and renders that data in a UI table to be viewed
 * by the user. The initial request is originated in Connexus. The details of the request are
 * received as query parameters via the URL.
 *
 */

import { Grid } from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import PrintWrapper from '../../Common/PrintReport';
//import Table from './UtilizationTable';
import { getApi } from '../../Common/AxiosCall';
import { API_URL, getConfig } from '../../../settings';
import { AxiosResponse } from 'axios';
import { RouteComponentProps } from 'react-router';
import { Header5Container } from './AutoFill.styled'


interface ResponseData {
  storeId: number;
  date: string;
  appName: string;
  store: string;
  reportName: string;
  header: object[];
  data: object[];
};

interface InitialState {
  data: any;
  loading: boolean;
  error: Error | string | null;
  note: string;
  details: string;
};

/*
 *
 * AutoFillUtilization Component
 */
export const AutoFillUtilization = (props: RouteComponentProps) => {

  const initialState: InitialState = {
    data: {},
    loading: true,
    error: null,
    note: '',
    details: ''
  };


  // useState hooks returns state and set state method
  const [state, setState] = useState(initialState);


  // useEffect hook - component did mount implementation for making Api call
  useEffect(() => {
    // Get/Build URL and Query Params for API call
    const { location } = props;
    const { search, pathname = '' } = location;
    const params = new URLSearchParams(search);
    const queryParams: { [key: string]: string } = {};
    Array.from(params.keys()).forEach((key) => {
      queryParams[key] = params.get(key) || '';
    });
    const { fromDate, toDate } = queryParams;
    const key = pathname.substr(1);
    const header = {};
    const URL = API_URL + getConfig(key);
    console.log(queryParams);
    getApi(
      URL,
      //   URL,
      queryParams,
      header,
      ({ data }: AxiosResponse) => {
        // setState({
        //   data,
        //   loading: false,
        //   error: null,
        //   // note,
        //   // details
        // });
      },
      (error: string) => {
        setState((prevState: any) => ({
          ...prevState,
          error,
          loading: false,
        }));
      },
    );
  }, []);

  const { data, loading, error, note, details } = state;

  if (loading) {
    return <div>Loading ....</div>;
  }
  if (error) {
    return <div>{`Error: ${error}`}</div>;
  }
  return (
    <div className="report-container">
      <Grid container spacing={10}>
        <Grid item xs={4}>
          <p className="para">{`Store #: ${data.storeId}`}</p>
          <p className="para">{`Report Date: ${data.reportDate}`}</p>
          <p className="para">{`From: ${data.dateRange}`}</p>
        </Grid>
        <Grid item xs={4}>
          <h5 className="pharma-header">{data.appName}</h5>
          <h5 className="pharma-header">{data.store}</h5>
          <h5 className="pharma-header">{data.reportName}</h5>
        </Grid>
        <Grid item xs={4}>
          <p className="para">{data.details}</p>
        </Grid>
      </Grid>
      {/* <Table patientData={data.data} rows={data.header} /> */}
      <Header5Container>
        {note}
        {
          '***PRIVATE-IF YOU SEE THIS REPORT IN ERROR, PLEASE RETURN TO WAL-MART PHARMACY IMMEDIATELY***'
        }
      </Header5Container>
    </div>
  );
}


