/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Nick Steen (vn50vbw)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Style Module is responsible for styling the AutoFillUtilization table.
 * 
 */

import styled from 'styled-components';
import {
    Table,
    TableHead,
    TableBody,
    TableRow,
    TableCell,
} from '@material-ui/core';

export const StyledTable = styled(Table) `
margin-top: 3px;
`;
export const StyledTableHead = styled(TableHead) `
width: 100%;
`;
export const StyledTableHeaderRow = styled(TableRow) `
`;
export const StyledTableHeaderCell = styled(TableCell) `
`;
export const StyledTableBody = styled(TableBody) `
`;
export const StyledTableTotalsTableRow = styled(TableRow) `
border-top: 1px solid black;
`
export const StyledTableBodyCell = styled(TableCell) `
padding: '4px 6px 4px 6px';
font-size: '11px';
border-bottom: '0px';
`;

export const StyledTableCellDataSet = styled(TableCell) `
padding: '4px 6px 4px 6px';
fontSize: '11px';
borderTop: '1px solid black';
`