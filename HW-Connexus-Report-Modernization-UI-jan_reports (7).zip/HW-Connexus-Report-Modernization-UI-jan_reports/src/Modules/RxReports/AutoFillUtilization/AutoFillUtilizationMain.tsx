/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Nick Steen (vn50vbw)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for displaying the correct report component 
 * based on the reportType URL parameter.
 */

import PropTypes from 'prop-types';
import React from 'react';
import { AutoFillUtilization } from './AutoFillUtilization';
import { AutoFillSummary } from './AutoFillSummary';
import { AutoFillCancellation } from './AutoFillCancellation';
import { RouteComponentProps } from 'react-router';
import PrintWrapper from '../../Common/PrintReport';

const AutoFillUtilizationMain = (props: RouteComponentProps) => {
  const { location } = props;
  const { search } = location;
  const params = new URLSearchParams(search);
  const reportType = params.get('reportType');

  switch (reportType) {
    case '1':
      return <AutoFillSummary {...props} />
    case '2':
      return <AutoFillUtilization {...props} />
    default:
      return <AutoFillCancellation {...props} />
  }
};

export default PrintWrapper(AutoFillUtilizationMain);
