/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Nick Steen (vn50vbw)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for rendering the table in the 
 * AutoFillSummary/Cancellation reports
 * 
 * This component visually formats the data shown in the JSON response
 *
 */

import {
  StyledTable,
  StyledTableHead,
  StyledTableHeaderRow,
  StyledTableHeaderCell,
  StyledTableBody,
  StyledTableBodyCell,
  StyledTableTotalsTableRow
} from './SummaryTable.styled';

import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import PropTypes from 'prop-types';
import React from 'react';
import '../../../assets/table.css';

const SummaryTable = ({ data: patientData, header: rows, totals }: any) => (
  <StyledTable aria-labelledby="tableTitle" id="reportTable" className="report-table">
    <StyledTableHead>
      <StyledTableHeaderRow className="table-header-row">
        {rows.map(
          (row: any) => (
            <StyledTableHeaderCell className="table-header-cell" key={row.id}>
              {row.label}
            </StyledTableHeaderCell>
          ),
        )}
      </StyledTableHeaderRow>
    </StyledTableHead>
    <StyledTableBody id="reportTableBody" className="report-table-body">
      {patientData.length > 0 ? (
        patientData.map((n: any, index: number) => (
          <TableRow
            id={`reportTableRow${index}`}
            hover
            tabIndex={-1}
            key={`${n.unique}-table-row`}
          >
            {rows.map(
              (row: any) => (
                <StyledTableBodyCell
                  key={`${n.unique} - ${row.id}`}
                >
                  {n[row.id]}
                </StyledTableBodyCell>
              )
            )}
          </TableRow>
        ))
      ) : (
          <TableRow hover tabIndex={-1}>
            <TableCell colSpan={12}>
              <div className="alert alert-warning" role="alert">
                Please enter correct Data and Search
              </div>
            </TableCell>
          </TableRow>
        )}
      {/* Renders totals */}
      <StyledTableTotalsTableRow
        hover
        tabIndex={-1}
        selected // Set to true for totals bar shading
      >
        {rows.map((row: any) => (
          // totals obj with k,v pairs that match header ids ensuring data is accurately mapped
          <StyledTableBodyCell
            key={`${row.id}-table-row-cell-totals`}
          >
            {row.id === 'date' ? <strong>Totals:</strong> : totals[row.id]}
          </StyledTableBodyCell>
        ))}
      </StyledTableTotalsTableRow>
    </StyledTableBody>
  </StyledTable>
);

export default SummaryTable;
