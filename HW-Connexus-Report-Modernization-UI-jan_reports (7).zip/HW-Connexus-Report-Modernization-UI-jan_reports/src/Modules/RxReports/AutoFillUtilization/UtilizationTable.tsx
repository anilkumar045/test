/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Nick Steen (vn50vbw)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for rendering the table 
 * used in AutoFillUtilization report
 * 
 * This component visually formats the data shown in the JSON response
 *
 */

import {
  StyledTable,
  StyledTableHead,
  StyledTableHeaderRow,
  StyledTableHeaderCell,
  StyledTableBody,
  StyledTableBodyCell,
  StyledTableCellDataSet
} from './UtilizationTable.styled';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import PropTypes from 'prop-types';
import React, { Fragment } from 'react';
import '../../../assets/table.css';


const UtilizationTable = ({ patientData, rows }: { patientData: any, rows: any }) => {
  // Function receives object and renders a data set with header and relational data
  // Data received by this function is expected to have a one to many relationship
  const renderDataSet = (data: any) => {
    // check if orders exist before returning jsx
    if (data.orders.length) {
      return (
        <Fragment key={`${Object.values(data)[0]}`}>
          <StyledTableHeaderRow className="table-header-row" hover tabIndex={-1}>
            <StyledTableHeaderCell
            >
              {Object.values(data)[0]}
            </StyledTableHeaderCell>
          </StyledTableHeaderRow>

          {data.orders.map((order: any, index: any) => (
            <TableRow
              id={`reportTableRow${index}`}
              hover
              tabIndex={-1}
              key={`${order.unique}-table-row-data-set`}
            >
              {rows.map((row: any, idx: number) => {
                if (idx === 0) return null;
                return (
                  <StyledTableCellDataSet
                    key={order.unique + order[row.id]}
                  >
                    {order[row.id]}
                  </StyledTableCellDataSet>
                );
              })}
              <StyledTableCellDataSet
              />
            </TableRow>
          ))}
        </Fragment>
      );
    }
    return null;
  };

  return (
    <StyledTable
      aria-labelledby="tableTitle"
      id="reportTable"
      className="report-table"
    >
      <StyledTableHead>
        <TableRow className="table-header-row">
          {rows.map((row: any, i: any) => (
            <TableCell
              key={`${row.id}-${row.unique}-table-header-cell`}
              className="table-header-cell"
            >
              {i === 0 ? row.label : null}
            </TableCell>
          ))}
        </TableRow>
        <StyledTableHeaderRow className="table-header-row">
          {rows.map((row: any, i: number) => {
            if (i === 0) return null;
            return (
              <TableCell
                key={`${row.id}-${row.unique}-table-header-cell`}
                className="table-header-cell"
              >
                {row.label}
              </TableCell>
            );
          })}
          <StyledTableCellDataSet
          />
        </StyledTableHeaderRow>
      </StyledTableHead>
      <TableBody id="reportTableBody" className="report-table-body">
        {patientData.length > 0 ? (
          patientData.map((n: any) => renderDataSet(n))
        ) : (
            <TableRow hover tabIndex={-1}>
              <TableCell colSpan={12}>
                <div className="alert alert-warning" role="alert">
                  Please enter correct Data and Search
                </div>
              </TableCell>
            </TableRow>
          )}
      </TableBody>
    </StyledTable>
  );
};

export default UtilizationTable;
