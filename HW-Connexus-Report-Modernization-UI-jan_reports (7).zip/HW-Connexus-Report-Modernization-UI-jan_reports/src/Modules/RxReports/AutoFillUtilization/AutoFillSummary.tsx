/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Nick Steen (vn50vbw)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for rendering the AutoFillSummary Report.
 * This component requests data from the API and renders that data in a UI table to be viewed
 * by the user. The initial request is originated in Connexus. The details of the request are
 * received as query parameters via the URL.
 *
 */

import { Grid } from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import Table from './SummaryTable';
import { getApi } from '../../Common/AxiosCalls';
import { API_URL, getConfig } from '../../../settings';
import { AxiosResponse } from 'axios';
import { RouteComponentProps } from 'react-router';
import { Header5Container } from './AutoFill.styled'

interface ResponseData {
  storeId: number;
  reportDate: string;
  appName: string;
  store: string;
  reportName: string;
  details: string;
  dateRange: string;
  header: object[];
  data: object[];

};

interface InitialState {
  data: ResponseData;
  loading: boolean;
  error: Error | string | null;
  totals: number;
};

/**
     * @desc calculates totals, returns object w/ k,v pairs representing header ids & column totals
     * @param {object} data - response object
     * @return {object} aggregate object
     * 
*/
export let calculateTotals = (agrData: object[]) => {
  const excluded = new Set(['date', 'unique', 'orders']);
  return agrData.reduce((aggObj: any, obj: any) => {
    const keys = Object.keys(obj);
    keys.forEach((key) => {
      if (!excluded.has(key)) {
        if (!aggObj[key]) {
          aggObj[key] = 0;
        }
        // Need to add logic for utilization % calculation
        aggObj[key] += obj[key];
      }
    });
    return aggObj;
  }, {});
}
export const AutoFillSummary = (props: RouteComponentProps) => {

  /**
  * @type {object}
  * @property {object} data Input Data
  * @property {object} totals Aggregate Data
  * @property {boolean} loading Loading Flag
  * @property {string} error Error Message
  */
  const initialState: InitialState = {
    data: {
      storeId: NaN,
      reportDate: '',
      appName: '',
      store: '',
      reportName: '',
      details: '',
      dateRange: '',
      header: [],
      data: [],
    },
    loading: true,
    error: null,
    totals: 0,
  };


  // useState hooks returns state and set state method
  const [state, setState] = useState(initialState);


  // useEffect hook - component did mount implementation for making Api call
  useEffect(() => {
    // Get/Build URL and Query Params for API call
    const { location } = props;
    const { search, pathname = '' } = location;
    const params = new URLSearchParams(search);
    const queryParams: { [key: string]: string } = {};
    Array.from(params.keys()).forEach((key) => {
      queryParams[key] = params.get(key) || '';
    });
    const { fromDate, toDate } = queryParams;
    const key = pathname.substr(1);
    const header = {};
    const URL = API_URL + getConfig(key);
    getApi(
      URL,
      queryParams,
      //   URL,
      //   queryParams,
      header,
      ({ data }: AxiosResponse) => {
        let totals = calculateTotals(data.data);
        setState({
          data,
          loading: false,
          error: null,
          totals: totals
        });
      },
      (error: Error) => {
        setState((prevState: any) => ({
          ...prevState,
          error,
          loading: false,
        }));
      },
    );
  }, []);

  const { data, loading, error, totals } = state;

  if (loading) {
    return <div>Loading ....</div>;
  }
  if (error) {
    return <div>{`Error: ${error}`}</div>;
  }
  return (
    <div className="report-container">
      <Grid container spacing={10}>
        <Grid item xs={4}>
          <p className="para">{`Store #: ${data.storeId}`}</p>
          <p className="para">{`Report Date: ${data.reportDate}`}</p>
          <br />
          <p className="para">{`From: ${data.dateRange}`}</p>
        </Grid>
        <Grid item xs={4}>
          <h5 className="pharma-header">{data.appName}</h5>
          <h5 className="pharma-header">{data.store}</h5>
          <h5 className="pharma-header">{data.reportName}</h5>
        </Grid>
        <Grid item xs={4}>
          <p className="para">{data.details}</p>
        </Grid>
      </Grid>
      <Table data={data.data} header={data.header} totals={totals} />
      <Header5Container style={{ textAlign: 'center' }}>
        {/* {data.note} */}
        {
          '***PRIVATE-IF YOU SEE THIS REPORT IN ERROR, PLEASE RETURN TO WAL-MART PHARMACY IMMEDIATELY***'
        }
      </Header5Container>
    </div>
  );
}

