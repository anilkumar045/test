/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Nick Steen (vn50vbw)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for rendering the WaitForDrugOrder Report.
 *
 * This component requests data from the API and renders that data in a UI table to be viewed
 * by the user. The initial request is originated in Connexus. The details of the request are
 * received as query parameters via the URL.
 *
 */

import React, { useEffect, useState, FC } from 'react';
import PropTypes from 'prop-types';
import { Grid } from '@material-ui/core';
import Table from './Table';
import PrintWrapper from '../../Common/PrintReport';
import { getApi } from '../../Common/AxiosCalls';
import { API_URL, getConfig } from '../../../settings';
import { AxiosResponse } from 'axios';
import { RouteComponentProps } from 'react-router';
import ErrorMessage from '../../Common/ErrorMessage';
import { useApi, apiStates } from '../../Common/useApi';
import Loader from '../../Common/Loader';
import ReportWrapper from '../../Common/LoadingErrorWrapper';

interface IWaitForDrugOrderPatientData {
  fillDate: string;
  rxNo: string;
  patientName: string;
  phoneNumber: string;
  readyReminder: string;
  dispensedProduct: string;
  ndcNumber: string;
  itemNumber: string;
  source: string;
  quantity: string;
  [field: string]: string | number;
}
interface IWaitForDrugOrderHeader {
  label1: string;
  label2: string;
  label3: string;
  data1: string;
  data2?: string | undefined;
  data3?:string | undefined;
  [field: string]: string | undefined;
}
interface DateRange {
  from: string;
  to: string;
}
interface ResponseData {
  storeId: number;
  date: string;
  appName: string;
  store: string;
  reportName: string;
  header: IWaitForDrugOrderHeader[];
  data: IWaitForDrugOrderPatientData[];
  details: string;
  dateRange: DateRange;
}
interface InitialState {
  data: ResponseData;
  loading: boolean;
  error: Error | string | null;
  fromDate: string;
  toDate: string;
}
type stateType = { state: string; error: string; data: ResponseData };

/*
 *
 * WaitForDrugOrder Component
 */
export const WaitForDrugOrder: React.FC<RouteComponentProps>= (props) => {

    const initialData: ResponseData = {
      storeId: NaN,
      date: "",
      appName: "",
      store: "",
      reportName: "",
      header: [],
      data: [],
      details: "",
      dateRange: {
        from: "",
        to: "",
      }
    };
    const { location } = props;
    // Get/Build URL and Query Params for API call
    const { search, pathname = '' } = location;
    const params = new URLSearchParams(search);
    const queryParams: { [key: string]: string } = {};
    Array.from(params.keys()).forEach((key) => {
      queryParams[key] = params.get(key) || '';
    });
    const { fromDate, toDate } = queryParams;
    const key = pathname.substr(1);
    const header = {};
    const URL = API_URL + getConfig(key);
    const { state, error, data:responseData }: stateType = useApi(
      'wait-for-drug-order.json',
      {},
      header,
    );

    const data = responseData || initialData;
      return (
        <ReportWrapper
            loading={state === apiStates.LOADING}
            error={state === apiStates.ERROR ? error : null}
        >
        <div className="report-container">
          <Grid container spacing={8}>
            <Grid item xs={4}>
              <p className="para">{`Store #: ${data.storeId}`}</p>
              <p className="para">{`Report Date: ${data.date}`}</p>
            </Grid>
            <Grid item xs={4}>
              <h5 className="pharma-header">{data.appName}</h5>
              <h5 className="pharma-header">{data.store}</h5>
              <h5 className="pharma-header">{data.reportName}</h5>
            </Grid>
            <Grid item xs={4}>
              <p className="para">{data.details}</p>
            </Grid>
          </Grid>
          <br />
          <p className="para">{`From: ${data.dateRange.from} To: ${data.dateRange.to}`}</p>
          <Table patientData={data.data} rows={data.header} />
        </div>
        </ReportWrapper>
      ); 
  
};

export default PrintWrapper(WaitForDrugOrder);
