/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Nick Steen (vn50vbw)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for rendering the RxModificationLog Table.
 * 
 * This component visually formats the response JSON.
 *
 */

import React, { Component, Fragment } from 'react';
import {
  TableRow,
  TableCell
} from '@material-ui/core';
import {
  StyledTable, StyledTableHead, StyledTableHeaderRow,
  StyledTableHeaderCell, StyledTableBody, StyledTableBodyCell,StyledTableHeaderCellTopBorder
  ,StyledTableHeaderCellBottomBorder
} from './WaitForDrugOrder.styled';
// import '../../../assets/table.css';
import './WaitForDrug.css';

interface IWaitForDrugOrderHeader {
    label1: string;
    label2: string;
    label3: string;
    data1: string;
    data2?: string | undefined;
    data3?:string | undefined;
    [field: string]: string | undefined;
}
interface IWaitForDrugOrderPatientData {
    fillDate: string;
    rxNo: string;
    patientName: string;
    phoneNumber: string;
    readyReminder: string;
    dispensedProduct: string;
    ndcNumber: string;
    itemNumber: string;
    source: string;
    quantity: string;
    [field: string]: string | number;
}

const CustomTable = ({ patientData, rows }: { patientData: IWaitForDrugOrderPatientData[], rows: IWaitForDrugOrderHeader[]}) => {

  return (
    <StyledTable aria-labelledby="tableTitle" id="reportTable" className="report-table">
      <StyledTableHead>
        <StyledTableHeaderRow className="table-header-row-wait-for-drug" >
          {rows.map(
            (row) => (
              <StyledTableHeaderCellTopBorder
                className="table-header-cell-wait-for-drug-order"
                key={row.data1}
              >
                {row.label1}
              </StyledTableHeaderCellTopBorder>
            )
          )}
        </StyledTableHeaderRow>
        <StyledTableHeaderRow className="table-header-row-wait-for-drug">
          {rows.map(
            (row) => (
              <StyledTableHeaderCell
                className="table-header-cell"
                key={row.data2}
              >
                {row.label2}
              </StyledTableHeaderCell>
            )
          )}
        </StyledTableHeaderRow>
        <StyledTableHeaderRow className="table-header-row-wait-for-drug">
          {rows.map(
            (row) => (
              <StyledTableHeaderCellBottomBorder
                className="table-header-cell"
                key={row.data3}
              >
                {row.label3}
              </StyledTableHeaderCellBottomBorder>
            )
          )}
        </StyledTableHeaderRow>
      </StyledTableHead>
      <StyledTableBody id="reportTableBody" className="report-table-body">
        {patientData? (
          patientData.map((n:any, index: number) => (
            <TableRow
              id={`reportTableRow${index}`}
              hover
              tabIndex={-1}
              key={n.unique}
            >
              {rows.map(
                (row) => (
                  <StyledTableBodyCell key={n.unique + n[row.data1]} className="table-body-cell-wait-for-drug">
                    {n[row.data1]}
                    {' '}
                    {(row.data1 === "patientName" &&row.data2!=undefined && n[row.data1] && n[row.data2] ) ? "," : ""}
                    {row.data1 !== "patientName" ? <br /> : ""}
                    {' '}
                    {(row.data2!=undefined)?
                      (n[row.data2]):("")
                    }
                    {' '}
                    <br />
                    {' '}
                    {(row.data3!=undefined)?
                      (n[row.data3]):("")
                    }
                  </StyledTableBodyCell>
                )
              )}
            </TableRow>
          ))
        ) : (
            <TableRow
              hover
              tabIndex={-1}
            >
              <Fragment>
                <TableCell colSpan={12}>
                  <div className="alert alert-warning" role="alert">
                    Please enter correct Data and Search
									</div>
                </TableCell>
              </Fragment>
            </TableRow>
          )}
      </StyledTableBody>
    </StyledTable>
  );
}


export default CustomTable;

