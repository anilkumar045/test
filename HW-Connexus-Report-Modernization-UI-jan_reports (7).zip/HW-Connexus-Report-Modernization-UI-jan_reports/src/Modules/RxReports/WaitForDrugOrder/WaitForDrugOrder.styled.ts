/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Nick Steen (vn50vbw)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for sytling the WaitForDrugOrder table.
 * 
 */

import styled from 'styled-components';
import {
    Table,
    TableHead,
    TableBody,
    TableRow,
    TableCell,
} from '@material-ui/core';


export const StyledTable = styled(Table) `
marginTop: 3px;
`;
export const StyledTableHead = styled(TableHead) `
width: '100%';
`;
// export const StyledTableHeadTopBorder = styled(TableHead) `
// width: '100%';
// border-top: '1px solid #000';
// `;
// export const StyledTableHeadBottomBorder = styled(TableHead) `
// width: '100%';
// border-bottom: '1px solid #000';
// `;

export const StyledTableHeaderRow = styled(TableRow) `
border: 0px;
height: 22px;
`;
export const StyledTableHeaderCell = styled(TableCell) `
padding:  4px 6px 4px 6px;
font-weight:bold;
font-size:11px;
`;
export const StyledTableHeaderCellTopBorder = styled(TableCell) `
border-top:1px solid #000;
padding:  4px 6px 4px 6px;
font-weight:bold;
font-size: 11px
`;
export const StyledTableHeaderCellBottomBorder = styled(TableCell) `
border-bottom: 1px solid #000;
font-weight:bold;
font-size: 11px;
padding:  4px 6px 4px 6px;
`;
export const StyledTableBody = styled(TableBody) `
`;

export const StyledTableBodyCell = styled(TableCell) `
padding: 4px 6px 4px 6px;
font-size: 11px;
border-bottom: 0px;
`;

// export const ReportContainer = styled.div`
// background-color: #fffacd;
// padding: 15px;
// font-size: 11px;
// `;

// export const HeadingFour = styled.h4`
// margin: 0px;
// text-align:center;
// `;
// export const HeadingFive = styled.h5`
// margin-top: 0.5em;
// text-align:center;
// `;

// export const ParaContainer = styled.p`
// margin: 0px;
// `;