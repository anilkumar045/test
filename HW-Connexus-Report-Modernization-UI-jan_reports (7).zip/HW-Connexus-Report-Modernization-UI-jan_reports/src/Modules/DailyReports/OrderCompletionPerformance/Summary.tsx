/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Feng Lin(vn5101e)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for rendering the Order Completion Performance Summary Report.
 * This component take data from the parent component and renders that data in a UI table to be viewed
 * by the user. 
 *
 */
import React from 'react';
import { Grid } from '@material-ui/core';

import {
     ParaContainer, HeaderContainer, UnderlinedParaContainer
  } from '../../../assets/common.styled';
  import {SummaryProps} from './OrderCompletionPerformance.type'
  

/**
 * Summary component for order completion component
 * @param props will pass summary data to this component, return summary part.
 */
export const Summary: React.FC<SummaryProps> = ({
    data,
  }: SummaryProps) => {
    const summary=data;
    return (
        <div>
            <h3>Grand Total</h3>
            <UnderlinedParaContainer />
            <Grid container spacing={3} >
                <Grid item xs={4}>
                    <HeaderContainer>% Patient Expectation Met:</HeaderContainer>
                    <ParaContainer>Total Order</ParaContainer>
                    <ParaContainer>Total RXS</ParaContainer>
                    <ParaContainer>% Order went throgh RES</ParaContainer>
                    <ParaContainer>% RX went through RES</ParaContainer>
                    <ParaContainer>% Order 'Instore/First Available:</ParaContainer>
                    <ParaContainer>Average 'Instore/First Available' System Calculation(minutes):</ParaContainer>
                    <ParaContainer>Average 'Instore/First Available' Order Performance(minute):</ParaContainer>
                    <ParaContainer>Average 'Instore/First Available' Order Performance including RES(minute):</ParaContainer>
                    <ParaContainer>Total Orders On Time/Under Due:</ParaContainer>
                    <ParaContainer>% Orders 'Instore/First Available' On Time</ParaContainer>
                    <ParaContainer>% Orders 'Instore/First Available' On Time including RES:</ParaContainer>
                    <ParaContainer>% Orders 'Drive Thru' On Time:</ParaContainer>
                    <ParaContainer>% Orders 'Today' (excluding 'First Available') On Time:</ParaContainer>
                    <ParaContainer>% Orders 'Critical' On Time:</ParaContainer>
                    <ParaContainer>% Orders 'Dr Call In' On Time:</ParaContainer>
                    <ParaContainer>% Orders 'Future' On Time:</ParaContainer>
                    <ParaContainer>Avg Minutes Over Due Time:</ParaContainer>
                    <ParaContainer>Avg Minutes Under Due Time:</ParaContainer>
                    <ParaContainer>% Orders Due Time Modified</ParaContainer>
                    <ParaContainer>Due Time Modified By User ID</ParaContainer>
                </Grid>
                <Grid item xs={4}>
                    <ParaContainer>{summary.petientExpect.toFixed(2)}</ParaContainer>
                    <ParaContainer>{summary.totalorder}</ParaContainer>
                    <ParaContainer>{summary.totalRxs}</ParaContainer>
                    <ParaContainer>{summary.orderRes.toFixed(2)}</ParaContainer>
                    <ParaContainer>{summary.rxRes.toFixed(2)}</ParaContainer>
                    <ParaContainer>{summary.firstAvailable.toFixed(2)}</ParaContainer>
                    <ParaContainer>{summary.sysCal.toFixed(2)}</ParaContainer>
                    <ParaContainer>{summary.orderPerformance.toFixed(2)}</ParaContainer>
                    <ParaContainer>{summary.orderPerformanceRes.toFixed(2)}</ParaContainer>
                    <ParaContainer>{summary.underDue.toFixed(2)}</ParaContainer>
                    <ParaContainer>{summary.ontime.toFixed(2)}</ParaContainer>
                    <ParaContainer>{summary.ontimeRes.toFixed(2)}</ParaContainer>
                    <ParaContainer>{summary.drivethruOnTime.toFixed(2)}</ParaContainer>
                    <ParaContainer>{summary.todayOnTimeRes.toFixed(2)}</ParaContainer>
                    <ParaContainer>{summary.criticalOnTime.toFixed(2)}</ParaContainer>
                    <ParaContainer>{summary.drcallinOneTime.toFixed(2)}</ParaContainer>
                    <ParaContainer>{summary.futureOnTime.toFixed(2)}</ParaContainer>
                    <ParaContainer>{summary.overDueTime}</ParaContainer>
                    <ParaContainer>{summary.underDueTime}</ParaContainer>
                    <ParaContainer>{summary.timeModified}</ParaContainer>
                    {summary.userId.map((n:  { [field: string]: string }, index: number) => (
                        <ParaContainer key={index}>{n.userId}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{n.num}</ParaContainer>
                    ))}
                </Grid>
            </Grid>
            <UnderlinedParaContainer />
        </div>
    )
}
