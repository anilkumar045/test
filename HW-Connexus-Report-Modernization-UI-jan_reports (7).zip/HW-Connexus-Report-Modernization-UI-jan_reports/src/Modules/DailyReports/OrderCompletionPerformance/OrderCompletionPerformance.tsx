/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Feng Lin(vn5101e)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for rendering the Order Completion Performance Report.
 * This component requests data from the API and renders that data in a UI table to be viewed
 * by the user. The initial request is originated in Connexus. The details of the request are
 * received as query parameters via the URL.
 *
 */
import React, { useEffect, useState } from 'react';
import { Grid } from '@material-ui/core';
import Table from '../../Common/Table';
import PrintWrapper from '../../Common/PrintReport';
import ReportWrapper from '../../Common/LoadingErrorWrapper';
import { API_URL, getConfig } from '../../../settings';
import { Summary } from './Summary';
import {
  ReportContainer,
  ParaContainer,
  HeaderContainer,
  UnderlinedParaContainer,
} from '../../../assets/common.styled';
import { useApi, apiStates } from '../../Common/useApi';
import {
  IFooter,
  IData,
  StateType,
  Props,
} from './OrderCompletionPerformance.type';
import { RouteComponentProps } from 'react-router';
/**
 * Order Completion Performance Component
 */
export const OrderCompletionPerformance: React.FC<RouteComponentProps> = (
  props:RouteComponentProps
) => {
  const { location } = props;
  /**
   *  Get and build the URL and parameter for API call
   * @property {list} response Handle a list of data which return from server side
   */

  const [response, setResponse] = useState<IData>({
    appDetails: {
      appName: '',
      reportName: '',
      storeId: 0,
      storeName: '',
      storeAddress: '',
    },
    tableHeader: [],
    reportData: [],
    summary: {
      petientExpect: 0,
      totalorder: 0,
      totalRxs: 0,
      orderRes: 0,
      rxRes: 0,
      firstAvailable: 0,
      sysCal: 0,
      orderPerformance: 0,
      orderPerformanceRes: 0,
      underDue: 0,
      ontime: 0,
      ontimeRes: 0,
      drivethruOnTime: 0,
      todayOnTimeRes: 0,
      criticalOnTime: 0,
      drcallinOneTime: 0,
      futureOnTime: 0,
      overDueTime: 0,
      underDueTime: 0,
      timeModified: 0,
      userId: [],
    },
  });
  const { search } = location;
  const params = new URLSearchParams(search);
  const queryParams: { [key: string]: string } = {};
  Array.from(params.keys()).forEach((key) => {
    queryParams[key] = params.get(key) || '';
  });
  const { showDetail, startDate, reportDate } = queryParams;
  const header = {};

  /**
   * useApi
   * @desc react hook for making Api call
   */
  const { state, error, data }: StateType = useApi(
    'order-completion-performance.json',
    queryParams,
    header,
  );

  /**
   * useEffect
   * @desc created data session in window object and sent it to .net team
   */
  useEffect(() => {
    if (data && state === apiStates.SUCCESS) {
      setResponse(data);
    }
  }, [data, state]);

  /**
   * render
   * @return {ReactElement}  content for this component
   */

  return (
    <ReportWrapper
      loading={state === apiStates.LOADING}
      error={state === apiStates.ERROR ? error : null}
    >
      <ReportContainer>
        <Grid container spacing={3} justify="space-between">
          <Grid item xs>
            <ParaContainer>
              Store # :{response.appDetails.storeId}
            </ParaContainer>
            <ParaContainer>Report Date :{reportDate}</ParaContainer>
            <br />
            <ParaContainer>
              from :{startDate + ' '}
              To:
              {' ' + reportDate}
            </ParaContainer>
          </Grid>
          <Grid item xs>
            <HeaderContainer>
              {response.appDetails.appName}
            </HeaderContainer>
            <HeaderContainer>
              {response.appDetails.storeName}
            </HeaderContainer>
            <HeaderContainer>
              {response.appDetails.reportName}
            </HeaderContainer>
          </Grid>
          <Grid item xs>
            <ParaContainer>{reportDate}</ParaContainer>
            <ParaContainer>
              {response.appDetails.storeAddress}
            </ParaContainer>
          </Grid>
        </Grid>
        {showDetail === 'true' ? (
          <Table
            data={response.reportData}
            header={response.tableHeader}
          />
        ) : (
          <UnderlinedParaContainer />
        )}
        <Summary data={response.summary} />
      </ReportContainer>
    </ReportWrapper>
  );
};
export default PrintWrapper(OrderCompletionPerformance);
