export type IFooter ={
    petientExpect: number,
    totalorder: number,
    totalRxs: number,
    orderRes: number,
    rxRes: number,
    firstAvailable: number,
    sysCal: number,
    orderPerformance: number,
    orderPerformanceRes: number,
    underDue: number,
    ontime: number,
    ontimeRes: number,
    drivethruOnTime: number,
    todayOnTimeRes: number,
    criticalOnTime: number,
    drcallinOneTime: number,
    futureOnTime: number,
    overDueTime: number,
    underDueTime: number,
    timeModified: number,
    userId: { [field: string]: string }[];
  }
  export type IData = {
    appDetails:{
    appName: string;
    reportName: string;
    storeId: number
    storeName: string;
    storeAddress: string;
    }
    tableHeader: { [key: string]: string }[];
    reportData: { [key: string]: string | number | boolean }[];
    summary: IFooter;
  };
  
  export type StateType = {
    state: string;
    error: string;
    data: IData;
  };
  export type Props = {
    location: Location;
  };

  export type SummaryProps = {
    data: IFooter
};