import React, { useState, useEffect } from 'react';
import { Grid } from '@material-ui/core';
import moment from 'moment';
import Table from '../Common/Table';
import PrintReport from '../Common/PrintReport';
import { API_URL, getConfig } from '../../settings';
import { getApi } from '../Common/AxiosCall';
import Loader from '../Common/Loader';
import Error from '../Common/ErrorMessage';
import { RouteComponentProps } from 'react-router';

/**
 * Pharmacist Activity report
 */

interface PharmacistActivityProps {
  location: { search: string; pathname: string };
}

interface PharmacistActivityData {
  storeId: string;
  date: string;
  appName: string;
  store: string;
  reportName: string;
  details: string;
  header: { [field: string]: string }[];
  data: { [field: string]: string }[];
}

export const PharmacistActivity: React.FC<RouteComponentProps> = (
  props,
) => {
  const [
    activityData,
    updateData,
  ] = useState<PharmacistActivityData | null>(null);
  const [loading, updateLoading] = useState<boolean>(true);
  const [error, updateError] = useState<null | string>(null);

  const { location } = props;
  const { search, pathname = '' } = location;
  const params = new URLSearchParams(search);
  const activityDate = params.get('activityDate');
  const userName = params.get('userName');
  const key = pathname.substr(1);
  const apiHeader = {};
  const URL = API_URL + getConfig(key);
  const storeId = params.get('storeId');

  useEffect(() => {
    getApi(
      URL,
      { activityDate, userName },
      apiHeader,
      (res) => {
        updateData(res.data);
        updateLoading(false);
        updateError(null);
      },
      (err) => {
        updateData(null);
        updateLoading(false);
        updateError(err);
      },
    );
  }, []);

  if (loading) {
    return <Loader />;
  }
  if (error) {
    return <Error error={error} />;
  }
  let tableOne: { [field: string]: string }[] = [];
  let tableTwo: { [field: string]: string }[] = [];
  if (
    activityData &&
    activityData.data &&
    activityData.data.length > 0
  ) {
    activityData.data.forEach(
      (datum: { [label: string]: string }, index: number) => {
        if (index % 2 === 0) {
          tableOne = [...tableOne, datum];
        } else {
          tableTwo = [...tableTwo, datum];
        }
      },
    );
  }
  if (activityData) {
    return (
      <div className="report-container">
        <Grid container spacing={1}>
          <Grid item xs={4}>
            <p className="para">{`Store # : ${storeId}`}</p>
            <p className="para">{`Report Date : ${moment().format(
              'MM/DD/YYYY',
            )}`}</p>
          </Grid>
          <Grid item xs={4}>
            <h5 className="pharma-header">{activityData.appName}</h5>
            <h5 className="pharma-header">{activityData.store}</h5>
            <h5 className="pharma-header">
              {activityData.reportName}
            </h5>
          </Grid>
          <Grid item xs={4}>
            <p className="para">{activityData.details}</p>
          </Grid>
        </Grid>
        <div className="report-params">
          <h5 className="para">{`Activity Date # : ${moment(
            activityDate,
            'MM-DD-YYYY',
          ).format('MM/DD/YYYY')}`}</h5>
          <h5 className="para">{`Pharmacist : ${userName}`}</h5>
        </div>
        <Grid container>
          <Grid item xs={6}>
            <Table data={tableOne} header={activityData.header} />
          </Grid>
          <Grid item xs={6}>
            <Table data={tableTwo} header={activityData.header} />
          </Grid>
        </Grid>
        <Grid container spacing={1}>
          <Grid item xs={6}>
            <p className="signature-label">Signature : </p>
            <p className="signature-value" />
          </Grid>
        </Grid>
        <Grid container spacing={1}>
          <Grid item xs={6}>
            <p className="signature-label">Date :</p>
          </Grid>
        </Grid>
      </div>
    );
  }
  return null;
};

export default PrintReport(PharmacistActivity);
