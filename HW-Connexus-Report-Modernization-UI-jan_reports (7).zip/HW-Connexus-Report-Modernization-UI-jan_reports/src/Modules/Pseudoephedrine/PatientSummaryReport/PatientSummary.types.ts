// import {
//   ResponseData,
// } from '../../Common/StateAndResponseTypes';

export interface Props {
  location: {[key: string]: string};
  search: string;
  pathname: string;
}

export interface AppDetails {
  appName: string;
  storeName: string;
  reportName: string;
  reportLayout: string;
  storeId: number;
  storeAddress: string;
  [field: string]: string | number;
}

export interface HeaderLabels {
  label1: string;
  label2: string;
  label3: string;
  firstId: string;
  secondId: string;
  thirdId: string;
  headerId: number;
  [field: string]: string | number;
}

export interface ReportData {
  soldDate: string;
  transId: number;
  patientName: string;
  patientAddress: string;
  patientDob: string;
  drug: string;
  qtyPkg: string;
  gram: string;
  packSize: string;
  patientId1: string;
  patientId2: string;
  state: string;
  country: string;
  associateName: string;
  intials: string;
  dataRowId: number;
  [field: string]: string | boolean | number;
}

export interface ResponseData {
  appDetails: AppDetails;
  tableHeader: {
    allPatientsHeader: HeaderLabels[];
    patientHeader: HeaderLabels[];
  };
  reportData: ReportData[];
  patientTableBodyData: ReportData[];
  [field: string]: string | number | {} | [] | null;
}

export interface StateType {
  state: string;
  error: string;
  data: ResponseData;
}
