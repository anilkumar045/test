/** ********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Naga Krishna Koyya(vn50zub)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for rendering the Patient Summary Table
 * Report. This component take data from the parent component and renders that data in a UI table
 * to be viewed by the user.
 *
 */

import React from 'react';
import { TableRow } from '@material-ui/core';
import {
  StyledTable,
  StyledTableHead,
  StyledTableHeaderRow,
  StyledTableHeaderCell,
  StyledTableBodyCell,
  StyledEmptyTableRow,
  StyledEmptyTableCell,
  StyledTableBody,
} from './PatientSummary.styled';
import {
  HeaderLabels,
  ReportData,

} from './PatientSummary.types';

interface TableProps {
  tableBodyData: ReportData[];
  tableHeaderData: HeaderLabels[];
}

/**
 * PatientSummaryTable Component
 */
const PatientSummaryTable: React.FC<TableProps> = ({
  tableBodyData,
  tableHeaderData,
}: TableProps) => (
  <StyledTable aria-labelledby="tableTitle">
    <StyledTableHead>
      <StyledTableHeaderRow>
        {tableHeaderData && (
          tableHeaderData.map((row: HeaderLabels) => (
            <StyledTableHeaderCell key={row.label1}>
              {row.label1}
            </StyledTableHeaderCell>
          )))}
      </StyledTableHeaderRow>
    </StyledTableHead>
    <StyledTableBody>
      {tableBodyData && tableBodyData.length ? (
        tableBodyData.map((item: ReportData) => (
          <TableRow hover tabIndex={-1} key={item.dataRowId}>
            {tableHeaderData.map(
              (row: HeaderLabels) => (
                <StyledTableBodyCell key={row.headerId}>
                  {item[row.firstId]}
                </StyledTableBodyCell>
              ),
            )}
          </TableRow>
        ))
      ) : (
        <StyledEmptyTableRow hover tabIndex={-1}>
          <>
            <StyledEmptyTableCell colSpan={tableHeaderData && tableHeaderData.length === 11 ? 11 : 9}>
              No Records Found
            </StyledEmptyTableCell>
          </>
        </StyledEmptyTableRow>
      )}
    </StyledTableBody>
  </StyledTable>
);

export default PatientSummaryTable;
