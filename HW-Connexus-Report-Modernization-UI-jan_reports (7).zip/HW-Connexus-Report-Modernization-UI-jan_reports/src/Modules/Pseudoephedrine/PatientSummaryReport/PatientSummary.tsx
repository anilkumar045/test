/** ********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Naga Krishna Koyya(vn50zub)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for rendering the Patient Summary Report.
 * This component requests data from the API and renders that data in a UI table to be viewed
 * by the user. The initial request is originated in Connexus. The details of the request are
 * received as query parameters via the URL.
 */

import React, { useEffect, useState } from 'react';
import { Grid } from '@material-ui/core';
import moment from 'moment';
import { useApi, apiStates } from '../../Common/useApi';
import PrintWrapper from '../../Common/PrintReport';
import PatientSummaryTable from './PatientSummaryTable';
import {
  Props,
  HeaderLabels,
  ReportData,
  ResponseData,
  StateType,
} from './PatientSummary.types';
import { HeadingFour } from './PatientSummary.styled';
import {
  ParaContainer,
  ReportContainer,
} from '../../../assets/common.styled';
import { API_URL, getConfig } from '../../../settings';
import { RouteComponentProps } from 'react-router';
import ReportWrapper from '../../Common/LoadingErrorWrapper';

/**
 * PatientSummary Component
 */
export const PatientSummary: React.FC<RouteComponentProps> = ({
  location
}:RouteComponentProps) => {
  /**
   * Get/Build URL and Query Params for API call
   */
  const [response, setResponse] = useState<ResponseData | null>(null);
  const { search, pathname } = location;
  const params = new URLSearchParams(search);
  const queryParams: { [key: string]: string } = {};
  Array.from(params.keys()).forEach((key) => {
    queryParams[key] = params.get(key) || '';
  });
  const { storeId, fromDate, toDate, patientId } = queryParams;
  const key = pathname.substr(1);
  const header = {};
  const URL = 'patient-summary.json' || API_URL + getConfig(key);

  /**
   * useApi
   * @desc react hook for making Api call
   */
  const { state, error, data }: StateType = useApi(
    URL,
    queryParams,
    header,
  );

  /**
   * allPatientsTableHeadersFormat
   * @desc to formating table header data for All patients
   */
  const allPatientsTableHeaderFormat = (
    headersData: HeaderLabels[],
  ) => {
    headersData.map((item: HeaderLabels) => {
      let packQtyLabels = '';
      let associateNameAndIntialsLabels = '';
      let stateAndCountryLabels = '';
      switch (item.firstId) {
        case 'qtyPkg':
          packQtyLabels += item.label1;
          packQtyLabels += ' / ';
          packQtyLabels += item.label2;
          packQtyLabels += '\n';
          packQtyLabels += item.label3;
          item.label1 = packQtyLabels;
          return item.label1;
        case 'associateName':
          associateNameAndIntialsLabels += item.label1;
          associateNameAndIntialsLabels += ' / ';
          associateNameAndIntialsLabels += item.label2;
          item.label1 = associateNameAndIntialsLabels;
          return item.label1;
        case 'state':
          stateAndCountryLabels += item.label1;
          stateAndCountryLabels += '\n';
          stateAndCountryLabels += item.label2;
          item.label1 = stateAndCountryLabels;
          return item.label1;
        default:
          return item.label1;
      }
    });
  };

  /**
   * allPatientsTableBodyDataFormat
   * @desc to formating table body data for All patients
   */
  const allPatientsTableBodyDataFormat = (
    tableBodyData: ReportData[],
  ) => {
    tableBodyData.map((ele: ReportData) => {
      let patientData = '';
      patientData += ele.patientName;
      patientData += '\n';
      patientData += ele.patientAddress;
      patientData += '\n';
      patientData += `DOB : ${ele.patientDob}`;
      ele.patient = patientData;

      let packQtyDetails = '';
      packQtyDetails += ele.qtyPkg;
      packQtyDetails += ' / ';
      packQtyDetails += ele.gram;
      packQtyDetails += '\n';
      packQtyDetails += ele.packSize;
      ele.qtyPkg = packQtyDetails;

      let stateAndCountry = '';
      stateAndCountry += ele.state;
      stateAndCountry += '\n';
      stateAndCountry += ele.country;
      ele.state = stateAndCountry;

      let associatenameAndInitials = '';
      associatenameAndInitials += ele.associateName;
      associatenameAndInitials += ' / ';
      associatenameAndInitials += ele.intials;
      ele.associateName = associatenameAndInitials;
      return tableBodyData;
    });
  };

  /**
   * patientTableHeaderFormat
   * @desc to formating table header data for selected patient
   */
  const patientTableHeaderFormat = (headersData: HeaderLabels[]) => {
    headersData.map((item: HeaderLabels) => {
      let stateAndCountryLabels = '';
      if (item.firstId === 'state') {
        stateAndCountryLabels += item.label1;
        stateAndCountryLabels += '\n';
        stateAndCountryLabels += item.label2;
        item.label1 = stateAndCountryLabels;
        return item.label1;
      }
      return item.label1;
    });
  };

  /**
   * patientsTableBodyDataFormat
   * @desc to formating table body data for selected patient
   */
  const patientTableBodyDataFormat = (
    tableBodyData: ReportData[],
  ) => {
    tableBodyData.map((ele: ReportData) => {
      let stateAndCountry = '';
      stateAndCountry += ele.state;
      stateAndCountry += '\n';
      stateAndCountry += ele.country;
      ele.state = stateAndCountry;
      return tableBodyData;
    });
  };

  /**
   * useEffect
   * @desc created data session in window object and sent it to .net team
   */
  useEffect(() => {
    if (data && state === apiStates.SUCCESS) {
      const allPatientsTableBodyData = data.reportData;
      const patientTableBodyData = data.reportData.filter(
        (item) => item.patientId2 === patientId,
      );
      data.patientTableBodyData = patientTableBodyData;
      const allPatientsTableHeaderData =
        data.tableHeader.allPatientsHeader;
      const patientTableHeaderData = data.tableHeader.patientHeader;
      if (patientId === '0') {
        // All patients table data methods
        allPatientsTableHeaderFormat(allPatientsTableHeaderData);
        allPatientsTableBodyDataFormat(allPatientsTableBodyData);
      } else {
        // One patient table data methods
        patientTableHeaderFormat(patientTableHeaderData);
        patientTableBodyDataFormat(patientTableBodyData);
      }
      setResponse(data);
    }
  }, [data, state, patientId]);

  /**
   * render
   * @return {ReactElement}  content for this component
   */
  return (
    <ReportWrapper
      loading={state === apiStates.LOADING}
      error={state === apiStates.ERROR ? error : null}
    >
      <>
        {response && (
          <ReportContainer>
            <Grid container>
              <Grid item xs={4}>
                <ParaContainer>{`Store # : ${storeId}`}</ParaContainer>
                <ParaContainer>
                  {`Report Date : ${moment().format('MM/DD/YYYY')}`}
                </ParaContainer>
                <br />
              </Grid>
              <Grid item xs={4}>
                <HeadingFour>
                  {response.appDetails.appName}
                </HeadingFour>
                <HeadingFour>
                  {response.appDetails.storeName}
                </HeadingFour>
                <HeadingFour>
                  {response.appDetails.reportName}
                </HeadingFour>
                <HeadingFour>
                  {response.appDetails.reportLayout}
                </HeadingFour>
              </Grid>
              <Grid item xs={4}>
                <ParaContainer>
                  <span>
                    {`From : ${moment(fromDate, 'MM/DD/YYYY').format(
                      'MM/DD/YYYY',
                    )} `}
                  </span>
                  <span>
                    {`To : ${moment(toDate, 'MM/DD/YYYY').format(
                      'MM/DD/YYYY',
                    )}`}
                  </span>
                </ParaContainer>
                <ParaContainer>
                  {response.appDetails.storeAddress}
                </ParaContainer>
              </Grid>
              {response.patientTableBodyData.length ? (
                <Grid item xs={12}>
                  <ParaContainer>
                    <strong>
                      {response.patientTableBodyData[0].patientName}
                    </strong>
                  </ParaContainer>
                  <ParaContainer>{`DOB: ${response.patientTableBodyData[0].patientDob}`}</ParaContainer>
                  <ParaContainer>
                    {`${response.patientTableBodyData[0].patientDob},`}
                  </ParaContainer>
                  <ParaContainer>
                    {response.patientTableBodyData[0].patientAddress}
                  </ParaContainer>
                </Grid>
              ) : null}
            </Grid>
            <br />
            {patientId === '0' ? (
              <PatientSummaryTable
                tableBodyData={response.reportData}
                tableHeaderData={
                  response.tableHeader.allPatientsHeader
                }
              />
            ) : (
              <PatientSummaryTable
                tableBodyData={response.patientTableBodyData}
                tableHeaderData={response.tableHeader.patientHeader}
              />
            )}
          </ReportContainer>
        )}
      </>
    </ReportWrapper>
  );
};

export default PrintWrapper(PatientSummary);
