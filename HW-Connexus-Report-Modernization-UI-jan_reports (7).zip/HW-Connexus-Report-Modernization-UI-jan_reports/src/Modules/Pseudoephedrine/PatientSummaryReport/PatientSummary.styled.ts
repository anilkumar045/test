import styled from 'styled-components';
import {
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
} from '@material-ui/core';

export const HeadingFour = styled.h4`
  margin: 0px;
  text-align: center;
`;

export const StyledTable = styled(Table)`
  margin-top: 3px;
`;

export const StyledTableHead = styled(TableHead)`
  width: 100%;
`;

export const StyledTableHeaderRow = styled(TableRow)`
  border-top: 1px solid black;
  border-bottom: 1px solid black;
`;

export const StyledTableHeaderCell = styled(TableCell)`
  padding: 4px 6px;
  font-size: 11px;
  border-bottom: 0px;
  font-weight: bold;
  color: inherit;
  line-height: 15px;
  vertical-align: initial;
  white-space: break-spaces;
`;

export const StyledTableBody = styled(TableBody)`
  margin-top: 3px;
  border-bottom: 1px solid black;
`;

export const StyledTableBodyCell = styled(TableCell)`
  padding: 4px 6px;
  font-size: 11px;
  border-bottom: 0px;
  vertical-align: initial;
  white-space: break-spaces;
`;

export const StyledEmptyTableRow = styled(TableRow)`
  text-align: center;
  color: red;
`;

export const StyledEmptyTableCell = styled(TableCell)`
  text-align: center;
  color: red;
`;
