import styled from 'styled-components';
import {
  Table,
  TableHead,
  TableCell,
} from '@material-ui/core';

export const HeaderWrapper = styled.div`
  font-weight: bold;
  text-align: center;
  background-color: orange;
`;

export const ReportContainer = styled.div`
  background-color: #fffacd;
  padding: 15px;
  font-size: 11px;
`;

export const ParaContainer = styled.p`
  margin: 0px;
`;

export const PharmaContainer = styled.h5`
  margin: 0px;
`;

export const DividerLine = styled.p`
  border-bottom: 1px solid #000;
  width: 100%;
`;

export const HalfLine = styled.p`
  border-bottom: 1px solid #000;
  width: 70%;
`;

export const FloatWrapper = styled.div`
  float: ${(props) => (props.float ? props.float : '')};
  width: ${(props) => (props.width ? props.width : '0')};
`;

export const TotalWrapper = styled.p`
  font-weight: bold;
  color: blue;
  display: inline-block;
  white-space: pre;
`;

export const InlineWrapper = styled.p`
  display: inline-block;
`;

export const StyledTableHead = styled(TableHead)`
  width: 100%;
  border-top: 1px solid #000;
  border-bottom: 1px solid #000;
`;

export const StyledTable = styled(Table)`
  margin-top: 3px;
`;

export const StyledTableHeaderCell = styled(TableCell)`
  padding: 4px 6px;
  font-size: 11px;
  border-bottom: 0px;
  font-weight: bold;
  color: inherit;
  line-height: 15px;
  vertical-align: initial;
  white-space: break-spaces;
`;

export const StyledTableBodyCell = styled(TableCell)`
  padding: 4px 6px;
  font-size: 11px;
  border-bottom: 0px;
  vertical-align: initial;
  white-space: break-spaces;
`;

export const StyledEmptyTableRow = styled.div`
  text-align: center;
  font-weight: 600;
  color: deeppink;
`;

export const BorderWrapper = styled.span`
  border: 0 0 0 0 ;
`;
