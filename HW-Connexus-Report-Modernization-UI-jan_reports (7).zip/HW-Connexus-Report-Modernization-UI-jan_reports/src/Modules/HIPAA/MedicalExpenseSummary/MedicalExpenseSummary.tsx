/** ********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 3 team, Primary : Bhanu Prakash P V(vn50xcy)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for rendering Medical Expense Summary Report.
 * This component requests data from the API and renders that data in a UI table to be viewed
 * by the user.The initial request is originated in Connexus. The details of the request are
 * received as query parameters via the URL.
 *
 */
import React, { useState, useEffect } from 'react';
import { Grid } from '@material-ui/core';
import moment from 'moment';
import CustomTable from './CustomTable';
import Table from '../../Common/Table';
import PrintWrapper from '../../Common/PrintReport';
import { formHeader } from './MedicalExpenseSummary.helper';
import Loader from '../../Common/Loader';
import ErrorMessage from '../../Common/ErrorMessage';
import { apiStates, useApi } from '../../Common/useApi';
import {
  ReportContainer,
  HeaderWrapper,
  ParaContainer,
  PharmaContainer,
  DividerLine,
  HalfLine,
  TotalWrapper,
  InlineWrapper,
  FloatWrapper,
} from './MedicalExpenseSummary.styled';
import { RouteComponentProps } from 'react-router';

type props = {
  location: { search: string; pathname: string };
};

interface header {
  label1: string;
  label2: string;
  label3: string;
  data1: string;
  data2: string;
  data3: string;
  [key: string]: string;
}

/**
 * MedicalExpenseSummary Component
 */

export const MedicalExpenseSummary: React.FC<RouteComponentProps> = (
  props,
) => {
  const {
    location: { search, pathname },
  } = props;
  const [finalHeader, updateFinalHeader] = useState<header[]>([]);
  const params = new URLSearchParams(search);
  const storeId = params.get('storeId');
  const fromDate = params.get('startFillDate');
  const toDate = params.get('endFillDate');
  const unSoldRx = params.get('dispSoldRecords') || '';
  const reportStyle = params.get('reportStyle');
  const fourthHeader = params.get('header4');
  const seventhHeader = params.get('header7');
  const eighthHeader = params.get('header8');
  const patientName = params.get('patName');
  const patientAddress1 = params.get('patAddress1');
  const patientAddress2 = params.get('patAddress2');
  const patientDob = params.get('patDOB');
  const queryParams = {};
  const header = {};

  /**
   * useApi
   * @desc react hook for making Api call
   */

  const { state, data, error } = useApi(
    'medical-expense-summary.json',
    queryParams,
    header,
  );

  useEffect(() => {
    updateFinalHeader(
      formHeader(fourthHeader, seventhHeader, eighthHeader),
    );
  }, []);

  /**
   * render
   * @return {ReactElement} markup
   */

  switch (state) {
    case apiStates.ERROR:
      return <ErrorMessage error={error} />;
    case apiStates.SUCCESS: {
      return (
        <ReportContainer>
          <Grid container spacing={10}>
            <Grid item xs={5}>
              <ParaContainer>{`Store # : ${storeId}`}</ParaContainer>
              <ParaContainer>
                {`Report Date : ${moment(data.reportDate).format(
                  'MM/DD/YYYY',
                )}`}
              </ParaContainer>
              <br />
            </Grid>
            <Grid item xs={4}>
              <PharmaContainer>{data.appName}</PharmaContainer>
              <PharmaContainer>{data.store}</PharmaContainer>
              <PharmaContainer>{data.reportName}</PharmaContainer>
            </Grid>
          </Grid>
          <DividerLine />
          {unSoldRx.toLowerCase() === 'true' && (
            <div>
              <HeaderWrapper>U N S O L D Rx's</HeaderWrapper>
              <DividerLine />
            </div>
          )}
          <FloatWrapper float="left" width="65px">
            <PharmaContainer>Patient:</PharmaContainer>
          </FloatWrapper>
          <FloatWrapper float="left" width="300px">
            <ParaContainer>{patientName}</ParaContainer>
            <ParaContainer>{patientAddress1}</ParaContainer>
            <ParaContainer>{patientAddress2}</ParaContainer>
          </FloatWrapper>
          <br />
          <br />
          <br />
          <br />
          <FloatWrapper float="left" width="65px">
            <PharmaContainer>Birthdate:</PharmaContainer>
          </FloatWrapper>
          <FloatWrapper float="left" width="150px">
            <ParaContainer>
              {moment(patientDob, 'MM/DD/YYYY').format('MM/DD/YYYY')}
            </ParaContainer>
          </FloatWrapper>
          <br />
          <DividerLine />
          <p>{`Below is a list of your Pharmacy Orders for the date range of:
            ${moment(fromDate, 'MM/DD/YYYY').format(
              'MM/DD/YYYY',
            )} To : ${moment(toDate, 'MM/DD/YYYY').format(
            'MM/DD/YYYY',
          )}`}</p>
          {reportStyle !== '7200' && (
            <div>
              <CustomTable data={data.data} header={finalHeader} />
              <br />
              <Grid container spacing={10}>
                <Grid item xs={4}>
                  <p>{`Report Date : ${moment().format(
                    'MM/DD/YYYY',
                  )}`}</p>
                  <p>Attested To By:</p>
                </Grid>
                <Grid item xs={4}>
                  <br />
                  <br />
                  <HalfLine />
                  <p>Registered Pharmacist</p>
                </Grid>
                <Grid item xs={3}>
                  <div>
                    <InlineWrapper>
                      <h5>Total: </h5>
                    </InlineWrapper>
                    <TotalWrapper>{` $ ${data.total}`}</TotalWrapper>
                  </div>
                </Grid>
              </Grid>
              <DividerLine />
            </div>
          )}
          {reportStyle === '7200' && (
            <Table data={data.secondData} header={data.header} />
          )}
        </ReportContainer>
      );
    }
    default:
      return <Loader />;
  }
};
export default PrintWrapper(MedicalExpenseSummary);
