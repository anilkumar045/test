import React, { ReactElement } from 'react';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import '../../../assets/table.css';
import {
  StyledTable,
  StyledTableHead,
  StyledTableHeaderCell,
  StyledTableBodyCell,
  StyledEmptyTableRow,
} from './MedicalExpenseSummary.styled';

type props = {
  data:
    | {
        [field: string]: any;
      }[]
    | null;
  header: { [label: string]: string }[];
};

const CustomTable: React.FC<props> = ({
  data: patientData,
  header: rows,
}): ReactElement => {
  return (
    <StyledTable aria-labelledby="tableTitle" id="reportTable">
      <StyledTableHead>
        <TableRow>
          {rows.map((row) => (
            <StyledTableHeaderCell key={row.data1}>
              {row.label1}
            </StyledTableHeaderCell>
          ))}
        </TableRow>
        <TableRow>
          {rows.map((row) => (
            <StyledTableHeaderCell key={row.data2}>
              {row.label2}
            </StyledTableHeaderCell>
          ))}
        </TableRow>
        <TableRow>
          {rows.map((row) => (
            <StyledTableHeaderCell key={row.data3}>
              {row.label3}
            </StyledTableHeaderCell>
          ))}
        </TableRow>
      </StyledTableHead>
      <TableBody id="reportTableBody" className="report-table-body">
        {patientData ? (
          patientData.map((n, index) => (
            <TableRow
              id={`reportTableRow${index}`}
              hover
              tabIndex={-1}
              key={n.unique}
            >
              {rows.map((row) => (
                <StyledTableBodyCell key={n.unique + n[row.data1]}>
                  {n[row.data1]} <br />
                  {n[row.data2]} <br />
                  {n[row.data3]}
                </StyledTableBodyCell>
              ))}
            </TableRow>
          ))
        ) : (
          <TableCell colSpan={12}>
            <StyledEmptyTableRow>
              No Records Found
            </StyledEmptyTableRow>
          </TableCell>
        )}
      </TableBody>
    </StyledTable>
  );
};

export default CustomTable;
