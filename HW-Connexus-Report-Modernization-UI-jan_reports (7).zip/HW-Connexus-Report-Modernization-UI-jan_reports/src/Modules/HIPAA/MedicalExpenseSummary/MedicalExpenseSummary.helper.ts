interface header {
  label1: string;
  label2: string;
  label3: string;
  data1: string;
  data2: string;
  data3: string;
  [key: string]: string;
}

const defaultHeader = {
  label1: '',
  label2: '',
  label3: '',
  data1: '',
  data2: '',
  data3: '',
};

export const formHeader4 = (header: string | null) => {
  if (header === '1') {
    return {
      label1: 'Prescriber',
      label2: 'Physician DEA',
      label3: 'Physician NPI',
      data1: 'prescriber',
      data2: 'physicianDea',
      data3: 'physicianNpi',
    };
  }
  if (header === '2') {
    return {
      label1: 'Prescriber',
      label2: 'Physician DEA',
      label3: '',
      data1: 'prescriber',
      data2: 'physicianDea',
      data3: '',
    };
  }
  if (header === '3') {
    return {
      label1: 'Prescriber',
      label2: '',
      label3: '',
      data1: 'prescriber',
      data2: '',
      data3: '',
    };
  }
  return defaultHeader;
};

export const formHeader7 = (header: string | null) => {
  if (header === '1') {
    return {
      label1: 'Dispense As Written',
      label2: 'SIG',
      label3: '',
      data1: 'dispenseAsWritten',
      data2: 'sig',
      data3: '',
    };
  }
  if (header === '2') {
    return {
      label1: 'Dispense',
      label2: 'As Written',
      label3: '',
      data1: 'dispenseAsWritten',
      data2: '',
      data3: '',
    };
  }
  return defaultHeader;
};

export const formHeader8 = (header: string | null) => {
  if (header === '1') {
    return {
      label1: 'Patient Paid',
      label2: 'TP Ref #',
      label3: '',
      data1: 'patientPaid',
      data2: 'tpRefNumber',
      data3: '',
    };
  }
  if (header === '2') {
    return {
      label1: 'Patient Paid',
      label2: 'Cash Price',
      label3: 'TP Ref #',
      data1: 'patientPaid',
      data2: 'cashPrice',
      data3: 'tpRefNumber',
    };
  }
  if (header === '3') {
    return {
      label1: 'Amount Due',
      label2: 'TP Ref #',
      label3: '',
      data1: 'amountDue',
      data2: 'tpRefNumber',
      data3: '',
    };
  }
  if (header === '4') {
    return {
      label1: 'Amount Due',
      label2: 'Cash Price',
      label3: 'TP Ref #',
      data1: 'amountDue',
      data2: 'cashPrice',
      data3: 'tpRefNumber',
    };
  }
  if (header === '5') {
    return {
      label1: 'Patient Paid',
      label2: '',
      label3: '',
      data1: 'patientPaid',
      data2: '',
      data3: '',
    };
  }
  if (header === '6') {
    return {
      label1: 'Patient Paid',
      label2: 'Cash Price',
      label3: '',
      data1: 'patientPaid',
      data2: 'cashPrice',
      data3: '',
    };
  }
  if (header === '7') {
    return {
      label1: 'Amount Due',
      label2: '',
      label3: '',
      data1: 'amountDue',
      data2: '',
      data3: '',
    };
  }
  if (header === '8') {
    return {
      label1: 'Amount Due',
      label2: 'Cash Price',
      label3: '',
      data1: 'amountDue',
      data2: 'cashPrice',
      data3: '',
    };
  }
  return defaultHeader;
};

export const formHeader = (
  header4: string | null,
  header7: string | null,
  header8: string | null,
) => {
  const header = [
    {
      label1: 'Date Filled',
      label2: 'Date Written',
      label3: '',
      data1: 'dateFilled',
      data2: 'dateWritten',
      data3: '',
    },
    {
      label1: 'Rx',
      label2: 'Fill ID',
      label3: '',
      data1: 'rx',
      data2: 'fillId',
      data3: '',
    },
    {
      label1: 'Drug Name',
      label2: 'NDC',
      label3: '',
      data1: 'drugName',
      data2: 'ndc',
      data3: '',
    },
  ];
  const fourthHeader: header = formHeader4(header4);
  header.push(fourthHeader);
  header.push(
    {
      label1: 'Qty',
      label2: 'Refill',
      label3: '#',
      data1: 'quantity',
      data2: 'refill',
      data3: 'number',
    },
    {
      label1: 'Days',
      label2: 'Supply',
      label3: '',
      data1: 'days',
      data2: 'supply',
      data3: '',
    },
  );
  const seventhHeader: header = formHeader7(header7);
  header.push(seventhHeader);
  const eighthHeader: header = formHeader8(header8);
  header.push(eighthHeader);
  return header;
};
