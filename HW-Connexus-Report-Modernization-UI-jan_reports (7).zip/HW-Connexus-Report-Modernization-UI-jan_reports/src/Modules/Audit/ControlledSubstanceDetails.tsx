/** ********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author: ADM Reports Team Primary: Benjamin Worrell
 * Date: 2021/1/6
 * Version: 0.1
 * Description: A report in the Connexus Report Moderinization project
 */
import { Grid } from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import PrintWrapper from '../Common/PrintReport';
import Table from './DetailsTable';
import { getApi } from '../Common/AxiosCalls';
import { AxiosResponse } from 'axios';



interface ResponseData {
  storeId: number;
  reportDate: string;
  appName: string;
  store: string;
  reportName: string;
  dateRange: string;
  header: object[];
  data: object[];
};

interface InitialState {
  data: ResponseData;
  loading: boolean;
  error: Error | string | null;
};
/**
 * ControlledSubstanceDetails Component
 */
export const ControlledSubstanceDetails = () => {
  /**
     * @type Initial State
     * @property  data Input Data
     * @property  loading Loading Flag
     * @property error Error Message
     */
  const initialState: InitialState = {
    data: {
      storeId: NaN,
      reportDate: '',
      appName: '',
      store: '',
      reportName: '',
      dateRange: '',
      header: [],
      data: [],
    },
    loading: true,
    error: null,
  };

  const [state, setState] = useState(initialState);

  /**
   * componentDidMount
   * @desc life cycle method for making Api call
   */
  useEffect(() => {
    getApi(
      'controlled-substance-details.json',
      {},
      {},
      ({data}: AxiosResponse) => {
        setState({
          data,
          loading: false,
          error: null,
        });
      },
      (error: Error) => {
        setState((prevState) => ({
          ...prevState,
          error,
          loading: false,
        }));
      },
    );
  }, []);

  /**
   * render
   * @return {ReactElement} markup
   */
  const { data, loading, error } = state;
  if (loading) {
    return <div>Loading ....</div>;
  }
  if (error) {
    return <div>{`Error: ${error}`}</div>;
  }
  return (
    <div className="report-container">
      <Grid container spacing={10}>
        <Grid item xs={4}>
          <p className="para">{`Store #: ${data.storeId}`}</p>
          <p className="para">{`Report Date: ${data.reportDate}`}</p>
          <p className="para">{`From: ${data.dateRange}`}</p>
        </Grid>
        <Grid item xs={4}>
          <h5 className="pharma-header">{data.appName}</h5>
          <h5 className="pharma-header">{data.store}</h5>
          <h5 className="pharma-header">{data.reportName}</h5>
        </Grid>
      </Grid>
      <Table data={data.data} header={data.header} />
    </div>
  );
};

export default PrintWrapper(ControlledSubstanceDetails);
