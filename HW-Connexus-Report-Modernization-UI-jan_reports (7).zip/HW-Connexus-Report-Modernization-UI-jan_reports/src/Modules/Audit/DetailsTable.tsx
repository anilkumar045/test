/** ********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author: ADM Reports Team Primary: Benjamin Worrell (vn50vbv)
 * Date: 2021/1/6
 * Version: 0.1
 * Description: A custom table used to render the data for Controlled Substance Details Report 
 */

import React from 'react';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import '../../assets/table.css';

const CustomTable = (
  {data: patientData, header: rows, footer, bodyClassName}: any) => (
  <Table aria-labelledby="tableTitle" id="reportTable" className="report-table">
    <TableHead style={{ width: '100%' }}>
      <TableRow className="table-header-row">
        {rows.map(
          (row: any) => (
            <TableCell
              className="table-header-cell"
              style={{ lineHeight: '24px' }}
              key={row.id}
            >
              {row.label}
            </TableCell>
          )
        )}
      </TableRow>
    </TableHead>
    <TableBody id="reportTableBody" className={bodyClassName}>
      {patientData.length ? (
        patientData.map((n: any, index: any) => (
          <TableRow
            id={`reportTableRow${index}`}
            hover
            tabIndex={-1}
            key={n.unique}
          >
            {rows.map(
              (row: any) => {
                if (row.id !== 'patientName' && row.id !== 'prescriberName') {
                  return <TableCell key={n.unique + n[row.id]} className='input-table-body-cell'>{n[row.id]}</TableCell>;
                }

                if (row.id === 'patientName') {
                  let patientInfo = '';
                  rows.forEach((element: any) => {
                    if (element.id === 'patientName') {
                      patientInfo += `${n[element.id]} - ${n.patientAddress}`;
                    }
                  });
                  return <TableCell key={n.unique + n[row.id]} className='input-table-body-cell'>{patientInfo}</TableCell>;
                }

                let prescriberInfo = '';
                rows.forEach((element: any) => {
                  if (element.id === 'prescriberName') {
                    prescriberInfo += `${n[element.id]} - ${n.prescriberAddress} - ${n.DEA}`;
                  }
                });
                return <TableCell key={n.unique + n[row.id]} className='input-table-body-cell'>{prescriberInfo}</TableCell>;
              }
            )}
          </TableRow>

        ))
      ) : (
        <TableRow
          hover
          tabIndex={-1}
          className="empty-table-row"
        >
          <>
            <TableCell colSpan={12} className="empty-table-body">
              No Records Found
            </TableCell>
          </>
        </TableRow>
      )}
    </TableBody>
    {footer}
  </Table>
);

CustomTable.defaultProps = {
  footer: null,
  bodyClassName: 'report-table-body',
};

export default CustomTable;