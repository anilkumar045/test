import {
  ResponseData,
} from '../../Common/StateAndResponseTypes';

export interface IRxModificationLogInitialState {
  data: ResponseData<IRxModificationLogPatientData, IHeaderObject>;
  fromDate: string;
  toDate: string;
  loading: boolean,
  error: Error | string | null,
}

export interface IHeaderObject {
  id: string;
  label: string;
  [field: string]: string;
}

export interface IRxModificationLogPatientData {
  rxNbr: number;
  unique: number;
  userId: string;
  rxModification: string;
  modifiedTime: string;
  [field: string]: string | number;
}

export interface IRxModificationLogTableProps {
  patientData: IRxModificationLogPatientData[];
  rows: IHeaderObject[];
}
