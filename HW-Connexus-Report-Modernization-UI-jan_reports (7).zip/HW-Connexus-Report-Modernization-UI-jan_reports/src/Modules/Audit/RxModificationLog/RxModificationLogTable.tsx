/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Nick Steen (vn50vbw)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for rendering the RxModificationLog Report Table.
 *
 * This component visually formats the JSON repsonse from the RxModificationLog component into a table.
 *
 */

import React from 'react';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import './RxModificationLogTableStyle.css';
import { IRxModificationLogTableProps } from './RxModificationLog.types';

const RxModificationLogReportTable: React.FC<IRxModificationLogTableProps> = ({
  patientData,
  rows,
}) => {
  //export default class RxModificationLogReportTable extends React.Component {
  // const { data: patientData, header: rows, footer, bodyClassName } = this.props;
  return (
    <Table
      aria-labelledby="tableTitle"
      id="reportTableRxMod"
      className="report-table"
    >
      <TableHead className="rxModifciationLogTable-header">
        <TableRow className="table-header-row-rxModificationReport">
          {rows.map((row) => (
            <TableCell
              className="table-header-cell-rxModificationReport"
              key={row.id}
            >
              {row.label}
            </TableCell>
          ))}
        </TableRow>
      </TableHead>
      <TableBody id="reportTableBody">
        {patientData.length > 0 ? (
          patientData.map((n, index: any) => (
            <TableRow
              id={`reportTableRow${index}`}
              className="report-table-body-row-rxModification"
              hover
              tabIndex={-1}
              key={n.unique}
            >
              {rows.map((row, index: number) =>
                rows.length - 2 == index ? (
                  <TableCell
                    key={n.unique}
                    className="report-table-body-cell-rxModificationReport"
                    id="rxModificationCell"
                  >
                    {n[row.id]}
                  </TableCell>
                ) : (
                  <TableCell
                    key={n.unique}
                    className="report-table-body-cell-rxModificationReport"
                  >
                    {n[row.id]}
                  </TableCell>
                ),
              )}
            </TableRow>
          ))
        ) : (
          <TableRow hover tabIndex={-1} className="empty-table-row">
            <TableCell colSpan={12} className="empty-table-body">
              No Records Found
            </TableCell>
          </TableRow>
        )}
      </TableBody>
    </Table>
  );
};

export default RxModificationLogReportTable;
