/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Nick Steen (vn50vbw)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for rendering the RxModificationLog Report.
 *
 * This component requests data from the API and renders that data in a UI table to be viewed
 * by the user. The initial request is originated in Connexus. The details of the request are
 * received as query parameters via the URL.
 *
 */

import { Grid } from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import PrintWrapper from '../../Common/PrintReport';
import { API_URL, getConfig } from '../../../settings';
import { getApi } from '../../Common/AxiosCalls';
import RxModificaitonLogReportTable from './RxModificationLogTable';
import { AxiosResponse } from 'axios';
import { RouteComponentProps } from 'react-router';
import { IRxModificationLogInitialState } from './RxModificationLog.types';
import ErrorMessage from '../../Common/ErrorMessage';
import Loader from '../../Common/Loader';
import { apiStates, useApi } from '../../Common/useApi';
import ReportWrapper from '../../Common/LoadingErrorWrapper';

interface IRxModificationLogPatientData {
  rxNbr: number;
  unique: number;
  userId: string;
  rxModification: string;
  modifiedTime: string;
  [field: string]: string | number;
}

interface IRxModificiationLogHeaderObject {
  id: string;
  label: string;
  [field: string]: string;
}

interface ResponseData {
  storeId: number;
  date: string;
  appName: string;
  store: string;
  reportName: string;
  fromDate: string;
  toDate: string;
  header: IRxModificiationLogHeaderObject[];
  data: IRxModificationLogPatientData[];
}
type stateType = { state: string; error: string; data: ResponseData };

/*
 *
 * WaitForDrugOrder Component
 */
export const RxModificationLogReport: React.FC<RouteComponentProps> = (
  props,
) => {
  const initialData: ResponseData = {
    storeId: NaN,
    date: '',
    appName: '',
    store: '',
    reportName: '',
    fromDate: '',
    toDate: '',
    header: [],
    data: [],
  };
  const { location } = props;
  // Get/Build URL and Query Params for API call
  const { search, pathname = '' } = location;
  const params = new URLSearchParams(search);
  const queryParams: { [key: string]: string } = {};
  Array.from(params.keys()).forEach((key) => {
    queryParams[key] = params.get(key) || '';
  });
  //const { fromDate, toDate } = queryParams;
  const key = pathname.substr(1);
  const header = {};
  const URL = API_URL + getConfig(key);

  const { state, error, data: responseData }: stateType = useApi(
    'rx-modification-log.json',
    {},
    header,
  );

  const data = responseData || initialData;
  console.log(data);
  return (
    <ReportWrapper
      loading={state === apiStates.LOADING}
      error={state === apiStates.ERROR ? error : null}
    >
      <div className="report-container">
        <Grid container spacing={10}>
          <Grid item xs={4}>
            <p>Store # : {data.storeId} </p>
            <p>Report Date : {data.date} </p>
            <p>
              {'From : '}
              {data.fromDate}
              {' To : '}
              {data.toDate}
            </p>
          </Grid>
          <Grid item xs={4}>
            <h5>{data.appName}</h5>
            <h5>{data.store}</h5>
            <h5>{data.reportName}</h5>
          </Grid>
        </Grid>
        <RxModificaitonLogReportTable
          patientData={data.data}
          rows={data.header}
        />
      </div>
    </ReportWrapper>
  );
};
export default PrintWrapper(RxModificationLogReport);
