import styled from 'styled-components';
import { Grid, TableCell } from '@material-ui/core';

export const StyledTempUserFooterCell = styled(TableCell)`
  color: black;
  text-align: left;
  padding: 0;
  font-weight: bold;
  border-bottom: none;
`;

export const StyledGrideHeaderContainer = styled(Grid)`
  text-align: center;
`;

export const DateContainer = styled.p`
  margin: 10px 0 0 0;
`;
