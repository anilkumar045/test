/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Edward Robinson(vn50zua)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for rendering the Temp User Report.
 * This component requests data from the API via the useApi hookand renders that data in a UI
 * table to be viewed by the user. The initial request is originated in Connexus. The details
 * of the request are received as query parameters via the URL.
 *
 */

import { Grid, TableFooter, TableRow } from '@material-ui/core';
import moment from 'moment';
import React, { FC } from 'react';
import { RouteComponentProps } from 'react-router';
import { API_URL, getConfig } from '../../../settings';
import ReportWrapper from '../../Common/LoadingErrorWrapper';
import PrintWrapper from '../../Common/PrintReport';
import Table from '../../Common/Table';
import { apiStates, useApi } from '../../Common/useApi';
import {
  HeaderContainer,
  ParaContainer,
  ReportContainer,
} from './../../../assets/common.styled';
import {
  DateContainer,
  StyledGrideHeaderContainer,
  StyledTempUserFooterCell,
} from './TempUser.styled';
import {
  TempUserResponseAndError,
  TempUserResponseData,
  UserObject,
} from './TempUser.types';

/**
 * @description calculates total users and binds data to footer
 * @returns Table Footer w/ data
 */
const renderFooter = (reportData: UserObject[]) => {
  const totalUsersCreated = reportData.length;
  return (
    <TableFooter>
      <TableRow>
        <StyledTempUserFooterCell>
          <p>{`Total Temp Users Created : ${totalUsersCreated}`}</p>
        </StyledTempUserFooterCell>
      </TableRow>
    </TableFooter>
  );
};

/**
 * TempUser Component
 */
export const TempUser: FC<RouteComponentProps> = (props) => {
  /**
   * @type Initial State
   * @property data Input Data
   * @property loading Loading Flag
   * @property error Error Message
   */
  const initialData: TempUserResponseData = {
    appDetails: {
      storeId: 0,
      appName: '',
      storeName: '',
      storeAddress: '',
      reportName: '',
    },
    tableHeader: [],
    reportData: [],
  };

  // Get/Build URL and Query Params for API call
  const { location } = props;
  const { search, pathname = '' } = location;
  const params = new URLSearchParams(search);
  const queryParams: { [key: string]: string } = {};
  Array.from(params.keys()).forEach((key) => {
    queryParams[key] = params.get(key) || '';
  });
  const { fromDate, toDate } = queryParams;
  const key = pathname.substr(1);
  const header = {};
  const URL = 'temp-user.json' || API_URL + getConfig(key);

  const {
    state,
    error,
    data: responseData,
  }: TempUserResponseAndError = useApi(URL, queryParams, header);

  const data = responseData || initialData;
  const { appDetails, tableHeader, reportData } = data;

  /**
   * @return {ReactElement} markup
   */

  return (
    <ReportWrapper
      loading={state === apiStates.LOADING}
      error={state === apiStates.ERROR ? error : null}
    >
      <ReportContainer>
        <Grid container spacing={10}>
          <Grid item xs={2}>
            <ParaContainer>{`Store #: ${appDetails.storeId}`}</ParaContainer>
            <ParaContainer>{`Report Date: ${moment().format(
              'MM/DD/YYYY',
            )}`}</ParaContainer>

            <DateContainer>
              {` 
              From : ${moment(fromDate, 'MM/DD/YYYY').format(
                'MM/DD/YYYY',
              )} 
              To : ${moment(toDate, 'MM/DD/YYYY').format(
                'MM/DD/YYYY',
              )}`}
            </DateContainer>
          </Grid>
          <StyledGrideHeaderContainer item xs={7}>
            <HeaderContainer>{appDetails.appName}</HeaderContainer>
            <HeaderContainer>{appDetails.storeName}</HeaderContainer>
            <HeaderContainer data-testid="report-name">{appDetails.reportName}</HeaderContainer>
          </StyledGrideHeaderContainer>
          <StyledGrideHeaderContainer item xs={3}>
            <HeaderContainer>
              {appDetails.storeAddress}
            </HeaderContainer>
          </StyledGrideHeaderContainer>
        </Grid>
        <Table
          data={reportData}
          header={tableHeader}
          footer={renderFooter(reportData)}
        />
      </ReportContainer>
    </ReportWrapper>
  );
};

export default PrintWrapper(TempUser);
