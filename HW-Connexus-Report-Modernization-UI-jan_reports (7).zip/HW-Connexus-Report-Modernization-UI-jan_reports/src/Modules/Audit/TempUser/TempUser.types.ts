import {
  ResponseData,
  UseApiHookState,
} from '../../Common/StateAndResponseTypes';

export interface HeaderObject {
  id: string;
  label: string;
  [key: string]: string;
}

export interface UserObject {
  unique: number;
  userId: string;
  userDescription: string;
  role: string;
  createTS: string;
  createUser: string;
  result: string;
  [key: string]: string | boolean | number;
}

export interface TempUserResponseData
  extends ResponseData<UserObject, HeaderObject> {
  reportData: UserObject[];
  tableHeader: HeaderObject[];
}

export interface TempUserResponseAndError
  extends UseApiHookState<TempUserResponseData> {
  data: TempUserResponseData | null;
}
