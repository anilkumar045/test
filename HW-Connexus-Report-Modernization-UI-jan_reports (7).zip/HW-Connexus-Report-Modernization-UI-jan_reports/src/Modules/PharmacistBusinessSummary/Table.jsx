import React, { Component } from 'react';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import '../../assets/table.css';
import './PharmacistBusinessSummary.css';

export default class CustomTable extends Component {

  render() {
    const { id: summary, data: values, header: rows } = this.props;
    let typeDivs = [], totalLen = 0, prevType, flag;
    if (!!rows[0] && rows[0].hasOwnProperty('type')) {
      rows.forEach(head => {
        totalLen++;
        const key = typeDivs.find(type => type.value === head.type);
        if (key) {
          typeDivs[typeDivs.indexOf(key)]['len']++;
        } else {
          typeDivs.push({ value: head.type, len: 1 });
        }
      });
    }
    if (summary === 'userProductivity') {
      values.sort((a, b) => a.type.localeCompare(b.type));
      prevType = '';
      flag = false;
    }
    return (
      <React.Fragment>
        {!!typeDivs.length &&
          <Table>
            <TableBody>
              <TableRow style={{ width: '100%' }}>
                {typeDivs.map((type, index) => (
                  <TableCell style={{ width: type.len / totalLen * 100 + "%", fontWeight: "bold" }} key={index}>
                    {!!type.value ?
                      <span style={{ display: "flex" }}>
                        &lt;<span className="Column-Group">{type.value}</span>&gt;
                    </span>
                      : ""}
                  </TableCell>
                ))}
              </TableRow>
            </TableBody>
          </Table>
        }
        <Table aria-labelledby="tableTitle" id="reportTable" style={{ tableLayout: 'fixed' }}>
          <TableHead style={{ width: '100%' }}>
            <TableRow className="table-header-row" style={{lineHeight:'24px'}}>
              {rows.map(
                (row, i) => (
                  <TableCell
                    className="table-header-cell"
                    key={row.id}
                    style={{ lineHeight:'24px', textAlign: i === 0 && row.id !== 'totConnectTrans' ? "left" : "center" }}
                  >
                    {row.label}
                  </TableCell>
                ),
                this,
              )}
            </TableRow>
          </TableHead>
          <TableBody id="reportTableBody">
            {values.map((n, index) => {
              if (summary === 'userProductivity') {
                flag = false;
                if (n['type'] !== prevType) {
                  prevType = n['type'];
                  flag = true;
                }
              }
              return (
                <React.Fragment key={index}>
                  {summary === 'userProductivity' &&
                    flag &&
                    <TableRow
                      id={`reportTableRowH` + index}
                      hover
                      tabIndex={-1}
                      key={'rowH' + index}
                    >
                      <TableCell style={{
                        padding: '4px 6px 4px 0px', fontSize: "11px", borderBottom: "0px",
                        fontWeight: "bold", textDecoration: "underline"
                      }}>{n['type']}</TableCell>
                    </TableRow>}
                  <TableRow
                    id={`reportTableRow` + index}
                    hover
                    tabIndex={-1}
                    key={'row' + index}
                  >
                    {rows.map(
                      (row, i) => (
                        <TableCell key={i} style={{
                          padding: '4px 6px 4px 6px', fontSize: "11px", borderBottom: "0px",
                          textAlign: i === 0 && summary !== 'onlinePharmacy' ? "left" : "center",
                          fontWeight: i === 0 && summary !== 'onlinePharmacy' && summary !== 'userProductivity' ? "bold" : "normal"
                        }}>
                          {n[row.id] ? n[row.id] : '-'}</TableCell>
                      ),
                      this,
                    )}
                  </TableRow>
                </React.Fragment>
              )
            }
            )
            }
          </TableBody>
        </Table>
        {!values.length &&
          <p style={{
            padding: '6px 0px', fontSize: "11px", color: "#fe00cb", width: "100%",
            textAlign: "center"
          }}>No Records Found</p>}
      </React.Fragment>
    )
  }
}
