import React, { useEffect } from 'react';
import { getApi, postApi } from '../../Common/AxiosCall';
import { apiStates } from '../../Common/useApi';
import {
  API_URL,
  getConfig,
  getReportDetails,
} from '../../../settings';

/**
 * AmberVialInventory functional Component
 */
declare global {
  interface Window {
    getData: string;
    error: string | null;
    apiStatus: number;
    updateData: Function;
  }
}

interface AmberVialInventoryProps {
  location: { search: string; pathname: string };
}

export const AmberVialInventory: React.FC<AmberVialInventoryProps> = (
  props: AmberVialInventoryProps,
) => {
  const { location } = props;
  const { search, pathname = '' } = location;
  const params = new URLSearchParams(search);
  const key = pathname.substr(1);
  const apiHeader = {};
  const URL = API_URL + getConfig(key);
  const fromDate = params.get('fromDate');
  const toDate = params.get('toDate');
  const storeId = params.get('storeId');
  const reportOption = params.get('reportOption');
  const fromVialId = params.get('fromVialId');
  const toVialId = params.get('toVialId');
  const queryParams = {
    fromDate,
    toDate,
    storeId,
    reportOption,
    fromVialId,
    toVialId,
  };
  const hasUpdate = getReportDetails(key);
  const getData = () => {
    getApi(
      // URL,
      'amber-vial-active-inventory.json',
      queryParams,
      apiHeader,
      ({ data }) => {
        setapiStatus(apiStates.SUCCESS, data);
      },
      (err) => {
        setapiStatus(apiStates.ERROR, err);
      },
    );
  };
  const updateData = (params: object[]) => {
    setapiStatus(apiStates.LOADING);
    //param changes
    //queryParams change as per required items
    postApi(
      URL,
      params,
      queryParams,
      () => {
        getData();
      },
      (err) => {
        setapiStatus(apiStates.ERROR, err);
      },
    );
  };
  if (hasUpdate) {
    window.updateData = updateData;
  }
  /**
   * useEffect
   * @desc useEffect is a react hook for implementing life cycle methods in functional based components
   */
  useEffect(() => {
    setapiStatus(apiStates.LOADING);
    getData();
  }, []);

  /**
   * @return {ReactElement} markup
   */
  return <div />;
};
const setapiStatus = (action: string, state?: string) => {
  switch (action) {
    case apiStates.LOADING:
      window.apiStatus = 0;
      break;
    case apiStates.SUCCESS:
      window.apiStatus = 1;
      window.getData = JSON.stringify(state);
      window.error = null;
      break;
    case apiStates.ERROR:
      window.apiStatus = 2;
      window.error = JSON.stringify(state);
      break;
  }
};

export default AmberVialInventory;
