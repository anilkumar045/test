import styled from 'styled-components';

export const HeadingFive = styled.h5`
  margin: 0px;
  text-align: center
`;
