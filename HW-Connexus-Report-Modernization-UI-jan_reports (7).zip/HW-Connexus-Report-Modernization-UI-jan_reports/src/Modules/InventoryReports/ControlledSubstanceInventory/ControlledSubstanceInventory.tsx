/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 2 team, Primary : Sanjay Dhanabalan(vn50xcx)
 * Date: 2021/01/08
 * Version: 0.1
 * Description: This Functional Component is responsible for rendering the Order Completion Performance Report.
 * This component requests data from the API and renders that data in a UI table to be viewed
 * by the user. The initial request is originated in Connexus. The details of the request are
 * received as query parameters via the URL.
 *
 */
import React, { FC } from 'react';
import { Grid } from '@material-ui/core';
import PrintWrapper from '../../Common/PrintReport';
import Table from '../../Common/Table';
import { API_URL, getConfig } from '../../../settings';
import { HeadingFive } from './ControlledSubstanceInventory.styled';
import Loader from '../../Common/Loader';
import ErrorMessage from '../../Common/ErrorMessage';
import { apiStates, useApi } from '../../Common/useApi';
import { RouteComponentProps } from 'react-router';

declare global {
  interface Window {
    getData: string;
  }
}

interface props {
  location: {
    search: string;
    pathname: string;
  };
}

interface header {
  label: string;
  id: string;
  [key: string]: string;
}

interface data {
  drugName: string;
  ndc: string;
  dosageForm: string;
  controlSchedule: string;
  packSize: string;
  noOfFullStockBottle: string;
  qtyInPartialStockBottle1: string;
  qtyInPartialStockBottle2: string;
  qtyInPartialStockBottle3: string;
  qtyInPartialStockBottle4: string;
  totalOnHand: string;
  [key: string]: string;
}

/**
 * Controlled Substance Inventory Report
 */
export const ControlledSubstanceInventory: FC<RouteComponentProps> = (
  props,
) => {
  const { location } = props;
  const { search, pathname = '' } = location;
  const params = new URLSearchParams(search);
  const queryParams: { [key: string]: string } = {};
  Array.from(params.keys()).forEach((key) => {
    queryParams[key] = params.get(key) || '';
  });
  const header = {};
  const key = pathname.substr(1);
  const URL = API_URL + getConfig(key);

  const { state, data, error } = useApi(URL, queryParams, header);

  switch (state) {
    case apiStates.ERROR:
      return <ErrorMessage error={error} />;
    case apiStates.SUCCESS: {
      let tableData = data.data;
      tableData = tableData.map((d: data) => {
        const drugDetails = [d.drugName, d.ndc].join('\n');
        return {
          ...d,
          drugDetails: drugDetails,
        };
      });
      return (
        <div className="report-container">
          <Grid container spacing={10}>
            <Grid item xs={4}>
              <p className="para">Store # :{queryParams.storeId}</p>
              <p className="para">
                Report Date :{new Date().toLocaleDateString('en-US')}
              </p>
            </Grid>
            <Grid item xs={4}>
              <HeadingFive>{data.appName}</HeadingFive>
              <HeadingFive>{data.store}</HeadingFive>
              <HeadingFive>{data.reportName}</HeadingFive>
            </Grid>
          </Grid>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <Table data={tableData} header={data.header} />
            </Grid>
          </Grid>
        </div>
      );
    }
    default:
      return <Loader />;
  }
};

export default PrintWrapper(ControlledSubstanceInventory);
