/** ********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author: ADM Reports Team Primary:
 * Date: 2021/1/6
 * Version: 0.1
 * Description: A report in the Connexus Report Moderinization project
 */
import React from 'react';
import moment from 'moment';
import { Grid } from '@material-ui/core';

import Table from '../../Common/Table';
import {
  Divider,
  HeadingFour,
  HeadingFive,
  ParaContainer,
  ReportContainer,
} from './HundredDaysDrugsNotUsed.styled';
import Loader from '../../Common/Loader';
import PrintWrapper from '../../Common/PrintReport';
import ErrorMessage from '../../Common/ErrorMessage';
import { useApi, apiStates } from '../../Common/useApi';
import { API_URL, getConfig } from '../../../settings';
import { RouteComponentProps } from 'react-router';

type props = {
  location: { search: string; pathname: string };
};

type dataProps = {
  appName: string;
  store: string;
  reportName: string;
  header: { [field: string]: string }[];
  data: {
    supplier: string;
    store: string;
    detail: {
      [key: string]: string | boolean | number;
    }[];
  }[];
  footerHeader: { [field: string]: string }[];
  footerdata: { [field: string]: string }[];
} | null;

type stateType = { state: string; error: string; data: dataProps };

/**
 * HundredDaysDrugsNotUsed Component
 */
export const HundredDaysDrugsNotUsed: React.FC<RouteComponentProps> = ({
  location: { search, pathname },
}) => {
  const params: any = new URLSearchParams(search);
  const storeId = params.get('storeId');
  const wareHouseItemInd = params.get('wareHouseItemInd');
  const nonWareHouseItemInd = params.get('nonWareHouseItemInd');
  const key = pathname.substr(1);
  const apiHeader = {};
  const URL = API_URL + getConfig(key);

  /**
   * useApi
   * @desc react hook for making Api call
   */
  const { state, error, data }: stateType = useApi(
    'HundredDaysDrugsNotUsed.json',
    { wareHouseItemInd, nonWareHouseItemInd },
    apiHeader,
  );

  /**
   * render
   * @return {ReactElement} markup
   */
  switch (state) {
    case apiStates.ERROR:
      return <ErrorMessage error={error} />;
    case apiStates.SUCCESS:
      window.getData = JSON.stringify(data);
      return (
        <>
          {data && (
            <ReportContainer>
              <Grid container spacing={0}>
                <Grid item xs={4}>
                  <ParaContainer>{`Store # :${storeId}`}</ParaContainer>
                  <ParaContainer>{`Report Date :${moment().format(
                    'MM/DD/YYYY',
                  )}`}</ParaContainer>
                  <br />
                </Grid>
                <Grid item xs={4}>
                  <HeadingFour>{data.appName}</HeadingFour>
                  <HeadingFour>{data.store}</HeadingFour>
                  <HeadingFour>{data.reportName}</HeadingFour>
                </Grid>
              </Grid>

              {data.data.map((n) => (
                <React.Fragment key={Math.random()}>
                  <Divider />
                  <Grid container spacing={0}>
                    <Grid item xs={4}>
                      <HeadingFive>{`Supplier: ${n.supplier}`}</HeadingFive>
                      <br />
                    </Grid>
                    <Grid item xs={4}>
                      <HeadingFive>{`${n.store}`}</HeadingFive>
                    </Grid>
                  </Grid>
                  <Table data={n.detail} header={data.header} />
                </React.Fragment>
              ))}

              <Table
                data={data.footerdata}
                header={data.footerHeader}
              />
            </ReportContainer>
          )}
        </>
      );
    default:
      return <Loader />;
  }
};

export default PrintWrapper(HundredDaysDrugsNotUsed);
