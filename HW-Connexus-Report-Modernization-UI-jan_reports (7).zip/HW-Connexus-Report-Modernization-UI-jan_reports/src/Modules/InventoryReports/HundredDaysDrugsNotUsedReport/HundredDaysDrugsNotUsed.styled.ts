import styled from 'styled-components';

export const ReportContainer = styled.div`
background-color: #fffacd;
padding: 15px;
font-size: 11px;
`;

export const HeadingFour = styled.h4`
margin: 0px;
text-align:center;
`;

export const HeadingFive = styled.h5`
margin: 0px;
`;

export const ParaContainer = styled.p`
margin: 0px;
`;

export const Divider = styled.p`
border-bottom: 1px solid #000;
width: 100%;
`;
