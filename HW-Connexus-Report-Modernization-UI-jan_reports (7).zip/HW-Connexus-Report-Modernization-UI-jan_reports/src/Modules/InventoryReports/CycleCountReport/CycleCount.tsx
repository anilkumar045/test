/** ********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Naga Krishna Koyya(vn50zub)
 * Date: 2020/11/13
 * Version: 0.1
 * Description: This Functional Component is responsible for rendering the Cycle Count Report.
 * This component requests data from the API and renders that data in a UI table to be viewed
 * by the user. The initial request is originated in Connexus. The details of the request are
 * received as query parameters via the URL.
 *
 */

import React, { useEffect } from 'react';
import { Location } from 'history';
import { getApi, postApi } from '../../Common/AxiosCall';
import { apiStates } from '../../Common/useApi';
import PrintWrapper from '../../Common/PrintReport';
import { API_URL, getConfig } from '../../../settings';
import { RouteComponentProps } from 'react-router';

type Props = {
  location: Location;
  search: string;
  pathname: string;
};

type ResponseData = {
  appName: string;
  store: string;
  reportName: string;
  data: { [field: string]: number | string }[];
  header: { [field: string]: string }[];
} | null;

type StateType = {
  state: string;
  error: string;
  data: ResponseData;
};

declare global {
  interface Window {
    getData: string;
    error: string | null;
    apiStatus: number;
    updateData: Function;
  }
}

/**
 * CycleCount Component
 */
export const CycleCount: React.FC<RouteComponentProps> = ({
  location,
}: {
  location: Location;
}) => {
  /**
   * @property {Object} response Handle a list of data which return from server side
   * @property {number} storeId Handle stode id
   */
  const { search, pathname = '' } = location;
  const params = new URLSearchParams(search);
  const storeId = params.get('storeId');
  const queryParams = { storeId };
  const key = pathname.substr(1);
  const apiHeader = {};
  const URL = API_URL + getConfig(key);

  const getData = () => {
    getApi(
      'cycle-count-report.json',
      queryParams,
      apiHeader,
      ({ data }) => setapiStatusingStatus(apiStates.SUCCESS, data),
      (err) => setapiStatusingStatus(apiStates.ERROR, err),
    );
  };

  const updateData = (params: object[]) => {
    setapiStatusingStatus(apiStates.LOADING);
    //param changes
    //queryParams change as per required items
    postApi(
      URL,
      params,
      queryParams,
      () => getData(),
      (err) => setapiStatusingStatus(apiStates.ERROR, err),
    );
  };

  window.updateData = updateData;

  const setapiStatusingStatus = (action: string, state?: string) => {
    switch (action) {
      case apiStates.LOADING:
        window.apiStatus = 0;
      case apiStates.SUCCESS:
        window.apiStatus = 1;
        window.getData = JSON.stringify(state);
      case apiStates.ERROR:
        window.apiStatus = 2;
        window.error = JSON.stringify(state);
    }
  };

  /**
   * useEffect
   * @desc useEffect is a react hook for implementing life cycle methods in functional based components
   */
  useEffect(() => {
    setapiStatusingStatus(apiStates.LOADING);
    getData();
  }, []);

  /**
   * render
   * @return {ReactElement}  content for this component
   */
  return <div />;
};

export default PrintWrapper(CycleCount);
