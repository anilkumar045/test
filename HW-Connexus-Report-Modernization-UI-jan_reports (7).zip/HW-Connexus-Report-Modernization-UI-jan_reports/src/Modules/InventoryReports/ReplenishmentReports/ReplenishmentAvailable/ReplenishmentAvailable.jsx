import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Grid } from '@material-ui/core';
import PrintWrapper from '../../../Common/PrintReport';
import { getApi } from '../../../Common/AxiosCalls';
import Table from '../../../Common/Table';
import { API_URL, getConfig } from '../../../../settings';

/**
 * ReplenishmentAvailable
 */

export class ReplenishmentAvailable extends Component {
  header = [
    {
      label: 'Product',
      id: 'product',
    },
    {
      label: 'NDC',
      id: 'ndc',
    },
    {
      label: 'Total Fills',
      id: 'totalFills',
      includeRxDetails: false,
    },
    {
      label: 'Total Fill Qty',
      id: 'totalFillQty',
      includeRxDetails: false,
    },
    {
      label: 'Rx Nbr',
      id: 'rxNbr',
      includeRxDetails: true,
    },
    {
      label: 'Last Fill Date',
      id: 'lastFillDate',
      includeRxDetails: true,
    },
    {
      label: 'Refills',
      id: 'refills',
      includeRxDetails: true,
    },
    {
      label: 'Fill Qty',
      id: 'fillQty',
      includeRxDetails: true,
    },
    {
      label: 'On-Hand Qty',
      id: 'onHandQty',
    },
  ];

  /**
   * constructor
   * @param {object} props
   */
  constructor(props) {
    super(props);
    /**
     * @type {object}
     * @property {list} data Handle a list of data which return from server side
     * @property {boolean} loading shows the content if flag is false which mean done with load
     * @property {string} error Handle error Message
     */
    this.state = {
      data: null,
      loading: true,
      error: null,
    };
  }

  /**
   * componentDidMount
   * @desc life cycle method for making Api call
   */
  componentDidMount() {
    // getApi('replenishment-available.json', {}, {}, (res) => {
    //   this.setState({ data: res.data, loading: false, error: null });
    // }, (err) => {
    //   this.setState({ data: null, error: err, loading: false });
    // });

    const { location } = this.props;
    const { search, pathname = '' } = location;
    const params = new URLSearchParams(search);
    const fromDate = params.get('fromDate');
    const toDate = params.get('toDate');
    const includeRx = params.get('includeRx');
    this.includeRx = includeRx === 'Y';
    const header = {"Access-Control-Allow-Origin": "*"}
    const key = pathname.substr(1);
    const URL = API_URL + getConfig(key);
    getApi(
      URL,
      { fromDate, toDate, includeRx },
      header,
      (res) => {        
        this.setState({
          data: res.data,
          loading: false,
          error: null,
        });
      },
      (err) => {
        this.setState({ data: null, error: err, loading: false });
      },
    );
  }

  /**
   * render
   * @return {ReactElement} markup
   */
  render() {
    const { data, loading, error } = this.state;
    if (loading) {
      return <div>Loading ....</div>;
    }
    if (error) {
      return <div>{`Error :${error}`}</div>;
    }
    this.header = this.header.filter(
      (col) =>
        (!Object.prototype.hasOwnProperty.call(
          col,
          'includeRxDetails',
        ) || col.includeRxDetails === this.includeRx) &&

        (!Object.prototype.hasOwnProperty.call(
          col,
          'includeRxDetails',
        ) || col.includeRxDetails === this.includeRx)
    );
    return (
      <div className="report-container">
        <Grid container spacing={10}>
          <Grid item xs={4}>
            <p className="para">{`Store # :${data.storeId}`}</p>
            <p className="para">
              {`Report Date :
              ${String(
                new Date(data.reportDate).toLocaleDateString('en-US'),
              )}`}
            </p>
          </Grid>
          <Grid item xs={4}>
            <center>
              <h5 className="pharma-header">{data.appName}</h5>
              <h5 className="pharma-header">{data.store}</h5>
              <h5 className="pharma-header">{data.reportName}</h5>
            </center>
          </Grid>
          <Grid item xs={4}>
            <p className="para">
              From :&nbsp;
              {String(
                new Date(data.fromDate).toLocaleDateString('en-US'),
              )}
              &nbsp;To :&nbsp;
              {String(
                new Date(data.toDate).toLocaleDateString('en-US'),
              )}
            </p>
            <p className="para">{data.address}</p>
          </Grid>
        </Grid>
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <Table data={data.data} header={this.header} />
          </Grid>
        </Grid>
        <Grid container spacing={2}>
          <Grid item xs={5}>
            <h5>Working the Replenishment Available Report</h5>
            <p style={{ marginBottom: '0px' }}>
              Follow the steps below to work the Replenishment
              Available Report
            </p>
            <ol style={{ marginTop: '1px' }}>
              <li>Review the current usage of each item listed</li>
              <ol type="a">
                <li>
                  If the item needs to be ordered, place the order
                  through McKesson Online.
                </li>
              </ol>
            </ol>
          </Grid>
        </Grid>
        <p className="divider-line" />
      </div>
    );
  }
}

ReplenishmentAvailable.propTypes = {
  location: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default PrintWrapper(ReplenishmentAvailable);
