import React, { useState, useEffect } from 'react';
import { Grid } from '@material-ui/core';
import PrintWrapper from '../../../Common/PrintReport';
import { getApi } from '../../../Common/AxiosCalls';
import Table from '../../../Common/Table';
import { API_URL, getConfig } from '../../../../settings';
import { RouteComponentProps } from 'react-router';

/**
 * Replenishment UnAvailable Report
 */
export const ReplenishmentUnAvailable: React.FC<RouteComponentProps> = (
  props,
) => {
  const initialHeaders = [
    {
      label: 'Product',
      id: 'product',
    },
    {
      label: 'NDC',
      id: 'ndc',
    },
    {
      label: 'Total Fills',
      id: 'totalFills',
      includeRxDetails: false,
    },
    {
      label: 'Total Fill Qty',
      id: 'totalFillQty',
      includeRxDetails: false,
    },
    {
      label: 'Rx Nbr',
      id: 'rxNbr',
      includeRxDetails: true,
    },
    {
      label: 'Refills',
      id: 'refills',
      includeRxDetails: true,
    },
    {
      label: 'Fill Qty',
      id: 'fillQty',
      includeRxDetails: true,
    },
    {
      label: 'On-Hand Qty',
      id: 'onHandQty',
    },
  ];
  const [data, updateData] = useState<null | stateData>(null);
  const [loading, updateLoading] = useState<boolean>(true);
  const [error, updateError] = useState<null | string>(null);
  const { location } = props;
  const { search, pathname = '' } = location;
  const params = new URLSearchParams(search);
  const storeId = params.get('storeId');
  const fromDate = params.get('fromDate');
  const toDate = params.get('toDate');
  const includeRx = params.get('includeRx') === 'Y';
  const apiHeader = {};
  const key = pathname.substr(1);
  const URL = API_URL + getConfig(key);

  useEffect(() => {
    getApi(
      URL,
      { fromDate, toDate },
      apiHeader,
      (res: any) => {
        updateData(res.data);
        updateLoading(false);
        updateError(null);
      },
      (err: any) => {
        updateData(null);
        updateLoading(false);
        updateError(err);
      },
    );
  }, []);

  if (loading) {
    return <div>Loading ....</div>;
  }
  if (!!error) {
    return <div>Error :{error}</div>;
  }
  if (!!data) {
    const headers = initialHeaders
      .filter(
        (col) =>
          !Object.prototype.hasOwnProperty.call(
            col,
            'includeRxDetails',
          ) || col.includeRxDetails === includeRx,
      )
      .map(({ id, label }) => ({
        id,
        label,
      }));
    return (
      <div className="report-container">
        <Grid container spacing={10}>
          <Grid item xs={4}>
            <p className="para">Store # :{storeId}</p>
            <p className="para">
              Report Date :{new Date().toLocaleDateString('en-US')}
            </p>
          </Grid>
          <Grid item xs={4} style={{ textAlign: 'center' }}>
            <h5 className="pharma-header">{data.appName}</h5>
            <h5 className="pharma-header">{data.store}</h5>
            <h5 className="pharma-header">{data.reportName}</h5>
          </Grid>
          <Grid item xs={4}>
            <p className="para">
              From :&nbsp;
              {new Date(data.fromDate).toLocaleDateString('en-US')}
              &nbsp;To :&nbsp;
              {new Date(data.toDate).toLocaleDateString('en-US')}
            </p>
            <p className="para">{data.address}</p>
          </Grid>
        </Grid>
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <Table data={data.data} header={headers} />
          </Grid>
        </Grid>
        <Grid container spacing={2}>
          <Grid item xs={5}>
            <h5>Working the Replenishment UnAvailable Report</h5>
            <p style={{ marginBottom: '0px' }}>
              Follow the steps below to work the Replenishment
              UnAvailable Report
            </p>
            <ol style={{ marginTop: '1px' }}>
              <li>Review the current usage of each item listed</li>
              <ol type="a">
                <li>
                  If the item needs to be ordered, place the order
                  through McKesson Online.
                </li>
              </ol>
            </ol>
          </Grid>
        </Grid>
        <p className="divider-line" />
      </div>
    );
  }
  return null;
};

export default PrintWrapper(ReplenishmentUnAvailable);

interface props {
  location: {
    search: string;
    pathname: string;
  };
}

interface stateData {
  appName: string;
  reportName: string;
  store: string;
  address: string;
  fromDate: string;
  toDate: string;
  data: data[];
}

interface data {
  product: string;
  ndc: string;
  totalFills: string;
  totalFillQty: string;
  rxNbr: string;
  refills: string;
  fillQty: string;
  nHandQty: string;
  [key: string]: string | boolean | number;
}
