/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : unknown
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for rendering the CII Drug Summary Report.
 * This component requests data from the API and renders that data in a UI table to be viewed
 * by the user. The initial request is originated in Connexus. The details of the request are
 * received as query parameters via the URL..
 *
 */
import React, { useState, useEffect } from 'react';
import moment from 'moment';
import PrintWrapper from '../../../Common/PrintReport';
import { API_URL, getConfig } from '../../../../settings';
import { getApi } from '../../../Common/AxiosCall';
import CIIDigitalLogBook from '../CIIDigitalLogbook/CIIDigitalLogbook';
import data1 from './cii-loginput.json';
import { useApi, apiStates } from '../../../Common/useApi';
import { RouteComponentProps } from 'react-router';
/**
 * CiiDrugSummary Component
 */

type Row = {
  mdsfamsid: Number;
  drugname: string;
  ndc: string;
  quantity: Number;
  cost: Number;
  status: string;
  onhands: string;
};
type ResponseData = {
  rows: Row[];
  header: { [field: string]: string }[];
} | null;

type LogData = {
  fromDate: string;
  toDate: string;
  storeId: string | null;
  inputData: { [field: string]: number | string }[];
};

declare global {
  interface Window {
    getData: string;
    setInputData: Function;
  }
}
type Props = {
  location: Location;
};
type StateType = {
  state: string;
  error: string;
  data: ResponseData;
};
export const CiiDrugSummary: React.FC<RouteComponentProps> = (
  props:RouteComponentProps
) => {
  const { location } = props;
  const [response, setResponse] = useState<ResponseData>(null);
  const [logInputData, setLogInputData] = useState<LogData>({
    fromDate: '',
    toDate: '',
    storeId: '',

    inputData: [],
  });
  const { search, pathname = '' } = location;
  const params = new URLSearchParams(search);
  const days = Number(params.get('noOfDays'));
  const toDate = moment().format('MM/DD/YYYY');
  const fromDate = moment()
    .subtract(days, 'days')
    .format('MM/DD/YYYY');
  const header = {};
  const key = pathname.substr(1);
  const URL = API_URL + getConfig(key);
  const storeId = params.get('storeId');
  const queryParams = { fromDate, toDate, storeId };

  const { state, error, data }: StateType = useApi(
    'cii-drug-summary.json',
    queryParams,
    header,
  );

  useEffect(() => {
    let unmounted = false;
    if (!unmounted && data && state === apiStates.SUCCESS) {
      setResponse(data);
      /**created data session to sent it to .net team */
      // sessionStorage.setItem('data', JSON.stringify(res.data.rows));
      let inputObject: LogData;
      window.getData = JSON.stringify(data['rows']);
      window.setInputData = (inputData: string) => {
        inputObject = {
          storeId,
          fromDate,
          toDate,
          inputData: JSON.parse(inputData),
        };

        setLogInputData(inputObject);
        return inputObject;
      };
      window.setInputData(window.getData);

      return () => {
        unmounted = true;
      };
    }
  }, [data, state]);

  if (logInputData.inputData) {
    return (
      <div>
        <CIIDigitalLogBook
          propData={logInputData}
        ></CIIDigitalLogBook>
      </div>
    );
  }
  return null;
};
export default PrintWrapper(CiiDrugSummary);
