import React, { useEffect } from 'react';
import { Location } from 'history';
import { useApi } from '../../../Common/useApi';
import { API_URL, getConfig } from '../../../../settings';

type PropDataType = {
  fromDate: string;
  toDate: string;
  storeId: string;
  inputData: { [field: string]: number | string }[];
};

type Props = {
  location: Location;
  search: string;
  pathname: string;
  propData: PropDataType;
};

type stateType = { state: string; error: string; data: DataProps };

type DataProps = {
  appName: string;
  store: string;
  storeNumber: number | string;
  reportDate: string;
  reportName: string;
  drugName: string;
  ndc: string | number;
  from: string;
  to: string;
  data: { [field: string]: number | string }[];
  header: { [field: string]: string }[];
  note: string;
} | null;

interface Window {
  getData: string;
  setInputData: Function;
}
/**
 * CiiDigitalLogbook Component
 */
 const CiiDigitalLogbookNoProp: React.FC<Props> = ({
  location: { search, pathname },
}: Props) => {
  const header = {};
  const params = new URLSearchParams(search);
  const storeId = params.get('storeId');
  const fromDate = params.get('fromDate');
  const toDate = params.get('toDate');
  const drugNameOrNdc = params.get('drugnameorndc');
  const ndc = params.get('ndc');
  

  /**
   * @desc makeing API call for getting c2 digital logbook data
   */
const fetchData= useApi(
  'cii-digital-logbook.json',
  { storeId, fromDate, toDate, drugNameOrNdc, ndc },
  header,
); 
const data=fetchData?fetchData.data:"";
const error=fetchData?fetchData.error:"";


  /**
   * useEffect
   * @desc life cycle method for setting data to window object (usefull for .net)
   */
  useEffect(() => {
    const key = pathname.substr(1);
  const URL = API_URL + getConfig(key);

    if (data) {
      window.getData = JSON.stringify(data);
    } else if (error) {
      window.getData = JSON.stringify(error);
    }
  }, [data, error]);

  return <div></div>;
};

export default CiiDigitalLogbookNoProp;
