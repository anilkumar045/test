/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Report React Track 1 team, Primary : Nick Steen (vn50vbw)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for rendering the CIIDigitalLogBook Table.
 * 
 * This component visually renders the CIIDigitalLogbook 
 *
 */

import React, { Fragment } from 'react';
import TableRow from '@material-ui/core/TableRow';
import {
  StyledTable, StyledTableHead, StyledTableHeaderRow,
  StyledTableHeaderCell, StyledTableBody, StyledTableBodyCell
} from './DigitalLogbook.styled';
import '../../../../assets/table.css';

interface IHeaderObject {
  id: string;
  label: string;
  [field: string]: string;
}

interface ICIIDigitalLogBookPatientData {
  transactionType: string;
  dateAndTime: string;
  cssosOrDea222: string;
  packingListOrMckInv: string;
  rx: number;
  quantity: string;
  balance: number;
  user: string;
  comments: string;
  unique: number;
  [field: string]: string | number;
}

export const CIILogbookTable = ({ data: patientData, header: rows }: { data: ICIIDigitalLogBookPatientData[], header: IHeaderObject[] }) => {
  return (
    <StyledTable aria-labelledby="tableTitle" id="reportTable" className="report-table">
      <StyledTableHead style={{ width: '100%' }}>
        <StyledTableHeaderRow className="table-header-row" >
          {rows.map(
            (row) => (
              <StyledTableHeaderCell
                className="table-header-cell"
                style={{ lineHeight: '24px' }}
                key={row.id}
              >
                {row.label}
              </StyledTableHeaderCell>
            ),
          )}
        </StyledTableHeaderRow>
      </StyledTableHead>
      <StyledTableBody id="reportTableBody" >
        {patientData.length ? (
          patientData.map((n, index: number) => (
            <TableRow
              id={`reportTableRow${index}`}
              hover
              tabIndex={-1}
              key={n.unique}
            >
              {rows.map(
                (row) => (
                  <StyledTableBodyCell
                    key={row.id} >
                    {n[row.id]}
                  </StyledTableBodyCell>
                ),
              )}
            </TableRow>
          ))
        ) : (
            <TableRow
              hover
              tabIndex={-1}
              className="empty-table-row"
            >
              <StyledTableBodyCell colSpan={12} className="empty-table-body">
                No Records Found
              </StyledTableBodyCell>
            </TableRow>
          )}
      </StyledTableBody>
    </StyledTable>
  );

}

// export default CIILogbookTable;