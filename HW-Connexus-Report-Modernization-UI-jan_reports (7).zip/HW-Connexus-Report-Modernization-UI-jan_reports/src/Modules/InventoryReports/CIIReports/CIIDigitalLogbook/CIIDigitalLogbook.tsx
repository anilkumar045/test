/**********************************************************************************
 * This file is digital property of Walmart HnW Team
 * Please ensure strict confidentiality and do not use this code
 * without prior permissions.
 * COPYRIGHT WM 2020-2099
 * Author : Reports React team, Primary : VenuGopalarao Ravula(vn50zuc)
 * Date: 2021/01/05
 * Version: 0.1
 * Description: This Functional Component is responsible for rendering the CII Digital Logbook Report.
 * This component requests data from the API and renders that data in a UI table to be viewed
 * by the user. The initial request is originated in Connexus. The details of the request are
 * received as query parameters via the URL..
 * */

import React, { useState, useEffect, FC } from 'react';
import { Grid } from '@material-ui/core';
// import { Location } from 'history';
import { AxiosResponse } from 'axios';
import moment from 'moment';
import {CIILogbookTable} from './Table';
import { API_URL, getConfig } from '../../../../settings';
import { useApi,apiStates } from '../../../Common/useApi';
import {
  ReportContainer,
  ParaContainer,
  HeadingFour,
  HeadingFive,
} from './DigitalLogbook.styled';
import ErrorMessage from '../../../Common/ErrorMessage';
import Loader from '../../../Common/Loader';
import { RouteChildrenProps } from 'react-router';
import {getApi} from '../../../Common/AxiosCall'

interface PropDataType {
  fromDate: string;
  toDate: string;
  storeId: string | null;
  inputData: { [field: string]: number | string }[];
};

// type Props = {
//   location: Location;
//   search: string;
//   pathname: string;
//   propData: PropDataType;
// };

// type apiData = {
//   transactionType: string;
//   dateAndTime: string;
//   cssosOrDea222: string;
//   packingListOrMckInv: string;
//   rx: number;
//   balance:number;
//   quantity: string;
//   user: string;
//   comments:string;
//   unique:number;
// };
// type header={
//   id: string;
//   label: string;
// };

// type DataProps = {
//   appName: string;
//   store: string;
//   storeNumber: number | string;
//   reportDate: string;
//   reportName: string;
//   drugName: string;
//   ndc: string | number;
//   from: string;
//   to: string;
//   data: apiData[];
//   header: header[];
//   note: string;
// } | null;

interface IHeaderObject {
  id: string;
  label: string;
  [field: string]: string;
}

interface ICIIDigitalLogBookPatientData {
  transactionType: string;
  dateAndTime: string;
  cssosOrDea222: string;
  packingListOrMckInv: string;
  rx: number;
  quantity: string;
  balance: number;
  user: string;
  comments: string;
  unique: number;
  [field: string]: string | number;
}

interface ResponseData {
  storeNumber: number;
  reportDate: string;
  drugName: string;
  ndc: string;
  from:string;
  to:string;
  appName:string;
  store:string;
  reportName:string;
  note:string;
  header: IHeaderObject[];
  data: ICIIDigitalLogBookPatientData[];
}

interface InitialState {
  data: ResponseData;
  loading: boolean;
  error: Error | string | null;
}
type Props = {
  propData: PropDataType;
};
/** 
* CiiDigitalLogbook Component 
*/
export const CiiDigitalLogbook:  FC<Props> =  ({
  propData,
}: Props)=> {
  const initialState: InitialState = {
    data: {
       storeNumber: NaN,
       reportDate: '',
       drugName: '',
       ndc: '',
       from:'',
       to:'',
       appName:'',
       store:'',
       reportName:'',
       note:'',
       header: [],
       data: []
    },
    loading: true,
    error: null,
  }
  /**
   * @type {object}
   * @property {list} data Handle a list of data which return from server side
   * @property {boolean} loading Will show the content if loading is false - finished loading
   * @property {string} error Handle error Message
   * @property {number} storeId Handle stode id
   */
  // const [responseData, setResponseData] = useState<DataProps>(null);
  const [state, setState] = useState(initialState);
  // const [loading, setLoading] = useState<boolean>(true);
  // const [error, setError] = useState<null | string>(null);
  console.log(propData,"propData.inputDatalll")
  const fromDate = propData ? propData.fromDate : null;
  const toDate = propData ? propData.toDate : null;
  const mdsfamid = propData.inputData[0] ? propData.inputData[0].mdsfamid : null;
  const storeId = propData ? propData.storeId : null;
  const header={};

  const fetchData=useApi(
    'cii-digital-logbook.json',
    { fromDate, toDate, mdsfamid, storeId },
    header,
  );
  const responseData:ResponseData=fetchData? fetchData.data :"";
  const responseError:string=fetchData? fetchData.error :"";
  const responseState:string=fetchData? fetchData.state :"";

  /**
   * useEffect
   * @desc life cycle method for making Api call
   */
  // const { location } = props;
  useEffect(() => {
     // Get/Build URL and Query Params for API call
    //  const { search, pathname = '' } = location;
    //  const params = new URLSearchParams(search);
    //  const queryParams: { [key: string]: string } = {};
    //  Array.from(params.keys()).forEach((key) => {
    //    queryParams[key] = params.get(key) || '';
    //  });
    //  const key = pathname.substr(1);
    //  const header = {};
    //  const URL = API_URL + getConfig(key);
      // getApi(
      //   // URL,
      //   'cii-digital-logbook.json',
      //   //{ fromDate, toDate, mdsfamid, storeId },
      //   {},
      //   header,
      //   ({ data }: AxiosResponse) => {
      //     console.log(data);
      if(responseData){
          setState({ 
            data:responseData,
            loading: false,
            error: null,
          });
        }else if(responseError){
          setState((prevState: InitialState) => ({
            ...prevState,
            error:responseError,
            loading: false,
          }));
        }
      //   },
        // (error: string) => {
      //   },
      // );
  }, [responseData,responseError]);

  const { data, loading, error } = state;


  if (loading) {
    return <div>Loading ....</div>;
  }
  if (error) {
    return <div>{`Error: ${error}`}</div>;
  }
  return (
        <ReportContainer className="report-container">
          <Grid container spacing={10}>
            <Grid item xs={4}>
              <ParaContainer className="para">{`Store #: ${data.storeNumber}`}</ParaContainer>
              <ParaContainer className="para">{`Report Date: ${moment().format(
                'MM/DD/YYYY',
              )}`}</ParaContainer>
              <br />
              <ParaContainer className="para">{`Drug Name: ${data.drugName}`}</ParaContainer>
              <ParaContainer className="para">{`NDC: ${data.ndc}`}</ParaContainer>
            </Grid>
            <Grid item xs={4}>
              <HeadingFour className="pharma-header">
                {data.appName}
              </HeadingFour>
              <HeadingFour className="pharma-header">
                {data.store}
              </HeadingFour>
              <HeadingFour className="pharma-header">
                {data.reportName}
              </HeadingFour>
            </Grid>
            <Grid item xs={4}>
              <ParaContainer className="pharma-header">{`From Date: ${data.from}`}</ParaContainer>
              <ParaContainer className="pharma-header">{`To Date: ${data.to}`}</ParaContainer>
            </Grid>
          </Grid>
          {data.data ?  
          <CIILogbookTable
            data={data.data}
            header={data.header}
          />
          : 
          <></>}
         
         <HeadingFive className="text-center">
             {data.note}
           </HeadingFive>
         </ReportContainer>
  );

};

export default CiiDigitalLogbook;
