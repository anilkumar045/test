import styled from 'styled-components';
import {
    Table,
    TableHead,
    TableBody,
    TableRow,
    TableCell
} from '@material-ui/core';

export const StyledTable = styled(Table) `
margin-top: 3px;
`;
export const StyledTableHead = styled(TableHead) `
width: 100%;
`;
export const StyledTableHeaderRow = styled(TableRow) `
border-top:1px solid black;
border-bottom:1px solid black;
`;
export const StyledTableHeaderCell = styled(TableCell) `
padding: 4px 6px ;
font-size: 11px;
border-bottom: 0px;
font-weight: bold;
color:inherit;
line-height:24px;
`;
export const StyledTableBody = styled(TableBody) `
margin-top: 3px;
border-bottom:1px solid black;
`;

export const StyledTableBodyCell = styled(TableCell) `
padding: 4px 6px;
font-size: 11px;
border-bottom: 0px;
`;

export const ReportContainer = styled.div`
background-color: #fffacd;
padding: 15px;
font-size: 11px;
`;

export const HeadingFour = styled.h4`
margin: 0px;
text-align:center;
`;
export const HeadingFive = styled.h5`
margin-top: 0.5em;
text-align:center;
`;

export const ParaContainer = styled.p`
margin: 0px;
`;