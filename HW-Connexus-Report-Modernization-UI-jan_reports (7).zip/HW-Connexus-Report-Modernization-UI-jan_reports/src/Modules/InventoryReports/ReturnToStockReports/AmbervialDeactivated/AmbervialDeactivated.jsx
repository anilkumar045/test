import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Grid } from '@material-ui/core';
import PrintWrapper from '../../../Common/PrintReport';
import { getApi } from '../../../Common/AxiosCalls';
import Table from '../../../Common/Table';
import { API_URL, getConfig } from '../../../../settings';
import {AmbervialDeactivatedPrint} from './AmbervialDeactivatedPrint'
import ReactDOMServer from "react-dom/server";
import { useHistory } from "react-router-dom";

/**
 * AmbervialDeactivated
 */
export class AmbervialDeactivated extends Component {
  header = [
    {
      label: 'Vial ID',
      id: 'vialid',
    },
    {
      label: 'NDC',
      id: 'ndc',
    },
    {
      label: 'Drug Description',
      id: 'drugdescription',      
    },
    {
      label: 'On Hand Qty',
      id: 'onhandqty',      
    },
    {
      label: 'On Hand Cost',
      id: 'onhandcost',
    },
    {
      label: 'Expiration Date',
      id: 'expirationdate',
    },
    {
      label: 'UserID',
      id: 'userid',
    },
    {
      label: 'Time Stamp',
      id: 'timestamp',
    },
    {
      label: '*Reactivate',
      id: 'reactivate',
    },
  ];

  testdata = {
    "storeId": 5545,
    "reportDate": "2020-11-11T23:28:56.782Z",
    "appName": "Connexus Pharmacy System",
    "store": "Wal-Mart Pharmacy10-5533",
    "reportName": "Replenishment Available Report",
    "fromDate": "2020-08-19T23:28:56.782Z",
    "toDate": "2020-11-11T23:28:56.782Z",
    "address": "5025 LOOP 410 NORTHWEST 5025 TRUTH OR CONSEQUENCE TRU COTulsa OK-74008",
    "totalqty": 767,
    "totalcost": "$4,48,71",
    "data": [
      {
        "vialid": "150",
        "ndc": "49035-0175-12",
        "drugdescription": "EQ EX-STR ACETAMINOPHEN TAB",
        "onhandqty": 10,
        "onhandcost": 0.1,
        "expirationdate": "1/21/2016",
        "userid": "VN50W1G",
        "timestamp": "3/21/2016 1:47:15 AM",
        "reactivate": false
      },
      {
        "vialid": "150",
        "ndc": "49035-0175-12",
        "drugdescription": "EQ EX-STR ACETAMINOPHEN TAB",
        "onhandqty": 10,
        "onhandcost": 0.1,
        "expirationdate": "1/21/2016",
        "userid": "VN50W1G",
        "timestamp": "3/21/2016 1:47:15 AM",
        "reactivate": true
      },
      {
        "vialid": "150",
        "ndc": "49035-0175-12",
        "drugdescription": "EQ EX-STR ACETAMINOPHEN TAB",
        "onhandqty": 10,
        "onhandcost": 0.1,
        "expirationdate": "1/21/2016",
        "userid": "VN50W1G",
        "timestamp": "3/21/2016 1:47:15 AM",
        "reactivate": true
      },
      {
        "vialid": "150",
        "ndc": "49035-0175-12",
        "drugdescription": "EQ EX-STR ACETAMINOPHEN TAB",
        "onhandqty": 10,
        "onhandcost": 0.1,
        "expirationdate": "1/21/2016",
        "userid": "VN50W1G",
        "timestamp": "3/21/2016 1:47:15 AM",
        "reactivate": true
      },
      {
        "vialid": "150",
        "ndc": "49035-0175-12",
        "drugdescription": "EQ EX-STR ACETAMINOPHEN TAB",
        "onhandqty": 10,
        "onhandcost": 0.1,
        "expirationdate": "1/21/2016",
        "userid": "VN50W1G",
        "timestamp": "3/21/2016 1:47:15 AM",
        "reactivate": true
      },
      {
        "vialid": "150",
        "ndc": "49035-0175-12",
        "drugdescription": "EQ EX-STR ACETAMINOPHEN TAB",
        "onhandqty": 10,
        "onhandcost": 0.1,
        "expirationdate": "1/21/2016",
        "userid": "VN50W1G",
        "timestamp": "3/21/2016 1:47:15 AM",
        "reactivate": true
      },
      {
        "vialid": "150",
        "ndc": "49035-0175-12",
        "drugdescription": "EQ EX-STR ACETAMINOPHEN TAB",
        "onhandqty": 10,
        "onhandcost": 0.1,
        "expirationdate": "1/21/2016",
        "userid": "VN50W1G",
        "timestamp": "3/21/2016 1:47:15 AM",
        "reactivate": true
      },
      {
        "vialid": "150",
        "ndc": "49035-0175-12",
        "drugdescription": "EQ EX-STR ACETAMINOPHEN TAB",
        "onhandqty": 10,
        "onhandcost": 0.1,
        "expirationdate": "1/21/2016",
        "userid": "VN50W1G",
        "timestamp": "3/21/2016 1:47:15 AM",
        "reactivate": true
      },
      {
        "vialid": "150",
        "ndc": "49035-0175-12",
        "drugdescription": "EQ EX-STR ACETAMINOPHEN TAB",
        "onhandqty": 10,
        "onhandcost": 0.1,
        "expirationdate": "1/21/2016",
        "userid": "VN50W1G",
        "timestamp": "3/21/2016 1:47:15 AM",
        "reactivate": true
      },
      {
        "vialid": "150",
        "ndc": "49035-0175-12",
        "drugdescription": "EQ EX-STR ACETAMINOPHEN TAB",
        "onhandqty": 10,
        "onhandcost": 0.1,
        "expirationdate": "1/21/2016",
        "userid": "VN50W1G",
        "timestamp": "3/21/2016 1:47:15 AM",
        "reactivate": true
      },
      {
        "vialid": "150",
        "ndc": "49035-0175-12",
        "drugdescription": "EQ EX-STR ACETAMINOPHEN TAB",
        "onhandqty": 10,
        "onhandcost": 0.1,
        "expirationdate": "1/21/2016",
        "userid": "VN50W1G",
        "timestamp": "3/21/2016 1:47:15 AM",
        "reactivate": true
      },
      {
        "vialid": "150",
        "ndc": "49035-0175-12",
        "drugdescription": "EQ EX-STR ACETAMINOPHEN TAB",
        "onhandqty": 10,
        "onhandcost": 0.1,
        "expirationdate": "1/21/2016",
        "userid": "VN50W1G",
        "timestamp": "3/21/2016 1:47:15 AM",
        "reactivate": true
      },
      {
        "vialid": "150",
        "ndc": "49035-0175-12",
        "drugdescription": "EQ EX-STR ACETAMINOPHEN TAB",
        "onhandqty": 10,
        "onhandcost": 0.1,
        "expirationdate": "1/21/2016",
        "userid": "VN50W1G",
        "timestamp": "3/21/2016 1:47:15 AM",
        "reactivate": true
      },
      {
        "vialid": "150",
        "ndc": "49035-0175-12",
        "drugdescription": "EQ EX-STR ACETAMINOPHEN TAB",
        "onhandqty": 10,
        "onhandcost": 0.1,
        "expirationdate": "1/21/2016",
        "userid": "VN50W1G",
        "timestamp": "3/21/2016 1:47:15 AM",
        "reactivate": true
      }
    ]
  }

  /**
   * constructor
   * @param {object} props
   */
  constructor(props) {
    super(props);
    /**
     * @type {object}
     * @property {list} data Handle a list of data which return from server side
     * @property {boolean} loading shows the content if flag is false which mean done with load
     * @property {string} error Handle error Message
     */
    this.state = {
      data: null,
      loading: true,
      error: null,
    };
    this.updateOnActivate = this.updateOnActivate.bind(this)
  }

  /**
   * componentDidMount
   * @desc life cycle method for making Api call
   */
  componentDidMount() {
    // getApi('replenishment-available.json', {}, {}, (res) => {
    //   this.setState({ data: res.data, loading: false, error: null });
    // }, (err) => {
    //   this.setState({ data: null, error: err, loading: false });
    // });

    const { location } = this.props;
    const { search, pathname = '' } = location;
    const params = new URLSearchParams(search);
    const fromDate = params.get('fromDate');
    const toDate = params.get('toDate');
    const header = {"Access-Control-Allow-Origin": "*"}
    const key = pathname.substr(1);
    const URL = API_URL + getConfig(key);
    getApi(
      URL,
      { fromDate, toDate },
      header,
      (res) => {        
        this.setState({
          data: this.testdata,
          loading: false,
          error: null,
        });
      },
      (err) => {
        this.setState({ data: this.testdata, error: null, loading: false });
      },
    );
 }

onSave(){
    const { data, loading, error } = this.state;
}  

updateOnActivate(r, c, e){
    const { data, loading, error } = this.state;
    data.data[r][c] = e.target.checked    
    this.setState({
        data: data,
        loading: false,
        error: null,
      });
 }

  /**
   * render
   * @return {ReactElement} markup
   */
  render() {
    const { data, loading, error } = this.state;
    if (loading) {
      return <div>Loading ....</div>;
    }
    if (error) {
      return <div>{`Error :${error}`}</div>;
    }
    return (
      <div className="report-container">
         <Grid container spacing={10}>
          <Grid item xs={4}>
            <p className="para">{`Store # :${data.storeId}`}</p>
             <p className="para">
              {`Report Date :
              ${String(
                new Date(data.reportDate).toLocaleDateString('en-US'),
              )}`}
            </p>
            <p className="para">
              From :&nbsp;
              {String(
                new Date(data.fromDate).toLocaleDateString('en-US'),
              )}
              &nbsp;To :&nbsp;
              {String(
                new Date(data.toDate).toLocaleDateString('en-US'),
              )}
            </p>            
          </Grid>
          <Grid item xs={4}>
            <center>
              <h5 className="pharma-header">{data.appName}</h5>
              <h5 className="pharma-header">{data.store}</h5>
              <h5 className="pharma-header">{data.reportName}</h5>
            </center>
          </Grid>
          <Grid item xs={4}>
          </Grid>
        </Grid>
        <Grid container spacing={2}>
          <Grid item xs={5}>
            <h3>Instructions</h3>
            <p style={{ marginBottom: '0px' }}>
            All amber vials listed on this report have been deactivated and should not be on the shelf
            </p>
            <p style={{ marginBottom: '0px' }}>
            Amber vials can be reactivated by clicking in the Reactivate columns
            </p>
            <p style={{ marginBottom: '0px' }}>
            For Further instruction refer to  <a href="https://www.walmart.com">POM 1705 Return to Stock Program</a>
            </p>
          </Grid>
        </Grid>        
        <br></br>
        <div style={{width:"100%",height:"200px",overflow:"scroll"}}>
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <Table data={data.data} header={this.header} iscellcheck = {{cellcheckid : "reactivate",cellcheckUpdate : this.updateOnActivate}} />
          </Grid>
        </Grid>
        </div>
        <p className="divider-line" />
        <br/>
        <Grid container spacing={2}>
          <Grid item xs={5}>            
            <p style={{ marginBottom: '0px' }}>
            Total On-Hand Quantity is <b> 767 </b> 
            </p>
            <p style={{ marginBottom: '0px' }}>
            Total On-Hand Cost is <b>$4,428.71</b> 
            </p>
          </Grid>
        </Grid>   
        <Grid container spacing={3}>
        <Grid item xs={6} sm={3}>
            columns with an * are editable
        </Grid>
        <Grid item xs={6} sm={3}>          
        </Grid>
        <Grid item xs={6} sm={3}>          
        </Grid>
        <Grid item xs={6} sm={3}>
            &nbsp;&nbsp;
            <button  onClick={()=>{
                this.onSave();
            }}>   Save Changes </button>
            &nbsp;&nbsp;
            <button> Back </button>
            &nbsp;&nbsp;
            <button onClick={()=>{
                let rethtml = ReactDOMServer.renderToString(<AmbervialDeactivatedPrint data={data} />)
                var win = window.open("", "");                
                win.document.write(rethtml);
                win.focus();
                win.print();
                win.document.close();
                win.close(); 
            }}> Print  </button>
            &nbsp;&nbsp;
        </Grid>
        </Grid>
      </div>
    );
  }
}

AmbervialDeactivated.propTypes = {
  location: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default PrintWrapper(AmbervialDeactivated);
