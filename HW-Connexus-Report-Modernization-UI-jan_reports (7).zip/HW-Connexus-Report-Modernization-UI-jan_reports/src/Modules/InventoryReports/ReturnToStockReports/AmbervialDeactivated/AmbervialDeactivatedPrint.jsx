import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Grid } from '@material-ui/core';
import PrintWrapper from '../../../Common/PrintReport';
import { getApi } from '../../../Common/AxiosCalls';
import Table from '../../../Common/Table';
import { API_URL, getConfig } from '../../../../settings';

/**
 * AmbervialDeactivatedPrint
 */

export class AmbervialDeactivatedPrint extends Component {
  header = [
    {
      label: 'Vial ID',
      id: 'vialid',
    },
    {
      label: 'NDC',
      id: 'ndc',
    },
    {
      label: 'Drug Description',
      id: 'drugdescription',      
    },
    {
      label: 'On Hand Qty',
      id: 'onhandqty',      
    },
    {
      label: 'On Hand Cost',
      id: 'onhandcost',
    },
    {
      label: 'Expiration Date',
      id: 'expirationdate',
    },
    {
      label: 'UserID',
      id: 'userid',
    },
    {
      label: 'Time Stamp',
      id: 'timestamp',
    },
  ];

  
  /**
   * constructor
   * @param {object} props
   */
  constructor(props) {
    super(props);
    /**
     * @type {object}
     * @property {list} data Handle a list of data which return from server side
     * @property {boolean} loading shows the content if flag is false which mean done with load
     * @property {string} error Handle error Message
     */
     this.state = {
        data: this.props.data
      }
  }

  /**
   * render
   * @return {ReactElement} markup
   */
  render() {
    const { data } = this.state;
    return (
      <div className="report-container">
        <Grid container spacing={5}>
          <Grid item xs={4}>
            <p>{`Store # :${data.storeId}`}</p>
            <p>
              {`Report Date :
              ${String(
                new Date(data.reportDate).toLocaleDateString('en-US'),
              )}`}
            </p>
            <p>
              From :&nbsp;
              {String(
                new Date(data.fromDate).toLocaleDateString('en-US'),
              )}
              &nbsp;To :&nbsp;
              {String(
                new Date(data.toDate).toLocaleDateString('en-US'),
              )}
            </p>            
          </Grid>
          <Grid item xs={4}>
            <center>
              <h5>{data.appName}</h5>
              <h5>{data.store}</h5>
              <h5>{data.reportName}</h5>
            </center>
          </Grid>
        </Grid>
        <Grid container spacing={2}>
          <Grid item xs={5}>
            <h3>Instructions</h3>
            <p style={{ marginBottom: '0px' }}>
            All amber vials listed on this report have been deactivated and should not be on the shelf
            </p>
            <p style={{ marginBottom: '0px' }}>
            Amber vials can be reactivated by clicking in the Reactivate columns
            </p>
            <p style={{ marginBottom: '0px' }}>
            For Further instruction refer to  <a href="https://www.walmart.com">POM 1705 Return to Stock Program</a>
            </p>
          </Grid>
        </Grid>        
        <br></br>
        <div>
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <Table data={data.data} header={this.header}  />
          </Grid>
        </Grid>
        </div>
        <p className="divider-line" />
        <br/>
        <Grid container spacing={2}>
          <Grid item xs={5}>            
            <p style={{ marginBottom: '0px' }}>
            Total On-Hand Quantity is <b> 767 </b> 
            </p>
            <p style={{ marginBottom: '0px' }}>
            Total On-Hand Cost is <b>$4,428.71</b> 
            </p>
          </Grid>
        </Grid>   
        <Grid container spacing={3}>
        <Grid item xs={6} sm={3}>
        </Grid>
        <Grid item xs={6} sm={3}>          
        </Grid>
        <Grid item xs={6} sm={3}>          
        </Grid>
        <Grid item xs={6} sm={3}>
        </Grid>
        </Grid>
      </div>
    );
  }
}

export default AmbervialDeactivatedPrint;
