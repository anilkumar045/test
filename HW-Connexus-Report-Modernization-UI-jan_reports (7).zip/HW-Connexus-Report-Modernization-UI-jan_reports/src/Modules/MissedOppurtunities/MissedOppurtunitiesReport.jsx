import { Grid } from '@material-ui/core';
import PropTypes from 'prop-types';
import React, { Component } from 'react';
import PrintWrapper from '../Common/PrintReport';
import { API_URL, getConfig } from '../../settings';
import { getApi } from '../Common/AxiosCalls';
import Table from '../Common/Table';
import { MORAggregateData } from './MORAggregateData';
/**
 *  Missed Oppurtunities Report
 */
export class MissedOppurtunitiesReport extends Component {
  /**
   * constructor
   * @param {object} props
   */
  constructor(props) {
    super(props);
    /**
     * @type {object}
     * @property {list} data Handle a list of data which return from server side
     * @property {boolean} loading Will show the content if loading is false which mean done with load
     * @property {string} error Handle error Message
     * @property {string} date Handle date
     */
    this.state = {
      data: null,
      loading: true,
      error: null,
      date: null,
    };
  }

  /**
   * componentDidMount
   * @desc life cycle method for making Api call
   */
  componentDidMount() {
    const { location } = this.props;
    const { search, pathname = '' } = location;
    const params = new URLSearchParams(search);
    const date = params.get('date');
    const key = pathname.substr(1);
    const header = {};
    const URL = API_URL + getConfig(key);

    getApi(
      URL,
      { date },
      header,
      (res) => {
        this.setState({ data: res.data, loading: false, error: null });
      },
      (err) => {
        this.setState({ data: null, error: err, loading: false });
      },
    );
  }

  /**
   * render
   * @return {ReactElement}  content for this component
   */

  render() {
    const { data, loading, error } = this.state;

    if (loading) {
      return <div>Loading ....</div>;
    }
    if (error) {
      return (
<div>
Error :
{' '}
{error}
</div>
);
    }
    return (
      <div className="report-container">
        <Grid container spacing={24}>
          <Grid item xs={4}>
            <p>
              Store # :
              {' '}
              {data.storeId}
              {' '}
            </p>
            <p>
              Report Date :
              {' '}
              {data.date}
              {' '}
            </p>
          </Grid>
          <Grid item xs={4}>
            <h5>{data.appName}</h5>
            <h5>{data.store}</h5>
            <h5>{data.reportName}</h5>
          </Grid>
          <Grid item xs={4}>
            <p>{data.details}</p>
          </Grid>
        </Grid>
        <Table data={data.data} header={data.header} />
        <MORAggregateData data={data.aggregates} />
        <h6>
          {data.note}
          {' '}
        </h6>
      </div>
    );
  }
}

MissedOppurtunitiesReport.propTypes = {
  location: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default PrintWrapper(MissedOppurtunitiesReport);
