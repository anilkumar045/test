export const API_URL = process.env.REACT_APP_NODE_ENV.trim();

const endPoints = {
  'rx-report': '/rx-report',
  '4-point-check-report': '/4-point-check-report',
  'tp-receivables-by-reg-acct-159': '/tp-receivables-by-reg-acct-159',
  'pharmacy-activity': '/pharmacy-activity',
  'central-fill-performance-report':
    '/central-fill-performance-report',
  'controlled-substance-pickup-report':
    '/controlled-substance-pickup-report',
  'leaflet-cover-sheet-printed-by-language':
    '/leaflet-cover-sheet-printed-by-language',
  'missed-opportunities-report': '/missed-opportunities-report',
  'pharmacy-business-summary': '/pharmacy-business-summary',
  'remote-order-review': '/remote-order-review',
  'wait-for-drug-order': '/wait-for-drug',
  'cancel-fill': '/cancel-fill',
  'partial-fill': '/partial-fill',
  'on-hold': '/on-hold',
  compliance: '/compliance',
  'replenishment-unavailable': '/replenishment-unavailable',
  'replenishment-available': '/replenishment-available',
  'cycle-count': '/cycle-count-report',
  'regulatory-patient-profile': '/regulatory-patient-profile',
  'cii-digital-logbook': '/cii-digital-logbook',
  'bagging-detail': '/bagging-detail',
  'auto-fill-utilization': '/auto-fill-utilization',
  'will-call-bin': '/will-call-bin',
  'drug-inventory-onhand': '/drug-inventory-onhand',
  'temp-user': '/temp-user',
  'daily-visual-verify': '/daily-visual-verify',
  'hundred-days-drugs-not-used': '/hundred-days-drug-no-use',
  'pseudoephedrine-patient-summary': '/patient-summary',
  'amber-vial-active-inventory': '/amber-vial-active-inventory',
  'cii-drug-summary': '/cii-drug-summary',
  ambervialdeactivated: '/ambervialdeactivated',
  'controlled-substance-rx-details':
    '/controlled-substance-rx-details',
  'amber-vial-inventory': '/amber-vial-inventory',
  'prescriptionimage' : '/prescriptionimage'
};
const reportDetails = {
  'daily-visual-verify': { reportName: 'visual verify check' },
  '4-point-check-report': { reportName: '4Point Check' },
  'amber-vial-active-inventory': { hasUpdate: true },
  'amber-vial-inventory': { hasUpdate: false },
};
export const getReportDetails = (id) => reportDetails[id];
export const getConfig = (id) => endPoints[id];
