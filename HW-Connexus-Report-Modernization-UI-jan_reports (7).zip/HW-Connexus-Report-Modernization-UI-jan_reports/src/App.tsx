import React from 'react';
import {
  BrowserRouter as Router,
  Route,
  Switch,
} from 'react-router-dom';
import './App.css';
import ControlledSubstanceDetails from './Modules/Audit/ControlledSubstanceDetails';
import RxModificationLog from './Modules/Audit/RxModificationLog/RxModificationLog';
import TempUser from './Modules/Audit/TempUser/TempUser';
import OrderCompletionPerformance from './Modules/DailyReports/OrderCompletionPerformance/OrderCompletionPerformance';
import FourPointCheckReport from './Modules/FourPointCheck/FourPointCheck';
import FourPTRphCorrection from './Modules/FourPTRPhCorrections/FourPTRphCorrectionMain';
import MedicalExpenseSummary from './Modules/HIPAA/MedicalExpenseSummary/MedicalExpenseSummary';
import Home from './Modules/Home/Home';
import AmberVialInventory from './Modules/InventoryReports/AmberVialInventory/AmberVialInventory';
import CIIDigitalLogbook from './Modules/InventoryReports/CIIReports/CIIDigitalLogbook/CIIDigitalLogbookNoprops';
import CIIDrugSummary from './Modules/InventoryReports/CIIReports/CIIDrugSummary/CIIDrugSummary';
import ControlledSubstanceInventory from './Modules/InventoryReports/ControlledSubstanceInventory/ControlledSubstanceInventory';
import CycleCount from './Modules/InventoryReports/CycleCountReport/CycleCount';
import HundredDaysDrugsNotUsed from './Modules/InventoryReports/HundredDaysDrugsNotUsedReport/HundredDaysDrugsNotUsed';
import ReplenishmentAvailable from './Modules/InventoryReports/ReplenishmentReports/ReplenishmentAvailable/ReplenishmentAvailable';
import ReplenishmentUnAvailable from './Modules/InventoryReports/ReplenishmentReports/ReplenishmentUnAvailable/ReplenishmentUnAvailable';
import AmbervialDeactivated from './Modules/InventoryReports/ReturnToStockReports/AmbervialDeactivated/AmbervialDeactivated';
import MissedOppurtunitiesReport from './Modules/MissedOppurtunities/MissedOppurtunitiesReport';
import PharmacistActivity from './Modules/PharmacistActivity/PharmacistActivity';
import PharmacistBusinessSummary from './Modules/PharmacistBusinessSummary/PharmacistBusinessSummary';
import InputIncorrectEnteriesMain from './Modules/PharmacistReport/InputIncorrectEnteries/InputIncorrectEnteriesMain';
import BaggingMain from './Modules/Pickup/POSReports/Bagging/BaggingMain';
import WillCallBinMain from './Modules/Pickup/POSReports/WillCallBin/WillCallBinMain';
import PatientSummary from './Modules/Pseudoephedrine/PatientSummaryReport/PatientSummary';
import RegulatoryPatientProfileReport from './Modules/RegulatoryPatientProfileReport/RegulatoryPatientProfileReport';
import RemoteOrder from './Modules/RemoteOrder/RemoteOrder';
import AutoFillUtilizationMain from './Modules/RxReports/AutoFillUtilization/AutoFillUtilizationMain';
import CancelFill from './Modules/RxReports/CancelFill/CancelFill';
import CentralFillPerformance from './Modules/RxReports/CentralFillPerformance/CentralFillPerformance';
import Compliance from './Modules/RxReports/Compliance/Compliance';
import ControlledSubstancePickup from './Modules/RxReports/ControlledSubstancePickup/ControlledSubstancePickup';
import CurrentOnHoldInventoryMain from './Modules/RxReports/CurrentOnHoldInventory/CurrentOnHoldInventoryMain';
import LeafletCoverSheet from './Modules/RxReports/LeafletCoverSheet/LeafletCoverSheet';
import OnHoldReport from './Modules/RxReports/OnHoldReport/OnHoldReport';
import PartialFill from './Modules/RxReports/PartialFill/PartialFill';
import RxReport from './Modules/RxReports/RxActivityReport/RxActivityReport';
import WaitForDrugOrder from './Modules/RxReports/WaitForDrugOrder/WaitForDrugOrder';
import TPReceivables from './Modules/TPReceivables/TPReceivables';
import PrescriptionImage from './Modules/PharmacistReport/PrescriptionImage/PrescriptionImage'

import { ErrorBoundary } from 'react-error-boundary';
import ErrorFallback from './Modules/Common/ErrorFallBack';

function App() {
  return (
    <ErrorBoundary FallbackComponent={ErrorFallback}>
      <Router>
        <Switch>
          <Route exact path="/" component={Home} />
          <Route
            exact
            path="/auto-fill-utilization"
            component={AutoFillUtilizationMain}
          />
          <Route
            exact
            path="/input-incorrect-enteries"
            component={InputIncorrectEnteriesMain}
          />
          <Route exact path="/on-hold" component={OnHoldReport} />
          <Route
            exact
            path="/drug-inventory-onhand"
            component={CurrentOnHoldInventoryMain}
          />
          <Route exact path="/rx-report" component={RxReport} />
          <Route
            exact
            path="/4-point-check-report"
            component={FourPointCheckReport}
          />
          <Route
            exact
            path="/pharmacy-activity"
            component={PharmacistActivity}
          />
          <Route
            exact
            path="/controlled-substance-rx-details"
            component={ControlledSubstanceDetails}
          />
          <Route
            exact
            path="/controlled-substance-pickup-report"
            component={ControlledSubstancePickup}
          />
          <Route
            exact
            path="/central-fill-performance-report"
            component={CentralFillPerformance}
          />
          <Route
            exact
            path="/pharmacy-business-summary"
            component={PharmacistBusinessSummary}
          />
          <Route
            exact
            path="/remote-order-review"
            component={RemoteOrder}
          />
          <Route
            exact
            path="/leaflet-cover-sheet-printed-by-language"
            component={LeafletCoverSheet}
          />
          <Route
            exact
            path="/missed-opportunities-report"
            component={MissedOppurtunitiesReport}
          />
          <Route
            exact
            path="/tp-receivables-by-reg-acct-159"
            component={TPReceivables}
          />
          <Route
            exact
            path="/wait-for-drug"
            component={WaitForDrugOrder}
          />
          <Route exact path="/partial-fill" component={PartialFill} />
          <Route exact path="/compliance" component={Compliance} />
          <Route
            exact
            path="/hundred-days-drugs-not-used"
            component={HundredDaysDrugsNotUsed}
          />
          <Route exact path="/cancel-fill" component={CancelFill} />
          <Route
            exact
            path="/bagging-detail"
            component={BaggingMain}
          />
          <Route
            exact
            path="/cii-digital-logbook"
            component={CIIDigitalLogbook}
          />
          <Route
            exact
            path="/will-call-bin"
            component={WillCallBinMain}
          />
          <Route exact path="/cycle-count" component={CycleCount} />
          <Route
            exact
            path="/replenishment-unavailable"
            component={ReplenishmentUnAvailable}
          />
          <Route
            exact
            path="/replenishment-available"
            component={ReplenishmentAvailable}
          />
          <Route
            exact
            path="/regulatory-patient-profile"
            component={RegulatoryPatientProfileReport}
          />
          <Route
            exact
            path="/order-completion-performance"
            component={OrderCompletionPerformance}
          />

          <Route
            exact
            path="/rx-modification-log"
            component={RxModificationLog}
          />

          <Route exact path="/temp-user" component={TempUser} />

          <Route
            exact
            path="/daily-visual-verify"
            component={FourPointCheckReport}
          />
          <Route path="/patient-summary" component={PatientSummary} />

          <Route
            exact
            path="/Four-PTRph-Correction"
            component={FourPTRphCorrection}
          />
          <Route
            exact
            path="/controlled-sub-inventory"
            component={ControlledSubstanceInventory}
          />
          <Route
            exact
            path="/amber-vial-inventory"
            component={AmberVialInventory}
          />
          <Route
            exact
            path="/amber-vial-active-inventory"
            component={AmberVialInventory}
          />
          <Route
            exact
            path="/cii-drug-summary"
            component={CIIDrugSummary}
          />
          <Route
            exact
            path="/ambervialdeactivated"
            component={AmbervialDeactivated}
          />
          <Route
            exact
            path="/medical-expense-summary"
            component={MedicalExpenseSummary}
          />
      <Route
        exact
        path="/prescriptionimage"
        component={PrescriptionImage}
      />    
        </Switch>
      </Router>
    </ErrorBoundary>
  );
}

export default App;
