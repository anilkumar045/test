import * as Helper from '../Modules/Common/AxiosCalls';
import * as Helperts from '../Modules/Common/AxiosCall.tsx';
import * as HelperUseApi from '../Modules/Common/useApi.ts';

Helper.getApi = jest.fn();
Helperts.getApi = jest.fn();
Helperts.postApi = jest.fn();
HelperUseApi.useApi = jest.fn();


export const mockSuccess = (returnObj) => {
  jest.clearAllMocks();
  Helper.getApi.mockImplementation((url, params, header, success) => {
    success(returnObj);
  });
};

export const mockFailure = (returnObj) => {
  jest.clearAllMocks();
  Helper.getApi.mockImplementation(
    (url, params, header, success, failure) => {
      failure(returnObj);
    },
  );
};

export const mockSuccessts = (returnObj) => {
  jest.clearAllMocks();
  Helperts.getApi.mockImplementation(
    (url, params, header, success) => {
      success(returnObj);
    },
  );
};

export const mockFailurets = (returnObj) => {
  jest.clearAllMocks();
  Helperts.getApi.mockImplementation(
    (url, params, header, success, failure) => {
      failure(returnObj);
    },
  );
};

export const mockUseApi = (returnObj) => {
  jest.clearAllMocks();
  HelperUseApi.useApi.mockReturnValue(returnObj);
};

export const mockPostSuccessts = (returnObj) => {
  jest.clearAllMocks();
  Helperts.postApi.mockImplementation(
    (url, params, query, success) => {
      success(returnObj);
    },
  );
};

export const mockPostFailurets = (returnObj) => {
  jest.clearAllMocks();
  Helperts.postApi.mockImplementation(
    (url, params, query, success, failure) => {
      failure(returnObj);
    },
  );
};
