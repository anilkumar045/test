import React from 'react';
import { shallow } from 'enzyme';
import { render } from '@testing-library/react';
import { mockSuccessts, mockFailurets } from '../../../util';
import * as data from '../../../../../public/HundredDaysDrugsNotUsed.json';
import Wrapper, {
  HundredDaysDrugsNotUsed,
} from '../../../../Modules/InventoryReports/HundredDaysDrugsNotUsedReport/HundredDaysDrugsNotUsed';

describe('HundredDaysDrugsNotUsed', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render loading message', () => {
    const { container } = render(<HundredDaysDrugsNotUsed location={{ pathname: '/hundred-days-drugs-not-used' }} />);
    expect(container.children).toMatchSnapshot();
  });

  it('should render report data', () => {
    mockSuccessts({ data });
    const { container } = render(<HundredDaysDrugsNotUsed location={{ pathname: '/hundred-days-drugs-not-used' }} />);
    expect(container.children).toMatchSnapshot();
  });

  it('should render error message', () => {
    mockFailurets('error');
    const { container } = render(<HundredDaysDrugsNotUsed location={{ pathname: '/hundred-days-drugs-not-used' }} />);
    expect(container.children).toMatchSnapshot();
  });

});
