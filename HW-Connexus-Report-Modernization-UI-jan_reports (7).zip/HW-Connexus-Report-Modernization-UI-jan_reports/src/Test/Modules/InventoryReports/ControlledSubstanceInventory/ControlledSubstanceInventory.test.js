import React from 'react';
import { shallow } from 'enzyme';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import Wrapper, {
  ControlledSubstanceInventory,
} from '../../../../Modules/InventoryReports/ControlledSubstanceInventory/ControlledSubstanceInventory.tsx';
import { mockSuccess, mockFailure } from '../../../util';

describe('ControlledSubstanceInventory', () => {

  const data = {
    appName: 'Connexus Pharmacy System',
    store: 'Sams Pharmacy10-5545',
    reportName: 'Controlled Substance Inventory Report',
    header: [
      {
        label: 'Drug Name\nNDC',
        id: 'drugDetails'
      },
      {
        label: 'Dosage Form',
        id: 'dosageForm'
      },
      {
        label: 'Control Schedule',
        id: 'controlSchedule'
      },
      {
        label: 'Pack Size',
        id: 'packSize'
      },
      {
        label: '# of Full Stock Bottle',
        id: 'noOfFullStockBottle'
      },
      {
        label: 'Qty in Partial Stock Bottle 1',
        id: 'qtyInPartialStockBottle1'
      },
      {
        label: 'Qty in Partial Stock Bottle 2',
        id: 'qtyInPartialStockBottle2'
      },
      {
        label: 'Qty in Partial Stock Bottle 3',
        id: 'qtyInPartialStockBottle3'
      },
      {
        label: 'Qty in Partial Stock Bottle 4',
        id: 'qtyInPartialStockBottle4'
      },
      {
        label: 'Total On-Hand',
        id: 'totalOnHand'
      }
    ],
    data: [
      {
        drugName: 'ABILIFY DISC 10MG TAB',
        ndc: '59148-0640-23',
        dosageForm: 'TABLET',
        controlSchedule: 'CII',
        packSize: 30,
        noOfFullStockBottle: '',
        qtyInPartialStockBottle1: '',
        qtyInPartialStockBottle2: '',
        qtyInPartialStockBottle3: '',
        qtyInPartialStockBottle4: '',
        totalOnHand: '',
      },
    ],
  };

  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render loading message', () => {
    const { container } = render(<ControlledSubstanceInventory location={{ pathname: '/controlled-sub-inventory' }} />);
    expect(container.children).toMatchSnapshot();
  });

  it('should render report w/ data', () => {
    mockSuccess({ data });
    const { container } = render(<ControlledSubstanceInventory location={{ pathname: '/controlled-sub-inventory' }} />);
    expect(container.children).toMatchSnapshot();
  });

  it('should render error message', () => {
    mockFailure('error');
    const { container } = render(<ControlledSubstanceInventory location={{ pathname: '/controlled-sub-inventory' }} />);
    expect(container.children).toMatchSnapshot();
  });
});
