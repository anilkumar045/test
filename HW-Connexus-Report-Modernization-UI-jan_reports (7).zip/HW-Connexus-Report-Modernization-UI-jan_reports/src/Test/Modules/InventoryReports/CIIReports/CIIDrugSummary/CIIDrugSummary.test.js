import React from 'react';
import { shallow } from 'enzyme';
import { MemoryRouter } from 'react-router';
import { CiiDrugSummary } from '../../../../../Modules/InventoryReports/CIIReports/CIIDrugSummary/CIIDrugSummary';
import { mockFailurets, mockSuccessts } from '../../../../util';
import data from '../../../../../../public/cii-drug-summary.json';
import { render } from '@testing-library/react';
describe('CiiDrugSummary', () => {
  it('should render correctly', () => {
    const comp = shallow(<CiiDrugSummary location={{}} />);
    expect(comp).toMatchSnapshot();
  });
  it('should render correctly', () => {
    const component = render(
      <MemoryRouter>
        <CiiDrugSummary
          location={{ pathname: '/cii-drug-summary' }}
        />
      </MemoryRouter>,
    );
    expect(component).toMatchSnapshot();
  });
  it('should render report data', () => {
    mockSuccessts({ data });
    const { container } = render(
      <MemoryRouter>
        <CiiDrugSummary
          location={{ pathname: '/cii-drug-summary' }}
        />
      </MemoryRouter>,
    );
    expect(container.children).toMatchSnapshot();
  });
  it('should render report data', () => {
    mockFailurets('error');
    const { container } = render(
      <MemoryRouter>
        <CiiDrugSummary
          location={{ pathname: '/cii-drug-summary' }}
        />
      </MemoryRouter>,
    );
    expect(container.children).toMatchSnapshot();
  });
  it('should render correctly', () => {
    const initialState = {
      data: null,
      error: null,
    };
    const component = shallow(
      <CiiDrugSummary location={{}} initialState={initialState} />,
    );
    component.instance();
  });
  it('should render correctly', () => {
    const initialState = {
      data,
      error: null,
    };
    const component = shallow(
      <CiiDrugSummary location={{}} initialState={initialState} />,
    );
    component.instance();
  });
});
