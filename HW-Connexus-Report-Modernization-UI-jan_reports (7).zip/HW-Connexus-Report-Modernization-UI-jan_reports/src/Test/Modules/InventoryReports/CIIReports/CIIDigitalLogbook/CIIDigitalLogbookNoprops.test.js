import React from 'react';
import { shallow } from 'enzyme';
import { render } from '@testing-library/react';
import { mockUseApi } from '../../../../util';
import CiiDigitalLogbookNoprops from '../../../../../Modules/InventoryReports/CIIReports/CIIDigitalLogbook/CIIDigitalLogbookNoprops';
import * as data from '../../../../../../public/cii-digital-logbook.json';

describe('CiiDigitalLogbookNoprops', () => {
  
    it('should render correctly', () => {
      const component = shallow(<CiiDigitalLogbookNoprops location={{}} />);
      component.instance();
    });
  
    it('should render correctly', () => {
      const initialState= {
        data: [],
        error: '',
      };
      const component = shallow(
        <CiiDigitalLogbookNoprops location={{}} initialState={initialState} />,
      );
      component.instance();
    });
  
    it('should render correctly', () => {
      const initialState= {
        data,
        error: '',
      };
      const component = shallow(
        <CiiDigitalLogbookNoprops location={{}} initialState={initialState} />,
      );
      component.instance();
    });
  
    // it('should render report data', () => {
    //   mockSuccess({ data });
    //   const { container } = render(<CiiDigitalLogbookNoprops location={{pathname:'/cii-digital-logbook'}} />);
    //   expect(container.children).toMatchSnapshot();
    // });
  
    // it('should render error message', () => {
    //   mockFailure('error');
    //   const { container } = render(<CiiDigitalLogbookNoprops location={{pathname:'/cii-digital-logbook'}} />);
    //   expect(container.children).toMatchSnapshot();
    // });

    it('should render report data', () => {
      mockUseApi({ data, error: '' });
      const { container } = render(<CiiDigitalLogbookNoprops location={{ pathname: '/cii-digital-logbook' }} />);
      expect(container.children).toMatchSnapshot();
    });
  
    it('should render error message', () => {
      mockUseApi({ data: {}, error: 'network error' });
      const { container } = render(<CiiDigitalLogbookNoprops location={{ pathname: '/cii-digital-logbook' }} />);
      expect(container.children).toMatchSnapshot();
    });
  });