import React from 'react';
import { shallow,mount } from 'enzyme';
import { mockSuccess, mockFailure } from '../../../../util';
import { render } from '@testing-library/react';
import { mockUseApi } from '../../../../util';
import Wrapper, {
  CiiDigitalLogbook,
} from '../../../../../Modules/InventoryReports/CIIReports/CIIDigitalLogbook/CIIDigitalLogbook';
import * as data from '../../../../../../public/cii-digital-logbook.json';
import { apiStates } from '../../../../../Modules/Common/useApi.ts';

describe('CiiDigitalLogbook', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render correctly', () => {
    const component = shallow(<CiiDigitalLogbook location={{}} />);
    component.instance();
  });

  it('should render correctly', () => {
    const initialState= {
      data: [],
      loading: true,
      error: '',
    };
    const component = shallow(
      <CiiDigitalLogbook location={{}} initialState={initialState} />,
    );
    component.instance();
  });

  it('should render correctly', () => {
    const initialState= {
      data,
      loading: true,
      error: '',
    };
    const component = shallow(
      <CiiDigitalLogbook location={{}} initialState={initialState} />,
    );
    component.instance();
  });
  it('should render loading message', () => {
    mockUseApi({ data: {}, state: apiStates.LOADING, error: '' });
    const { container } = render(<CiiDigitalLogbook location={{ pathname: 'cii-digital-logbook' }} />);
    expect(container.children).toMatchSnapshot();
  });

  it('should render report data', () => {
    mockUseApi({ data, state: apiStates.SUCCESS, error: '' });
    const { container } = render(<CiiDigitalLogbook location={{ pathname: '/cii-digital-logbook' }} />);
    expect(container.children).toMatchSnapshot();
  });

  it('should render error message', () => {
    mockUseApi({ data: {}, state: apiStates.ERROR, error: 'network error' });
    const { container } = render(<CiiDigitalLogbook location={{ pathname: '/cii-digital-logbook' }} />);
    expect(container.children).toMatchSnapshot();
  });
});

