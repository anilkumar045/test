import React from 'react';
import { shallow } from 'enzyme';
import { render } from '@testing-library/react';
import {
  mockSuccessts,
  mockFailurets,
  mockPostSuccessts,
  mockPostFailurets,
} from '../../../util';
import Wrapper, {
  CycleCount,
} from '../../../../Modules/InventoryReports/CycleCountReport/CycleCount.tsx';

describe('CycleCountReport', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render loading message', () => {
    mockPostSuccessts({ data: {} });
    mockSuccessts({ data: { data: [{}, {}], header: [] } });
    const { container } = render(
      <CycleCount
        location={{ search: '', pathname: '/cycle-count' }}
      />,
    );
    window.updateData([]);
    expect(container.children).toMatchSnapshot();
  });
  it('should render loading message', () => {
    mockPostFailurets({ data: {} });
    const { container } = render(
      <CycleCount
        location={{ search: '', pathname: '/cycle-count' }}
      />,
    );
    window.updateData([]);
    expect(container.children).toMatchSnapshot();
  });

  it('should render correctly', () => {
    mockSuccessts({ data: { data: [{}, {}], header: [] } });
    const { container } = render(<CycleCount location={{}} />);
    expect(container.children).toMatchSnapshot();
  });

  it('should render correctly', () => {
    mockSuccessts({ data: null });
    const { container } = render(<CycleCount location={{}} />);
    expect(container.children).toMatchSnapshot();
  });

  it('should render correctly', () => {
    mockFailurets('error');
    const { container } = render(<CycleCount location={{}} />);
    expect(container.children).toMatchSnapshot();
  });
});
