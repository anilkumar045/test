import React from 'react';
import { shallow } from 'enzyme';
import '@testing-library/jest-dom/extend-expect';
import { render } from '@testing-library/react';
import Wrapper, {
  AmberVialInventory,
} from '../../../../Modules/InventoryReports/AmberVialInventory/AmberVialInventory.tsx';
import { mockSuccessts, mockFailurets, mockPostSuccessts, mockPostFailurets } from '../../../util';

describe('AmberVialInventory', () => {
  it('should render loading message', () => {
    mockPostSuccessts({data:{}});
    mockSuccessts({ data: { data: [{}, {}], header: [] } });
    const { container } = render(
      <AmberVialInventory location={{search:"",pathname:"/amber-vial-active-inventory"}} />
    );
    window.updateData([]);
    expect(container.children).toMatchSnapshot();
  });
  it('should render loading message', () => {
    mockPostFailurets({data:{}});
    const { container } = render(
      <AmberVialInventory location={{search:"",pathname:"/amber-vial-active-inventory"}} />
    );
    window.updateData([]);
    expect(container.children).toMatchSnapshot();
  });

  it('should render correctly', () => {
    mockSuccessts({ data: { data: [{}, {}], header: [] } });
    const { container } = render(
      <AmberVialInventory location={{}} />,
    );
    expect(container.children).toMatchSnapshot();
  });

  it('should render correctly', () => {
    mockSuccessts({ data: null });
    const { container } = render(
      <AmberVialInventory location={{}} />,
    );
    expect(container.children).toMatchSnapshot();
  });

  it('should render correctly', () => {
    mockFailurets('error');
    const { container } = render(
      <AmberVialInventory location={{}} />,
    );
    expect(container.children).toMatchSnapshot();
  });
});
