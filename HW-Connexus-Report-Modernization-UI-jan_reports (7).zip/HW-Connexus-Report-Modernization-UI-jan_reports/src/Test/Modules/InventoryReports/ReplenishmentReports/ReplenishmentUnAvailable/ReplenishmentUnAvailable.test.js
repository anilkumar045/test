import React from 'react';
import { shallow } from 'enzyme';
import Wrapper, {
  ReplenishmentUnAvailable,
} from '../../../../../Modules/InventoryReports/ReplenishmentReports/ReplenishmentUnAvailable/ReplenishmentUnAvailable';
import { mockSuccess, mockFailure } from '../../../../util';

describe('ReplenishmentUnAvailable', () => {
  const data = {
    storeId: 5545,
    reportDate: '2020-01-01T23:28:56.782Z',
    date: '2020-01-01T23:28:56.782Z',
    appName: 'Connexus Pharmacy System',
    store: 'Sams Pharmacy10-5545',
    reportName: 'Cancel Fill Report',
    fromDate: '2020-04-10T23:28:56.782Z',
    toDate: '2020-04-11T23:28:56.782Z',
    address:
      '5025 LOOP 410 NORTHWEST 5025 TRUTH OR CONSEQUENCE TRU COTulsa OK-74008',
    data: [
      {
        product: 'ABC PLUS TAB',
        ndc: 74312000070,
        totalFills: 14,
        totalFillQty: 196,
        rxNbr: 8809307,
        refills: 'N',
        fillQty: 10,
        onHandQty: 4617,
      },
    ],
  };

  it('should render correctly', () => {
    mockSuccess({ data });
    const component = shallow(
      <ReplenishmentUnAvailable location={{}} />,
    );
    const instance = component.instance();
    expect(instance.state.data).toEqual(data);
  });

  it('should render correctly', () => {
    mockFailure('error');
    const component = shallow(
      <ReplenishmentUnAvailable location={{}} />,
    );
    const instance = component.instance();
    expect(instance.state.error).toEqual('error');
  });

  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render correctly', () => {
    const component = shallow(
      <ReplenishmentUnAvailable location={{}} />,
    );
    component.instance();
  });

  it('should render correctly', () => {
    const component = shallow(
      <ReplenishmentUnAvailable location={{}} />,
    );
    const instance = component.instance();
    instance.setState({ error: 'network error', loading: false });
  });

  it('should render correctly', () => {
    const component = shallow(
      <ReplenishmentUnAvailable location={{}} />,
    );
    const instance = component.instance();
    instance.setState({ data, loading: false });
  });
});
