import React from 'react';
import { shallow } from 'enzyme';
import { render } from '@testing-library/react';
import { mockUseApi } from '../../../util';
import { apiStates } from '../../../../Modules/Common/useApi.ts';
import Wrapper, {
  PatientSummary,
} from '../../../../Modules/Pseudoephedrine/PatientSummaryReport/PatientSummary.tsx';
import * as data from '../../../../../public/patient-summary.json';

describe('PatientSummaryReport', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render loading message', () => {
    mockUseApi({ data: {}, state: apiStates.LOADING, error: '' });
    const { container } = render(<PatientSummary location={{ pathname: '/patient-summary' }} />);
    expect(container.children).toMatchSnapshot();
  });

  it('should render report data', () => {
    mockUseApi({ data, state: apiStates.SUCCESS, error: '' });
    const { container } = render(<PatientSummary location={{ pathname: '/patient-summary' }} />);
    expect(container.children).toMatchSnapshot();
  });

  it('should render error message', () => {
    mockUseApi({ data: {}, state: apiStates.ERROR, error: 'network error' });
    const { container } = render(<PatientSummary location={{ pathname: '/patient-summary' }} />);
    expect(container.children).toMatchSnapshot();
  });
});
