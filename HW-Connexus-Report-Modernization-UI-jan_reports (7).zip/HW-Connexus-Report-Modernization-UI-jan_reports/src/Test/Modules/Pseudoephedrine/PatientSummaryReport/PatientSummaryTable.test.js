import React from 'react';
import { shallow } from 'enzyme';
import PatientSummaryTable from '../../../../Modules/Pseudoephedrine/PatientSummaryReport/PatientSummaryTable.tsx';

describe('PatientSummaryTable', () => {
  it('should render correctly', () => {
    shallow(<PatientSummaryTable data={[]} header={[]} />);
  });

  it('should render result correctly', () => {
    const header = [
      {
        label1: 'Sold Date',
        id1: 'soldDate',
        unique: 1,
      },
      {
        label1: 'Trans Id',
        id1: 'transId',
        unique: 2,
      },
      {
        label1: 'Patient',
        id1: 'patient',
        unique: 3,
      },
      {
        label1: 'Drug',
        id1: 'drug',
        unique: 4,
      },
      {
        label1: 'Qty Pkg',
        id1: 'qtyPkg',
        label2: 'Gram',
        id2: 'gram',
        label3: 'Pack Size',
        id3: 'packSize',
        unique: 5,
      },
      {
        label1: 'Patient ID',
        id1: 'patientId1',
        unique: 6,
      },
      {
        label1: 'Patient ID #',
        id1: 'patientId2',
        unique: 7,
      },
      {
        label1: 'State',
        id1: 'state',
        label2: 'Country',
        id2: 'country',
        unique: 8,
      },
      {
        label1: 'Associate Name',
        id1: 'associateName',
        label2: 'Intials',
        id2: 'intials',
        unique: 9,
      },
    ];
    const data = [
      {
        soldDate: '10/2/2013 9:10:28 AM',
        transId: 2,
        patientName: 'BAGGING, PSE',
        patientAddress: '123 SUDAFED LANE BENTON,AR 72653',
        patientDob: '1/1/1970',
        drug: 'EQ SUPHEDRINE 30MG TAB',
        qtyPkg: '1',
        gram: '0.72',
        packSize: '24',
        patientId1: '',
        patientId2: '',
        state: '',
        country: '',
        associateName: 'TECH USER BARRY',
        intials: 'TUB6789',
        unique: 1,
      },
      {
        soldDate: '10/2/2013 9:37:51 AM',
        transId: 3,
        patientName: 'WALLACE, HEATHER',
        patientAddress: '1/22/1984 123 B LAW, TN38464',
        patientDob: '1/22/1984',
        drug: 'EQ SUPHEDRINE 30MG TAB',
        qtyPkg: '1',
        gram: '0.72',
        packSize: '24',
        patientId1: 'Driver\'s License',
        patientId2: '12345678965421',
        state: 'AR',
        country: '',
        associateName: 'TECH USER BARRY',
        intials: 'TUB6789',
        unique: 2,
      },
      {
        soldDate: '3/4/2014 9:47:05 AM',
        transId: 20,
        patientName: 'BROWN, HOLLI',
        patientAddress: 'SOMEWHERE OVER THE RAINBOW, OH 73505',
        patientDob: '12/26/1987',
        drug: 'EQ SUPHEDRINE 30MG TAB',
        qtyPkg: '1',
        gram: '0.72',
        packSize: '24',
        patientId1: 'Driver\'s License',
        patientId2: '4556464',
        state: 'AZ',
        country: '',
        associateName: 'ATHENA M CORTEZ-PALMER',
        intials: 'AMCORTE',
        unique: 3,
      },
      {
        soldDate: '1/21/2016 1:51:52 PM',
        transId: 234,
        patientName: 'BP, PRASAD',
        patientAddress: 'SD ASD, AS 79989',
        patientDob: '1/1/1980',
        drug: 'ACTIFED 2.5-60MG TAB',
        qtyPkg: '1',
        gram: '1.44',
        packSize: '24',
        patientId1: 'Driver\'s License',
        patientId2: 'ASDFASFDDSAFDSAFDSAF',
        state: 'DC',
        country: 'US',
        associateName: 'RAM WIN',
        intials: 'RWI1111',
        unique: 4,
      },
    ];
    shallow(<PatientSummaryTable data={data} header={header} />);
  });
});
