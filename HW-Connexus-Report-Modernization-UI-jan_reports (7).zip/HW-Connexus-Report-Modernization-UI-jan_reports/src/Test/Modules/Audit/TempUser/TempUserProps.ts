import {
  LocationDescriptorObject,
  LocationListener,
  LocationState,
  Path,
  TransitionPromptHook,
} from 'history';
import { RouteComponentProps } from 'react-router';

const props: RouteComponentProps = {
  history: {
    length: 3,
    action: 'PUSH',
    location: {
      pathname: '/temp-user',
      search:
        '?fromDate=3/29/2020 12:00:00 AM&toDate=11/26/2020 12:00:00 AM',
      state: '',
      hash: '',
      key: 'gasgwd',
    },
    push: (path: Path, state?: LocationState) => {},
    replace: (path: Path, state?: LocationState) => {},
    go: (n: number) => {},
    goBack: () => {},
    goForward: () => {},
    block: (
      prompt?: boolean | string | TransitionPromptHook<LocationState>,
    ) => () => {},
    listen: (listener: LocationListener<LocationState>) => () => {},
    createHref: (location: LocationDescriptorObject<LocationState>) =>
      '',
  },
  location: {
    pathname: '/temp-user',
    search:
      '?fromDate=3/29/2020 12:00:00 AM&toDate=11/26/2020 12:00:00 AM',
    state: '',
    hash: '',
    key: 'gasgwd',
  },
  match: {
    path: '/temp-user',
    url: '/temp-user',
    isExact: true,
    params: {},
  },
};

export default props;
