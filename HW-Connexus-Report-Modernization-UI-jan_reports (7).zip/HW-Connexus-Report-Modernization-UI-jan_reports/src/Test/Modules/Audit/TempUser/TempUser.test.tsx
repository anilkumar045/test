import '@testing-library/jest-dom/extend-expect';
import { render } from '@testing-library/react';
import React from 'react';
import { RouteComponentProps } from 'react-router';
import * as data from '../../../../../public/temp-user.json';
import { TempUser } from '../../../../Modules/Audit/TempUser/TempUser';
import { mockUseApi } from '../../../util';
import props from './TempUserProps';

const renderUI = (props: RouteComponentProps) => {
  return render(<TempUser {...props} />);
};

describe('<TempUser />', () => {
  it('should render loading message', () => {
    mockUseApi({ state: 'LOADING', error: '', data: null });
    const { container } = renderUI(props);
    expect(container.children).toMatchSnapshot();
  });

  it('should render report w/ data', () => {
    mockUseApi({ state: 'SUCCESS', error: '', data });
    const { container } = renderUI(props);
    expect(container.children).toMatchSnapshot();
  });

  it('should render error message', () => {
    mockUseApi({
      state: 'ERROR',
      error: 'There was an error fetching data',
      data: null,
    });
    const { container } = renderUI(props);
    expect(container.children).toMatchSnapshot();
  });
});
