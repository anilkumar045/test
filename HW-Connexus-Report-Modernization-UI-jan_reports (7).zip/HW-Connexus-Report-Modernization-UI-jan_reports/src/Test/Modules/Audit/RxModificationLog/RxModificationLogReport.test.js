import React from 'react';
import axios from 'axios';
import expect from 'expect';
import { shallow, mount, unmount } from 'enzyme';
// import mockAxios from 'axios';
import Wrapper, {
    RxModificationLogReport,
} from '../../../../Modules/Audit/RxModificationLog/RxModificationLog';
import { mockSuccess, mockFailure } from '../../../util';
//import { getApi } from '../../../../Modules/Common/AxiosCalls';
import { API_URL, getConfig } from '../../../../settings';
import * as data from '../../../../../public/rx-modification-log.json';

let component;
beforeEach(() => {
    //global.fetch = jest.fn();
    window.fetch = jest.fn(); //if running browser environment
    component = shallow(<RxModificationLogReport />)
    // component = shallow(<Compliance location={{
    //     pathname: "/compliance",
    //     search: "?nextFillDate=11/14/2020%2012:00:00%20AM&productId=0&prescriberId=0&patientId=0&complianceIndex=N&showPatientIndex=Y&showPrescriberIndex=N&includeDeceasedPatientsData=true"
    //     //search: "?nextFillDate=11/14/2020 12:00:00 AM&productId=0&prescriberId=0&patientId=0&complianceIndex=N&showPatientIndex=Y&showPrescriberIndex=N&includeDeceasedPatientsData=true"
    // }} />);
});

afterEach(() => {
    component.unmount();
    jest.clearAllMocks();
})

describe('Compliance Report', () => {

    it('should render correctly', () => {
        shallow(<Wrapper />);
    });

    it('should render correctly', () => {
        component.instance();
    });

    it('should render correctly', () => {
        const instance = component.instance();
        instance.setState({ error: 'network error', loading: false });
    });

    it('should render correctly', () => {
        const instance = component.instance();
        instance.setState({ data, loading: false });
    });

    it('mockSuccess for Compliance E2E testing', () => {
        mockSuccess({ data });
        const instance = component.instance();
        instance.setState({ data: mockSuccess({ data }), loading: mockSuccess({ data }), error: mockSuccess({ data }) })
        expect(instance.state.data).toEqual(data);
    });

    it('mockFailure for Compliance E2E testing', () => {
        mockFailure('error');
        const instance = component.instance();
        instance.setState({ data: mockFailure('error'), loading: mockFailure('error'), error: mockFailure('error') })
        expect(instance.state.error).toEqual('error');
    });
});
