import React from 'react';
import { shallow } from 'enzyme';
import * as data from '../../../../../public/rx-modification-log.json';
import Wrapper, {
    RxModificationLogReportTable,
} from '../../../../Modules/Audit/RxModificationLog/RxModificationLogTable';
describe('CurrentOnHoldInventorySummaryTable Test', () => {
    it('should render correctly', () => {
        shallow(
            <RxModificationLogReportTable data={[]} header={[]} />,
        );
    });

    it('should render correctly', () => {
        shallow(
            <RxModificationLogReportTable
                data={data.data}
                header={data.headers}
            />,
        );
    });
});
