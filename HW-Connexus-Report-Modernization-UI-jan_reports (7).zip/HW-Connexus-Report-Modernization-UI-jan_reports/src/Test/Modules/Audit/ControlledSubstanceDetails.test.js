import React from 'react';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import { ControlledSubstanceDetails } from '../../../Modules/Audit/ControlledSubstanceDetails.tsx';
import { mockSuccess, mockFailure } from '../../util';
import * as data from '../../../../public/controlled-substance-details.json';

describe('ControlledSubstanceDetails', () => {
  it('should render loading message', () => {
    const { container } = render(<ControlledSubstanceDetails location={{}} />);
    expect(container.children).toMatchSnapshot();
  });

  it('should render report w/ data', () => {
    mockSuccess({ data });
    const { container } = render(<ControlledSubstanceDetails location={{}} />);
    expect(container.children).toMatchSnapshot();
  });

  it('should render error message', () => {
    mockFailure('error');
    const { container } = render(<ControlledSubstanceDetails location={{}} />);
    expect(container.children).toMatchSnapshot();
  });
});
