import React from 'react';
import { shallow } from 'enzyme';
import Table from '../../../../Modules/RxReports/WaitForDrugOrder/Table';
import * as data from '../../../../../public/wait-for-drug-order.json';

describe('WaitForDrugOrder', () => {
  it('should render correctly', () => {
    shallow(<Table data={[]} header={[]} />);
  });

  it('should render correctly', () => {
    shallow(
      <Table data={data} header={data.header} id="reportTable" />,
    );
  });
});
