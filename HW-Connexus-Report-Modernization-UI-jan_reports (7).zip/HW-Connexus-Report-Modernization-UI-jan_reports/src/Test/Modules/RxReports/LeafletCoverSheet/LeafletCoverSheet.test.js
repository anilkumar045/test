import React from 'react';
import { shallow } from 'enzyme';
import Wrapper, {
  LeafletCoverSheet,
} from '../../../../Modules/RxReports/LeafletCoverSheet/LeafletCoverSheet';
import { mockSuccess, mockFailure } from '../../../util';

describe('LeafletCoverSheet', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render correctly', () => {
    const component = shallow(<LeafletCoverSheet location={{}} />);
    component.instance();
  });

  it('should render correctly', () => {
    const component = shallow(<LeafletCoverSheet location={{}} />);
    const instance = component.instance();
    instance.setState({ error: 'network error', loading: false });
  });

  it('should render correctly', () => {
    const data = {
      storeId: 5545,
      date: '10/09/2020',
      appName: 'Connexus Pharmacy System',
      store: "Sam's Pharmacy10-5545",
      reportName: 'Leaflet Cover Sheet Print By Language',
      dateRange: {
        from: '09/09/2020',
        to: '10/01/2020',
      },
      header: [
        {
          label: 'Language',
          id: 'language',
        },
        {
          label: 'Count',
          id: 'count',
        },
        {
          label: '% of Total',
          id: 'percentage',
        },
      ],
      data: [
        {
          language: 'English',
          count: 9,
          percentage: '100.00',
        },
      ],
    };
    const component = shallow(<LeafletCoverSheet location={{}} />);
    const instance = component.instance();
    instance.setState({ data, loading: false });
  });

  it('should render correctly', () => {
    mockSuccess({ data: { dateRange: {}, data: [{}, {}] } });
    const component = shallow(<LeafletCoverSheet location={{}} />);
    const instance = component.instance();
    expect(instance.state.data).toEqual({
      dateRange: {},
      data: [{}, {}],
    });
  });

  it('should render correctly', () => {
    mockFailure('error');
    const component = shallow(<LeafletCoverSheet location={{}} />);
    const instance = component.instance();
    expect(instance.state.error).toEqual('error');
  });
});
