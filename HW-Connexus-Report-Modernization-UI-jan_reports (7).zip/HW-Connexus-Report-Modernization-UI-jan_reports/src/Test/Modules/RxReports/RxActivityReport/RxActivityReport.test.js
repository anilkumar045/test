import React from 'react';
import { shallow, mount } from 'enzyme';
import Wrapper, {
  RxActivityReport,
} from '../../../../Modules/RxReports/RxActivityReport/RxActivityReport.tsx';
import { mockSuccessts, mockFailurets } from '../../../util';

describe('RxActivityReport', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render correctly', () => {
    mockSuccessts({ data: { data: [{}, {}], header: [] } });
    const component = mount(<RxActivityReport location={{}} />);
    component.update();
  });

  it('should render correctly', () => {
    mockSuccessts({ data: null });
    const component = mount(<RxActivityReport location={{}} />);
    component.update();
  });

  it('should render correctly', () => {
    mockFailurets('error');
    const component = mount(<RxActivityReport location={{}} />);
    component.update();
  });
});
