import React from 'react';
import { shallow } from 'enzyme';
import Table, { setTableHeader, setTableBody } from '../../../../Modules/RxReports/Compliance/Table';

describe('RxReport', () => {
  it('should render correctly', () => {
    shallow(<Table data={[]} header={[]} />);
  });
  it('should render correctly', () => {

    expect(setTableHeader("DrugName", "true")).toBe("Patient");
    expect(setTableHeader("Qty", "false")).toBe("");
    const data = {
      drugName: "drugName",
      quantity: "8"
    }
    expect(setTableBody(data, "quantity", "false")).toBe("");

  });

  it('should render correctly', () => {
    const header = [
      {
        label: 'Rx',
        id: 'Rx',
      },
      {
        label: 'PatientName',
        id: 'PatientName',
      },
      {
        label: 'FillDate',
        id: 'FillDate',
      },
      {
        label: 'Drug',
        id: 'Drug',
      },
      {
        label: 'Quantity',
        id: 'Quantity',
      },
      {
        label: 'DAW',
        id: 'DAW',
      },
      {
        label: 'UserId',
        id: 'UserId',
      },
      {
        label: 'Date/Time',
        id: 'Date/Time',
      },
    ];
    shallow(<Table data={[{}]} header={header} drug=''/>);
  });
});
