import React from 'react';
import { shallow } from 'enzyme';
import Wrapper, {
  CentralFillPerformance,
} from '../../../../Modules/RxReports/CentralFillPerformance/CentralFillPerformance';
import { mockSuccess, mockFailure } from '../../../util';

describe('FourPointCheck', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render correctly', () => {
    const component = shallow(
      <CentralFillPerformance location={{}} />,
    );
    component.instance();
  });

  it('should render correctly', () => {
    const component = shallow(
      <CentralFillPerformance location={{}} />,
    );
    const instance = component.instance();
    instance.setState({ error: 'network error', loading: false });
  });

  it('should render correctly', () => {
    const data = {
      data: {
        details: [
          {
            date: '09/09/2020',
            fillsFldInStr: 0,
            fillsFilledInCentrlFil: 0,
            prcntInCentrl: 0,
            unique: 1,
          },
        ],
        totlFillInStr: 0,
        totlFillInCentrlFill: 0,
        totlprcntInCntrl: 0,
      },
    };
    const component = shallow(
      <CentralFillPerformance location={{}} />,
    );
    const instance = component.instance();
    instance.setState({ data, loading: false });
  });
});

it('should render correctly', () => {
  mockSuccess({ data: { data: [{}, {}] } });
  const component = shallow(<CentralFillPerformance location={{}} />);
  const instance = component.instance();
  expect(instance.state.data).toEqual({ data: [{}, {}] });
});

it('should render correctly', () => {
  mockFailure('error');
  const component = shallow(<CentralFillPerformance location={{}} />);
  const instance = component.instance();
  expect(instance.state.error).toEqual('error');
});
