import React from 'react';
import { shallow } from 'enzyme';
import Table from '../../../../Modules/RxReports/CancelFill/CancelFillTable';

describe('RxReport', () => {
  it('should render correctly', () => {
    shallow(<Table data={[]} header={[]} />);
  });

  it('should render correctly', () => {
    const header = [
      {
        label: 'RX #',
        id: 'rxNbr',
      },
      {
        label: 'Patient',
        id: 'patient',
      },
      {
        label: 'Fill Date',
        id: 'fillDate',
      },
      {
        label: 'Cancel Date',
        id: 'cancelDate',
      },
      {
        label: 'Fill Qty',
        id: 'fillQty',
      },
      {
        label: 'Drug',
        id: 'drug',
      },
      {
        label: 'Reason',
        id: 'reason',
      },
      {
        label: 'SOLD Pay',
        id: 'soldPay',
      },
      {
        label: 'User Id',
        id: 'userId',
      },
    ];
    const data = [
      {
        rxNbr: 2202652,
        patient: 'TEST,REV',
        fillDate: '2020-04-11T23:28:56.782Z',
        cancelDate: '2020-04-11T23:28:56.782Z',
        fillQty: 30,
        drug: 'OxyCODONE 15MG TAB',
        reason: 'Patient Wants Rx Back',
        soldPay: 'N',
        userId: 'VN50D46',
      },
    ];
    shallow(<Table data={data} header={header} />);
  });
});
