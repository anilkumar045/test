import React from 'react';
import { render } from '@testing-library/react';
import { shallow } from 'enzyme';
import '@testing-library/jest-dom/extend-expect';
import {
  FourPointCheck,
} from '../../../Modules/FourPointCheck/FourPointCheck.tsx';
import Table from '../../../Modules/FourPointCheck/Table.tsx';

import { mockSuccessts, mockFailurets } from '../../util';
import * as data from '../../../../public/4-point-check.json';

describe('FourPointCheck', () => {
  it('should render loading message', () => {
    const { container } = render(<FourPointCheck location={{}} />);
    expect(container.children).toMatchSnapshot();
  });

  it('should render correctly', () => {
    mockSuccessts(data);
    const { container } = render(
      <FourPointCheck
        location={{ pathname: '/4-point-check-report' }}
      />,
    );
    expect(container.children).toMatchSnapshot();
  });
  it('should render correctly', () => {
    mockSuccessts(data);
    const { container } = render(
      <FourPointCheck
        location={{ pathname: '/daily-visual-verify' }}
      />,
    );
    expect(container.children).toMatchSnapshot();
  });
  it('should render correctly', () => {
    mockFailurets('error');
    const { container } = render(<FourPointCheck location={{}} />);
    expect(container.children).toMatchSnapshot();
  });
});

describe('FourPTRTable', () => {
  it('should render correctly', () => {
    shallow(<Table data={[]} header={[]} />);
  });

  it('should render correctly', () => {
    const header = [
      {
        label: "Pharmacist's Name",
        id: 'pharmacistName',
      },
      {
        label: 'User Id',
        id: 'userId',
      },
      {
        label: 'Store Number',
        id: 'storeNumber',
      },
      {
        label:
          'Number Of 4PT Corrections (Maximum of one RX per User One Rx may have been corrected by multiple users)',
        id: 'numberOfCorrection',
      },
    ];
    shallow(<Table data={[{}]} header={header} />);
  });
});
