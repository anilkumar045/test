import React from 'react';
import { shallow } from 'enzyme';
import Table from '../../../Modules/FourPointCheck/Table.tsx';

describe('DailyVisualVerify', () => {
  it('should render correctly', () => {
    shallow(<Table data={[]} header={[]} />);
  });

  it('should render correctly', () => {
    const header = [
      {
        label: 'RX #',
        id: 'rx',
      },
      {
        label: 'Patient Name',
        id: 'patientName',
      },
      {
        label: 'Fill Date',
        id: 'fillDt',
      },
      {
        label: 'Drug',
        id: 'drug',
      },
      {
        label: 'Qty',
        id: 'qty',
      },
      {
        label: 'UserId',
        id: 'userId',
      },
      {
        label: 'Date/Time',
        id: 'dateTime',
      },
    ];
    shallow(<Table data={[{}]} header={header} />);
  });
});
