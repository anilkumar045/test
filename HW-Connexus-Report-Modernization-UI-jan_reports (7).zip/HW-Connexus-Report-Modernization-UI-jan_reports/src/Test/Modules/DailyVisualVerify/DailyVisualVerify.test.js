import React from 'react';
import { shallow } from 'enzyme';
import Wrapper, {
  FourPointCheck,
} from '../../../Modules/FourPointCheck/FourPointCheck.tsx';
import { mockSuccess, mockFailure } from '../../util';

describe('DailyVisualVerify', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render correctly', () => {
    const data = {
      dates: [
        {
          date: '03/03/2020',
          pharmacists: [
            {
              pharmacistName: 'Rama Sundaram - vendor',
              data: [
                {
                  rx: 4405624,
                  patientName: 'PMP,RAMANS',
                  fillDt: '03/03/2020',
                  drug: 'BUTISOL SOD 30MG TAB',
                  qty: '4',
                  userId: 'VN509PY',
                  dateTime: '03/03/2020 12:47:06 AM',
                },
              ],
            },
            {
              pharmacistName: 'Seth Jaffer - vendor',
              data: [
                {
                  rx: 6635675,
                  patientName: 'SETH TEST15',
                  fillDt: '03/03/2020',
                  drug: 'RANDITINE 150MG TAB',
                  qty: '30',
                  userId: 'VN50ICV',
                  dateTime: '03/03/2020 09:48:33 AM',
                },
              ],
            },
          ],
        },
      ],
    };
    mockSuccess({ data });
    const component = shallow(<FourPointCheck location={{}} />);
    const instance = component.instance();
    expect(instance.state.data).toEqual(data);
  });
  it('should render correctly', () => {
    const data = {
      dates: [
        {
          date: '03/03/2020',
          pharmacists: [
            {
              pharmacistName: 'Rama Sundaram - vendor',
              data: [
                {
                  rx: 4405624,
                  patientName: 'PMP,RAMANS',
                  fillDt: '03/03/2020',
                  drug: 'BUTISOL SOD 30MG TAB',
                  qty: '4',
                  userId: 'VN509PY',
                  dateTime: '03/03/2020 12:47:06 AM',
                },
              ],
            },
            {
              pharmacistName: 'Seth Jaffer - vendor',
              data: [
                {
                  rx: 6635675,
                  patientName: 'SETH TEST15',
                  fillDt: '03/03/2020',
                  drug: 'RANDITINE 150MG TAB',
                  qty: '30',
                  userId: 'VN50ICV',
                  dateTime: '03/03/2020 09:48:33 AM',
                },
              ],
            },
          ],
        },
      ],
    };
    mockSuccess({ data });
    const component = shallow(<FourPointCheck location={{}} />);
    const instance = component.instance();
    expect(instance.state.data).toEqual(data);
  });

  it('should render correctly', () => {
    mockFailure('error');
    const component = shallow(<FourPointCheck location={{}} />);
    const instance = component.instance();
    expect(instance.state.error).toEqual('error');
  });

  it('should render correctly', () => {
    const component = shallow(<FourPointCheck location={{}} />);
    const instance = component.instance();
    instance.setState({ error: 'network error', loading: false });
  });

  it('should render correctly', () => {
    const data = {
      dates: [
        {
          date: '03/03/2020',
          pharmacists: [
            {
              pharmacistName: 'Rama Sundaram - vendor',
              data: [
                {
                  rx: 4405624,
                  patientName: 'PMP,RAMANS',
                  fillDt: '03/03/2020',
                  drug: 'BUTISOL SOD 30MG TAB',
                  qty: '4',
                  userId: 'VN509PY',
                  dateTime: '03/03/2020 12:47:06 AM',
                },
              ],
            },
            {
              pharmacistName: 'Seth Jaffer - vendor',
              data: [
                {
                  rx: 6635675,
                  patientName: 'SETH TEST15',
                  fillDt: '03/03/2020',
                  drug: 'RANDITINE 150MG TAB',
                  qty: '30',
                  userId: 'VN50ICV',
                  dateTime: '03/03/2020 09:48:33 AM',
                },
              ],
            },
          ],
        },
      ],
    };
    const component = shallow(<FourPointCheck location={{}} />);
    const instance = component.instance();
    instance.setState({ data, loading: false });
  });
});
