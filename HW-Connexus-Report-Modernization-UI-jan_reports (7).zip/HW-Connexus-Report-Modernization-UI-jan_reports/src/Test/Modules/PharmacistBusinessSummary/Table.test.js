import React from 'react';
import { shallow } from 'enzyme';
import Table from '../../../Modules/PharmacistBusinessSummary/Table';

describe('RxReport', () => {
  it('should render correctly', () => {
    shallow(<Table data={[]} header={[]} />);
  });

  it('should render correctly', () => {
    const header = [
      {
        label: 'Payroll Summary (Hourly Associate)',
        id: 'payrollSumm',
        type: null,
      },
      {
        label: 'Total',
        id: 'total',
        type: 'TOTAL',
      },
      {
        label: '% of Sales',
        id: 'percSales1',
        type: 'TOTAL',
      },
      {
        label: 'WTD',
        id: 'wtd',
        type: 'Hourly',
      },
      {
        label: '% of Sales',
        id: 'percSales2',
        type: 'Hourly',
      },
    ];
    const data = [
      {
        payrollSumm: 'SAT',
        total: '0.00',
        percSales1: '0.00',
        wtd: '0.00',
        percSales2: '0.00',
        type: 'Weekend',
      },
    ];
    shallow(
      <Table data={data} header={header} id="userProductivity" />,
    );
  });
});
