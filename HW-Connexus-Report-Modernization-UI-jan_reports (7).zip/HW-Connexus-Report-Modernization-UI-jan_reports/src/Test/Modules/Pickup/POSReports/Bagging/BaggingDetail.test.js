import React from 'react';
import { shallow } from 'enzyme';
import Wrapper, {
  BaggingDetail,
} from '../../../../../Modules/Pickup/POSReports/Bagging/BaggingDetail';
import { mockSuccess, mockFailure } from '../../../../util';

const data = {
  storeId: 5545,
  reportDate: '11/04/2020',
  appName: 'Connexus Pharmacy System',
  store: 'Wal-Mart Pharmacy10-5533',
  reportName: 'BAGGING DETAIL REPORT',
  dateFrom: 'From : 09/09/2020',
  dateTo: 'To 10/09/2020',
  address: '5025 LOOP 410 NORTH 5025',
  detail: 'TRUTH OR CONSEQUENCE TRU COTulsa OK - 74008',
  header: [
    {
      id: 'patient',
      label: 'Patien',
    },
    {
      id: 'rx',
      label: 'Rx ',
    },
    {
      id: 'qty',
      label: 'Qt',
    },
    {
      id: 'dispensedItem',
      label: 'Dispensed Ite',
    },
    {
      id: 'colorNmber',
      label: 'Bag Color/Numbe',
    },
    {
      id: 'date',
      label: 'Bag Dat',
    },
    {
      id: 'userid',
      label: 'User I',
    },
    {
      id: 'assocName',
      label: 'Assoc Nam',
    },
    {
      id: 'jobClass',
      label: 'Assoc Job Clas',
    },
    {
      id: 'timeStart',
      label: 'Time Star',
    },
    {
      id: 'timeEnd',
      label: 'Time En',
    },
  ],
  data: [
    {
      unique: 1,
      patient: 'Test, John',
      rx: 4405787,
      qty: 10,
      dispensedItem: 'BUTISOL SOD 300MG TAB',
      colorNmber: 'PU 1742',
      date: '10/30/2020',
      userid: 'VN509PY',
      assocName: 'Rama Samurdrala - Vendor',
      jobClass: 'Non-Pharmacist',
      timeStart: '10/13/2020/ 06:24:47 AM',
      timeEnd: '10/14/2020/ 06:24:47 A',
    },
    {
      unique: 4405786,
      patient: 'Davd, John',
      rx: 4405786,
      qty: 10,
      dispensedItem: 'BUTISOL SOD 300MG TAB',
      colorNmber: 'PU 1742',
      date: '10/30/2020',
      userid: 'VN509PY',
      assocName: 'Rama Samurdrala - Vendor',
      jobClass: 'Non-Pharmacist',
      timeStart: '10/13/2020/ 06:24:47 AM',
      timeEnd: '10/14/2020/ 06:24:47 A',
    },
    {
      unique: 4405788,
      patient: 'Test, John',
      rx: 4405788,
      qty: 10,
      dispensedItem: 'BUTISOL SOD 300MG TAB',
      colorNmber: 'PU 1742',
      date: '10/30/2020',
      userid: 'VN509PY',
      assocName: 'Rama Samurdrala - Vendor',
      jobClass: 'Non-Pharmacist',
      timeStart: '10/13/2020/ 06:24:47 AM',
      timeEnd: '10/14/2020/ 06:24:47 A',
    },
    {
      unique: 4405789,
      patient: 'Test, John',
      rx: 4405789,
      qty: 10,
      dispensedItem: 'BUTISOL SOD 300MG TAB',
      colorNmber: 'PU 1742',
      date: '10/30/2020',
      userid: 'VN509PY',
      assocName: 'Rama Samurdrala - Vendor',
      jobClass: 'Non-Pharmacist',
      timeStart: '10/13/2020/ 06:24:47 AM',
      timeEnd: '10/14/2020/ 06:24:47 A',
    },
    {
      unique: 4405189,
      patient: 'Test, John',
      rx: 4405189,
      qty: 10,
      dispensedItem: 'BUTISOL SOD 300MG TAB',
      colorNmber: 'PU 1742',
      date: '10/30/2020',
      userid: 'VN509PQ',
      assocName: 'Rama Samurdrala - Vendor',
      jobClass: 'Pharmacist',
      timeStart: '10/13/2020/ 06:24:47 AM',
      timeEnd: '10/14/2020/ 06:24:47 A',
    },
  ],
};

describe('BaggingDetail', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render correctly', () => {
    const component = shallow(<BaggingDetail location={{}} />);
    component.instance();
  });

  it('should render correctly', () => {
    const component = shallow(<BaggingDetail location={{}} />);
    const instance = component.instance();
    instance.setState({ error: 'network error', loading: false });
  });

  it('should render correctly', () => {
    const component = shallow(<BaggingDetail location={{}} />);
    const instance = component.instance();
    instance.setState({ data, loading: false });
  });

  it('should render correctly', () => {
    mockSuccess({ data });
    const component = shallow(<BaggingDetail location={{}} />);
    const instance = component.instance();
    expect(instance.state.data).toEqual(data);
  });

  it('should render correctly', () => {
    mockFailure('error');
    const component = shallow(<BaggingDetail location={{}} />);
    const instance = component.instance();
    expect(instance.state.error).toEqual('error');
  });
});
