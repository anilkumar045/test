import React from 'react';
import { shallow } from 'enzyme';
import BaggingMain from '../../../../../Modules/Pickup/POSReports/Bagging/BaggingMain';

describe('BaggingMain', () => {

    it('should render correctly', () => {
        const component = shallow(<BaggingMain location={{}} />);
        component.instance();
    });

    it('should render correctly', () => {
        shallow(<BaggingMain location={{}} />);
    });
});
