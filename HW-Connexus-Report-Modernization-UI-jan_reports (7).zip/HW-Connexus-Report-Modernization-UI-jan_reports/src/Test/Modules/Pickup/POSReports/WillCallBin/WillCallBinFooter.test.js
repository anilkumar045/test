import '@testing-library/jest-dom/extend-expect';
import { render } from '@testing-library/react';
import React from 'react';
import { shallow } from 'enzyme';
import WillCallBinFooter from '../../../../../Modules/Pickup/POSReports/WillCallBin/WillCallBinFooter.tsx';

const footerData = {
  footerData: {
    totalUnsoldPres: 0,
    totalUnsoldOrders: 0,
    totalUnsoldPresCost: 0,
    totalUnsoldPresPrice: 0,
    totalNewPres: 0,
    totalRefillPres: 0,
    totalPresUsingMess: 0,
  },
};
describe('WCBDetailedTable', () => {
  it('should render correctly', () => {
    shallow(<WillCallBinFooter props={footerData} />);
  });

  it('should render w/ data', () => {
    const { container } = render(
      <WillCallBinFooter props={footerData} />,
    );
    expect(container.children).toMatchSnapshot();
  });
});
