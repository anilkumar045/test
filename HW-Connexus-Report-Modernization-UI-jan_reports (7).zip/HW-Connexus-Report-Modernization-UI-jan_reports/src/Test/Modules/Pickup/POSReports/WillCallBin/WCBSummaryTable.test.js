import '@testing-library/jest-dom/extend-expect';
import { render } from '@testing-library/react';
import React from 'react';
import { shallow } from 'enzyme';
import WCBSummaryTable from '../../../../../Modules/Pickup/POSReports/WillCallBin/WCBSummaryTable.tsx';
import * as data from '../../../../../../public/will-call-bin.json';

describe('WCBSummaryTable', () => {
  it('should render correctly', () => {
    shallow(<WCBSummaryTable data={[]} header={[]} />);
  });

  it('should render w/ data', () => {
    const { container } = render(
      <WCBSummaryTable
        data={data.data}
        header={data.header}
        footer={data.footer}
      />,
    );
    expect(container.children).toMatchSnapshot();
  });
});
