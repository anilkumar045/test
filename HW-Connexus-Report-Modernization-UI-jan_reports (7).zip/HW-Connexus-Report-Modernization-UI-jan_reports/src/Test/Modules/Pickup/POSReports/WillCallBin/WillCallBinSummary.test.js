import '@testing-library/jest-dom/extend-expect';
import { render } from '@testing-library/react';
import React from 'react';
import { WillCallBinSummary } from '../../../../../Modules/Pickup/POSReports/WillCallBin/WillCallBinSummary.tsx';

const state = {
  data: {
    storeId: NaN,
    reportDate: '',
    appName: '',
    store: '',
    reportName: '',
    header: [],
    data: [],
  },
  footerData: {
    totalUnsoldPres: 0,
    totalUnsoldOrders: 0,
    totalUnsoldPresCost: 0,
    totalUnsoldPresPrice: 0,
    totalNewPres: 0,
    totalRefillPres: 0,
    totalPresUsingMess: 0,
  },
  summaryTableData: [],
};

describe('WillCallBinSummary', () => {
  it('should render correctly', () => {
    const { container } = render(
      <WillCallBinSummary state={state} />,
    );
    expect(container.children).toMatchSnapshot();
  });
});
