import '@testing-library/jest-dom/extend-expect';
import { render } from '@testing-library/react';
import React from 'react';
import { shallow } from 'enzyme';
import WCBDetailedTable from '../../../../../Modules/Pickup/POSReports/WillCallBin/WCBDetailedTable.tsx';
import * as data from '../../../../../../public/will-call-bin.json';

describe('WCBDetailedTable', () => {
  it('should render correctly', () => {
    shallow(<WCBDetailedTable data={[]} header={[]} />);
  });

  it('should render w/ data', () => {
    const { container } = render(
      <WCBDetailedTable
        data={data.data}
        header={data.header}
        footer={data.footer}
      />,
    );
    expect(container.children).toMatchSnapshot();
  });
});
