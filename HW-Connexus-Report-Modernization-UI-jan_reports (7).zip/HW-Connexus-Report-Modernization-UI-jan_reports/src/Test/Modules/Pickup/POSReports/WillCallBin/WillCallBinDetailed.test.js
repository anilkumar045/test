import '@testing-library/jest-dom/extend-expect';
import { render } from '@testing-library/react';
import React from 'react';
import { WillCallBinDetailed } from '../../../../../Modules/Pickup/POSReports/WillCallBin/WillCallBinDetailed.tsx';

const state = {
  data: {
    storeId: NaN,
    reportDate: '',
    appName: '',
    store: '',
    reportName: '',
    header: [],
    data: [],
  },
  footerData: {
    totalUnsoldPres: 0,
    totalUnsoldOrders: 0,
    totalUnsoldPresCost: 0,
    totalUnsoldPresPrice: 0,
    totalNewPres: 0,
    totalRefillPres: 0,
    totalPresUsingMess: 0,
  },
  notes: {
    isWarning: false,
    isLockout: false,
    wasNotified: false,
    isEnrolled: false,
    incompleteScripts: false,
  },
};

describe('WillCallBinDetailed', () => {
  it('should render correctly', () => {
    const { container } = render(<WillCallBinDetailed state={state} />);
    expect(container.children).toMatchSnapshot();
  });
});
