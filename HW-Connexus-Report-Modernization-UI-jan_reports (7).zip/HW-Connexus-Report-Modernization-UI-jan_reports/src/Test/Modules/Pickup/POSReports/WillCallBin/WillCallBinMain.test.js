import '@testing-library/jest-dom/extend-expect';
import { render } from '@testing-library/react';
import { shallow } from 'enzyme';
import React from 'react';
import * as data from '../../../../../../public/will-call-bin.json';
import PrintWrapper, {
  WillCallBinMain,
} from '../../../../../Modules/Pickup/POSReports/WillCallBin/WillCallBinMain.tsx';
import { mockFailure, mockSuccess } from '../../../../util';

describe('WillCallBinMain', () => {
  it('should render Print Wrapper correctly', () => {
    shallow(<PrintWrapper />);
  });

  it('should render loading message', () => {
    const { container } = render(<WillCallBinMain location={{}} />);
    expect(container.children).toMatchSnapshot();
  });

  it('should render Detail report w/ data', () => {
    mockSuccess({ data });
    const { container } = render(
      <WillCallBinMain
        location={{
          search:
            '?fromDate=11/6/2020 12:00:00 AM&toDate=11/20/2020 12:00:00 AM&isIncludeAll=False&patientId=103088&mdsFamId=148033&prescriberId=0&sortBy=Blank&excludeReadyReminderRxs=False&isCompound=False&isSummaryReport=False&isDetailedReport=True&sortLevel1=Patient&sortLevel2=Qty&sortLevel3=Color&storeId=5533',
        }}
      />,
    );
    expect(
      container.firstChild.firstChild.lastChild.lastChild.textContent,
    ).toMatch('WILL CALL BIN DETAIL REPORT');
    expect(container.children).toMatchSnapshot();
  });

  it('should render Summary report w/ data', () => {
    mockSuccess({ data });
    const { container } = render(
      <WillCallBinMain
        location={{
          search:
            '?fromDate=11/6/2020 12:00:00 AM&toDate=11/20/2020 12:00:00 AM&isIncludeAll=False&patientId=103088&mdsFamId=148033&prescriberId=0&sortBy=Blank&excludeReadyReminderRxs=False&isCompound=False&isSummaryReport=True&isDetailedReport=False&sortLevel1=Patient&sortLevel2=Qty&sortLevel3=Color&storeId=5533',
        }}
      />,
    );
    expect(
      container.firstChild.firstChild.lastChild.lastChild.textContent,
    ).toMatch('WILL CALL BIN SUMMARY REPORT');
    expect(container.children).toMatchSnapshot();
  });

  it('should render error message', () => {
    mockFailure('error');
    const { container } = render(<WillCallBinMain location={{}} />);
    expect(container.children).toMatchSnapshot();
  });
});
