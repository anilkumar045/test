import React from 'react';
import Wrapper, {
    OrderCompletionPerformance,
} from '../../../../Modules/DailyReports/OrderCompletionPerformance/OrderCompletionPerformance';
import { mockUseApi } from '../../../util';
import * as data from '../../../../../public/order-completion-performance.json';
import { render } from '@testing-library/react';
import { shallow } from 'enzyme';
import { apiStates } from '../../../../Modules/Common/useApi.ts';

describe('OrderCompletionPerformance', () => {

  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

    it('should render loading message', () => {
      mockUseApi({ data: {}, state: apiStates.LOADING, error: '' });
    const { container } = render(<OrderCompletionPerformance location={{}} />);
    expect(container.children).toMatchSnapshot();
  });
  it('should render report w/ data', () => {
    mockUseApi({ data, state: apiStates.SUCCESS, error: '' });
   const { container } = render(<OrderCompletionPerformance location={{}} />);
    expect(container.children).toMatchSnapshot();
  });

  it('should render error message', () => {
    mockUseApi({ data: {}, state: apiStates.ERROR, error: 'network error' });
    const { container } = render(<OrderCompletionPerformance location={{}} />);
    expect(container.children).toMatchSnapshot();
  });
});