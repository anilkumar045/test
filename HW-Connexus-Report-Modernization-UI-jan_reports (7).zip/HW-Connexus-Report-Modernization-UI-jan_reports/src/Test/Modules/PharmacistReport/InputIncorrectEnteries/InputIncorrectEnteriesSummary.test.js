import React from 'react';
import { shallow } from 'enzyme';
import { render } from '@testing-library/react';
import { mockSuccessts, mockFailurets } from '../../../util';
import * as data from '../../../../../public/input-incorrect-enteries-summary.json';
import Wrapper, {
  InputIncorrectEnteriesSummary,
} from '../../../../Modules/PharmacistReport/InputIncorrectEnteries/InputIncorrectEnteriesSummary';

describe('InputIncorrectEnteriesSummary', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render loading message', () => {
    const { container } = render(<InputIncorrectEnteriesSummary location={{ pathname: '/input-incorrect-enteries' }} />);
    expect(container.children).toMatchSnapshot();
  });

  it('should render report data', () => {
    mockSuccessts({ data });
    const { container } = render(<InputIncorrectEnteriesSummary location={{ pathname: '/input-incorrect-enteries' }} />);
    expect(container.children).toMatchSnapshot();
  });

  it('should render error message', () => {
    mockFailurets('error');
    const { container } = render(<InputIncorrectEnteriesSummary location={{ pathname: '/input-incorrect-enteries' }} />);
    expect(container.children).toMatchSnapshot();
  });

});





