import React from 'react';
import { shallow } from 'enzyme';
import Table from '../../../../Modules/PharmacistReport/InputIncorrectEnteries/InputIncorrectTable.tsx';

describe('RxReport', () => {
  it('should render correctly', () => {
    shallow(<Table data={[]} header={[]} />);
  });

  it('should render correctly', () => {
    const header = [
      {
        label: 'Rx',
        id: 'Rx',
      },
      {
        label: 'PatientName',
        id: 'PatientName',
      },
      {
        label: 'FillDate',
        id: 'FillDate',
      },
      {
        label: 'Drug',
        id: 'Drug',
      },
      {
        label: 'Quantity',
        id: 'Quantity',
      },
      {
        label: 'DAW',
        id: 'DAW',
      },
      {
        label: 'UserId',
        id: 'UserId',
      },
      {
        label: 'Date/Time',
        id: 'Date/Time',
      },
    ];
    shallow(<Table data={[]} header={header} />);
  });

  it('should render correctly', () => {
    const header = [
      {
        label: 'PatientName',
        id: 'PatientName',
      },
      {
        label: 'FillDate',
        id: 'FillDate',
      },
      {
        label: 'Address',
        id: 'Address',
      },
    ];
    const data = [{
      PatientName: 'John',
      FillDate: '19/12/2020',
      Address: 'New York',
    }];
    const totalExist = true;
    const totalValue = 1;
    const halfWidth = true;
    const tableHeader = true;
    shallow(<Table data={data} header={header} tableHeader={tableHeader} totalExist={totalExist} totalValue={totalValue} halfWidth={halfWidth} />);
  });

  it('should render correctly', () => {
    const header = [
      {
        label: 'PatientName',
        id: 'PatientName',
      },
      {
        label: 'FillDate',
        id: 'FillDate',
      },
      {
        label: 'Address',
        id: 'Address',
      },
    ];
    const data = [{
      PatientName: 'John',
      FillDate: '19/12/2020',
      Address: 'New York',
    }];
    const totalExist = true;
    const halfWidth = true;
    shallow(<Table data={data} header={header} totalExist={totalExist} halfWidth={halfWidth} />);
  });
});
