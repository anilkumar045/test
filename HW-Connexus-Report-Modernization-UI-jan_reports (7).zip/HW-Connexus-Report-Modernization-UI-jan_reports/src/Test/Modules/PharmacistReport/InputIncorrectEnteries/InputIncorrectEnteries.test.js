import React from 'react';
import { shallow } from 'enzyme';
import { render } from '@testing-library/react';
import { mockSuccessts, mockFailurets } from '../../../util';
import * as data from '../../../../../public/input-incorrect-enteries-detailed.json';
import Wrapper, {
  InputIncorrectEnteriesDetailed,
} from '../../../../Modules/PharmacistReport/InputIncorrectEnteries/InputIncorrectEnteriesDetailed';

describe('InputIncorrectEnteriesDetailed', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render loading message', () => {
    const { container } = render(<InputIncorrectEnteriesDetailed location={{ pathname: '/input-incorrect-enteries' }} />);
    expect(container.children).toMatchSnapshot();
  });

  it('should render report data', () => {
    mockSuccessts({ data });
    const { container } = render(<InputIncorrectEnteriesDetailed location={{ pathname: '/input-incorrect-enteries' }} />);
    expect(container.children).toMatchSnapshot();
  });

  it('should render error message', () => {
    mockFailurets('error');
    const { container } = render(<InputIncorrectEnteriesDetailed location={{ pathname: '/input-incorrect-enteries' }} />);
    expect(container.children).toMatchSnapshot();
  });

});
