import React from 'react';
import { shallow } from 'enzyme';

import InputIncorrectEnteriesMain from '../../../../Modules/PharmacistReport/InputIncorrectEnteries/InputIncorrectEnteriesMain';

describe('InputIncorrectEnteriesMain', () => {

    it('should render correctly for summary report', () => {
        const component = shallow(<InputIncorrectEnteriesMain location={{ search:'isSummaryReport=True' }} />);
        component.instance();
    });

    it('should render correctly for detailed report', () => {
        const component = shallow(<InputIncorrectEnteriesMain location={{ search:'isSummaryReport=False' }} />);
        component.instance();
    });
});
