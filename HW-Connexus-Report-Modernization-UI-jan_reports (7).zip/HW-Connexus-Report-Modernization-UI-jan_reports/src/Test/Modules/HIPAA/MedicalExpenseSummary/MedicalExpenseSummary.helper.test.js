import {
  formHeader,
  formHeader4,
  formHeader7,
  formHeader8,
} from '../../../../Modules/HIPAA/MedicalExpenseSummary/MedicalExpenseSummary.helper';

describe('MedicalExpenseSummary', () => {
  it('should pass', () => {
    const data = [
      {
        label1: 'Date Filled',
        label2: 'Date Written',
        label3: '',
        data1: 'dateFilled',
        data2: 'dateWritten',
        data3: '',
      },
      {
        label1: 'Rx',
        label2: 'Fill ID',
        label3: '',
        data1: 'rx',
        data2: 'fillId',
        data3: '',
      },
      {
        label1: 'Drug Name',
        label2: 'NDC',
        label3: '',
        data1: 'drugName',
        data2: 'ndc',
        data3: '',
      },
      {
        label1: 'Prescriber',
        label2: 'Physician DEA',
        label3: 'Physician NPI',
        data1: 'prescriber',
        data2: 'physicianDea',
        data3: 'physicianNpi',
      },
      {
        label1: 'Qty',
        label2: 'Refill',
        label3: '#',
        data1: 'quantity',
        data2: 'refill',
        data3: 'number',
      },
      {
        label1: 'Days',
        label2: 'Supply',
        label3: '',
        data1: 'days',
        data2: 'supply',
        data3: '',
      },
      {
        label1: 'Dispense As Written',
        label2: 'SIG',
        label3: '',
        data1: 'dispenseAsWritten',
        data2: 'sig',
        data3: '',
      },
      {
        label1: 'Patient Paid',
        label2: 'TP Ref #',
        label3: '',
        data1: 'patientPaid',
        data2: 'tpRefNumber',
        data3: '',
      },
    ];
    expect(formHeader('1', '1', '1')).toEqual(data);
  });
  it('formHeader4 should pass', () => {
    const data = {
      label1: 'Prescriber',
      label2: 'Physician DEA',
      label3: '',
      data1: 'prescriber',
      data2: 'physicianDea',
      data3: '',
    };
    expect(formHeader4('2')).toEqual(data);
  });
  it('formHeader4 should pass', () => {
    const data = {
      label1: 'Prescriber',
      label2: '',
      label3: '',
      data1: 'prescriber',
      data2: '',
      data3: '',
    };
    expect(formHeader4('3')).toEqual(data);
  });
  it('formHeader7 should pass', () => {
    const data = {
      label1: 'Dispense',
      label2: 'As Written',
      label3: '',
      data1: 'dispenseAsWritten',
      data2: '',
      data3: '',
    };
    expect(formHeader7('2')).toEqual(data);
  });
  it('formHeader8 should pass', () => {
    const data = {
      label1: 'Patient Paid',
      label2: 'Cash Price',
      label3: 'TP Ref #',
      data1: 'patientPaid',
      data2: 'cashPrice',
      data3: 'tpRefNumber',
    };
    expect(formHeader8('2')).toEqual(data);
  });
  it('formHeader8 should pass', () => {
    const data = {
      label1: 'Amount Due',
      label2: 'TP Ref #',
      label3: '',
      data1: 'amountDue',
      data2: 'tpRefNumber',
      data3: '',
    };
    expect(formHeader8('3')).toEqual(data);
  });
  it('formHeader8 should pass', () => {
    const data = {
      label1: 'Amount Due',
      label2: 'Cash Price',
      label3: 'TP Ref #',
      data1: 'amountDue',
      data2: 'cashPrice',
      data3: 'tpRefNumber',
    };
    expect(formHeader8('4')).toEqual(data);
  });
  it('formHeader8 should pass', () => {
    const data = {
      label1: 'Patient Paid',
      label2: '',
      label3: '',
      data1: 'patientPaid',
      data2: '',
      data3: '',
    };
    expect(formHeader8('5')).toEqual(data);
  });
  it('formHeader8 should pass', () => {
    const data = {
      label1: 'Patient Paid',
      label2: 'Cash Price',
      label3: '',
      data1: 'patientPaid',
      data2: 'cashPrice',
      data3: '',
    };
    expect(formHeader8('6')).toEqual(data);
  });
  it('formHeader8 should pass', () => {
    const data = {
      label1: 'Amount Due',
      label2: '',
      label3: '',
      data1: 'amountDue',
      data2: '',
      data3: '',
    };
    expect(formHeader8('7')).toEqual(data);
  });
  it('formHeader8 should pass', () => {
    const data = {
      label1: 'Amount Due',
      label2: 'Cash Price',
      label3: '',
      data1: 'amountDue',
      data2: 'cashPrice',
      data3: '',
    };
    expect(formHeader8('8')).toEqual(data);
  });
});
