import React from 'react';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import { MedicalExpenseSummary } from '../../../../Modules/HIPAA/MedicalExpenseSummary/MedicalExpenseSummary.tsx';
import { mockUseApi } from '../../../util';
import { apiStates } from '../../../../Modules/Common/useApi.ts';
import * as data from '../../../../../public/medical-expense-summary.json';

describe('MedicalExpenseSummary', () => {
  it('should render loading message', () => {
    mockUseApi({ data: {}, state: apiStates.LOADING, error: '' });
    const { container } = render(
      <MedicalExpenseSummary location={{}} />,
    );
    expect(container.children).toMatchSnapshot();
  });

  it('should render report w/ data', () => {
    mockUseApi({ data, state: apiStates.SUCCESS, error: '' });
    const { container } = render(
      <MedicalExpenseSummary location={{}} />,
    );
    expect(container.children).toMatchSnapshot();
  });

  it('should render error message', () => {
    mockUseApi({ data: {}, state: apiStates.ERROR, error: 'error' });
    const { container } = render(
      <MedicalExpenseSummary location={{}} />,
    );
    expect(container.children).toMatchSnapshot();
  });
});
