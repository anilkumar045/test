import React from 'react';
import { shallow } from 'enzyme';
import Table from '../../../../Modules/HIPAA/MedicalExpenseSummary/CustomTable';
import * as data from '../../../../../public/medical-expense-summary.json';

describe('MedicalExpenseSummary', () => {
  it('should render correctly', () => {
    shallow(<Table data={[]} header={[]} />);
  });

  it('should render correctly', () => {
    const header = [
      {
        label1: 'Date Filled',
        label2: 'Date Written',
        label3: '',
        data1: 'dateFilled',
        data2: 'dateWritten',
        data3: '',
      },
      {
        label1: 'Rx',
        label2: 'Fill ID',
        label3: '',
        data1: 'rx',
        data2: 'fillId',
        data3: '',
      },
      {
        label1: 'Drug Name',
        label2: 'NDC',
        label3: '',
        data1: 'drugName',
        data2: 'ndc',
        data3: '',
      },
      {
        label1: 'Prescriber',
        label2: 'Physician DEA',
        label3: 'Physician NPI',
        data1: 'prescriber',
        data2: 'physicianDea',
        data3: 'physicianNpi',
      },
      {
        label1: 'Qty',
        label2: 'Refill',
        label3: '#',
        data1: 'quantity',
        data2: 'refill',
        data3: 'number',
      },
      {
        label1: 'Days',
        label2: 'Supply',
        label3: '',
        data1: 'days',
        data2: 'supply',
        data3: '',
      },
      {
        label1: 'Dispense As Written',
        label2: 'SIG',
        label3: '',
        data1: 'dispenseAsWritten',
        data2: 'sig',
        data3: '',
      },
      {
        label1: 'Patient Paid',
        label2: 'TP Ref #',
        label3: '',
        data1: 'patientPaid',
        data2: 'tpRefNumber',
        data3: '',
      },
    ];
    shallow(
      <Table data={data.data} header={header} id="reportTable" />,
    );
  });
});
