import React from 'react';
import { shallow } from 'enzyme';
import Wrapper, {
  TPReceivables,
} from '../../../Modules/TPReceivables/TPReceivables';
import { mockSuccess, mockFailure } from '../../util';

describe('TPReceivables', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render correctly', () => {
    const component = shallow(<TPReceivables location={{}} />);
    component.instance();
  });

  it('should render correctly', () => {
    const component = shallow(<TPReceivables location={{}} />);
    const instance = component.instance();
    instance.setState({ error: 'network error', loading: false });
  });

  it('should render correctly', () => {
    const component = shallow(<TPReceivables location={{}} />);
    const instance = component.instance();
    instance.setState({ data: { data: [] }, loading: false });
  });

  it('should render correctly', () => {
    mockSuccess({ data: { data: [{ test: 1 }, {}] } });
    const component = shallow(<TPReceivables location={{}} />);
    const instance = component.instance();
    expect(instance.state.data).toEqual({ data: [{ test: 1 }, {}] });
  });

  it('should render correctly', () => {
    mockFailure('error');
    const component = shallow(<TPReceivables location={{}} />);
    const instance = component.instance();
    expect(instance.state.error).toEqual('error');
  });
});
