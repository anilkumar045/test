import React from 'react';
import { shallow } from 'enzyme';
import Wrapper, {
  RxReport,
} from '../../../Modules/RxReport/RxReport';

describe('RxReport', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render correctly', () => {
    const component = shallow(<RxReport location={{}} />);
    component.instance();
  });

  it('should render correctly', () => {
    const component = shallow(<RxReport location={{}} />);
    const instance = component.instance();
    instance.setState({ error: 'network error', loading: false });
  });

  it('should render correctly', () => {
    const component = shallow(<RxReport location={{}} />);
    const instance = component.instance();
    instance.setState({ data: {}, loading: false });
  });
});
