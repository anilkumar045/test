import React from 'react';
import { shallow } from 'enzyme';
import Table from '../../../Modules/RxReports/PartialFill/Table';

describe('partial fill report', () => {
  it('should render correctly', () => {
    shallow(<Table data={[]} header={[]} />);
  });

  it('should render result correctly', () => {
    const header = [
      {
        label: 'Fill Date',
        id: 'fillDt',
      },
      {
        label1: 'Rx #',
        label2: 'Fill #',
        id1: 'rxNo',
        id2: 'fillNo',
      },
      {
        label: 'Name',
        id: 'name',
      },
      {
        label: 'Status',
        id: 'status',
      },
      {
        label1: 'Drug',
        label2: 'Qty',
        id1: 'drug',
        id2: 'qty',
      },
      {
        label: 'Payment',
        id: 'payment',
      },
      {
        label: 'Patient Pay',
        id: 'patientPay',
      },
      {
        label: 'Sold',
        id: 'sold',
      },
      {
        label: 'Write-Off',
        id: 'writeOff',
      },
    ];
    const data = [
      {
        fillDt: '05/07/2020',
        rxNo: '2203606',
        fillNo: '1125303',
        name: 'ARYA.STARK',
        status: 'I',
        drug: 'HYDROCO/APAP7 TAB',
        qty: 'Qty :3',
        payment: 'CASH',
        patientPay: '$ 0.00',
        sold: 'Y',
        writeOff: '',
      },
      {
        fillDt: '05/08/2020',
        rxNo: '6631756',
        fillNo: '1125308',
        name: 'ARYA.STARK',
        status: 'I',
        drug: 'FLUCONOZOLE/200MG TAB',
        qty: 'Qty :3',
        payment: 'CASH',
        patientPay: '$ 0.00',
        sold: 'Y',
        writeOff: '',
      },
    ];
    shallow(<Table data={data} header={header} />);
  });
});
