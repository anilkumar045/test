import React from 'react';
import { render } from '@testing-library/react';
import { shallow } from 'enzyme';
import Wrapper, {
  PharmacistActivity,
} from '../../../Modules/PharmacistActivity/PharmacistActivity.tsx';
import { mockSuccessts, mockFailurets } from '../../util';

describe('PharmacistActivity', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render correctly', () => {
    mockSuccessts({ data: { data: [{}, {}], header: [] } });
	const { container } = render(<PharmacistActivity location={{}} />);
    expect(container.children).toMatchSnapshot();
  });

  it('should render correctly', () => {
    mockSuccessts({ data: null });
    const { container } = render(<PharmacistActivity location={{}} />);
    expect(container.children).toMatchSnapshot();
  });

  it('should render correctly', () => {
    mockFailurets('error');
    const { container } = render(<PharmacistActivity location={{}} />);
    expect(container.children).toMatchSnapshot();    
  });
});