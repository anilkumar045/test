import React from 'react';
import { shallow } from 'enzyme';
import Table from '../../../Modules/Common/Table';

describe('RxReport', () => {
  it('should render correctly', () => {
    shallow(<Table data={[]} header={[]} />);
  });

  it('should render correctly', () => {
    const header = [
      {
        label: 'Rx',
        id: 'Rx',
      },
      {
        label: 'PatientName',
        id: 'PatientName',
      },
      {
        label: 'FillDate',
        id: 'FillDate',
      },
      {
        label: 'Drug',
        id: 'Drug',
      },
      {
        label: 'Quantity',
        id: 'Quantity',
      },
      {
        label: 'DAW',
        id: 'DAW',
      },
      {
        label: 'UserId',
        id: 'UserId',
      },
      {
        label: 'Date/Time',
        id: 'Date/Time',
      },
    ];
    shallow(<Table data={[{ unique: 1 }]} header={header} />);
  });
});
