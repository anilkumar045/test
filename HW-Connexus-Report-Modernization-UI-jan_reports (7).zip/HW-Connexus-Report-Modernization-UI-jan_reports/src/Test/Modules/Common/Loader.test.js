import React from 'react';
import { shallow } from 'enzyme';
import Loader from '../../../Modules/Common/Loader';

describe('Loader', () => {
  it('should render correctly', () => {
    shallow(<Loader />);
  });
});
