import React from 'react';
import { shallow } from 'enzyme';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import Wrapper, {
  FourPTRPhCorrectionSummary,
} from '../../../Modules/FourPTRPhCorrections/FourPTRphCorrectionSummary';
import { mockUseApi } from '../../util';
import { apiStates } from '../../../Modules/Common/useApi';
import * as data from '../../../../public/4PT-Rph-corrections-summary.json';

describe('FourPointCorrection', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render loading message', () => {
    mockUseApi({ data: {}, state: apiStates.LOADING, error: '' });
    const { container } = render(
      <FourPTRPhCorrectionSummary
        location={{ pathname: '/Four-PTRph-Correction' }}
      />,
    );
    expect(container.children).toMatchSnapshot();
  });

  it('should render report w/ data', () => {
    mockUseApi({ data, state: apiStates.SUCCESS, error: '' });
    const { container } = render(
      <FourPTRPhCorrectionSummary
        location={{ pathname: '/Four-PTRph-Correction' }}
      />,
    );
    expect(container.children).toMatchSnapshot();
  });

  it('should render error message', () => {
    mockUseApi({
      data: {},
      state: apiStates.ERROR,
      error: 'network error',
    });
    const { container } = render(
      <FourPTRPhCorrectionSummary
        location={{ pathname: '/Four-PTRph-Correction' }}
      />,
    );
    expect(container.children).toMatchSnapshot();
  });
});
