import React from 'react';
import { shallow } from 'enzyme';
import Table from '../../../Modules/FourPTRPhCorrections/Table';

describe('FourPTRTable', () => {
  it('should render correctly', () => {
    shallow(<Table data={[]} header={[]} />);
  });

  it('should render correctly', () => {
    const header = [
      {
    "label": "Pharmacist's Name",
    "id": "pharmacistName"
  },
  {
    "label": "User Id",
    "id": "userId"
  },
  {
    "label": "Store Number",
    "id": "storeNumber"
  },
  {
    "label": "Number Of 4PT Corrections (Maximum of one RX per User One Rx may have been corrected by multiple users)",
    "id": "numberOfCorrection"
  }
    ];
    shallow(<Table data={[{}]} header={header} />);
  });
});
