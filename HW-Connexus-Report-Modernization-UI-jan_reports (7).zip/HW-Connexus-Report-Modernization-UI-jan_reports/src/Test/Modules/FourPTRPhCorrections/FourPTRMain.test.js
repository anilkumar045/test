import React from 'react';
import { shallow } from 'enzyme';
import FourPTRphCorrectionMain from '../../../Modules/FourPTRPhCorrections/FourPTRphCorrectionMain';

describe('FourPTRMain', () => {

    it('should render correctly', () => {
        const component = shallow(<FourPTRphCorrectionMain location={{}} />);
        component.instance();
    });

    it('should render correctly', () => {
        shallow(<FourPTRphCorrectionMain location={{}} />);
    });
});
